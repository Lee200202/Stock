# 張震股市盤中家教班　自動追蹤網站

2026/09/11 更新：已改為上下文收錄與合併 JSON 判讀，請先閱讀 [本次部署與重跑說明](release/DEPLOY_CONTEXT_JSON_V3.md)。

把 YouTube 頻道「張震_股市盤中家教班」每天的盤中直播，自動整理成可查詢、可比對、可追蹤的網站與每日推播信。核心原則只有一條：**只呈現影片中明確講過的內容，沒講到就標「未說明」，不推測、不補完。**

本站與該頻道無隸屬關係，內容整理自公開直播。

---

## 一、系統架構

兩層式，中間用一份 Google 試算表當唯一交換介面，彼此不直接呼叫。

上游 GitHub Actions（平日，內部輪詢循環）：抓影片清單 → 取逐字稿（拿到即先落地）→ Gemini 潤飾/擷取/完整性稽核 → 分類、代號比對、產業剔除、寫入試算表。

下游 Apps Script（觸發器）：每日品質關卡（完整性稽核補漏 → 內容複審 → 重寫每日整理）、補快取（日K/基本面/報價）、重算持股追蹤（含逐日說明、轉譯錯誤剔除）、渲染網站（圖表、逐日、郵件查詢、AI 助手）、寄信（推播含防重寄、狀態、告警）。

會員簡訊的盤中偵測由 Apps Script 每分鐘執行；同日有文章後，持續用字數與 SHA-256 比對同一篇內容，直到監看時段結束。補抓最近七天、全部文章、依編號補抓、AI 解析、寫入操作紀錄與逐日稽核統一由 GitHub Actions 執行。流程固定先辨識張震，再以可驗證的來源時間篩選日期；日期缺失的文章只進「會員簡訊稽核」，不會以執行日代替。

---

## 二、檔案清單

上游（GitHub，Python）：
- `pipeline.py`：GitHub Actions 使用的主程式。`pipeline/pipeline.py` 保留同版副本供分目錄部署使用。
- daily.yml：GitHub Actions 工作流程。放在 .github/workflows/daily.yml。
- requirements.txt：Python 相依套件。

下游（Google Apps Script，.gs）：
- Code.gs：對外 API 端點（api* 系列），前端經 google.script.run 呼叫。
- Setup.gs：初始化試算表分頁、安裝所有觸發器（installTriggers）。
- SheetService.gs：讀試算表、每日總覽、搜尋、持股追蹤重算（rebuildHoldingsTrackerJob）。
- AdminService.gs / AdminPipeline.gs：後台投稿工單、整理過去資料、全面重整、內容複審（reviewDayRecords_）與三段提示語。
- CacheBuilder.gs：日K/基本面/代號對照快取；產業列清除（purgeIndustryRows）；一鍵刷新（refreshSiteNow）。
- QuoteService.gs：即時報價、K 線聚合、共用快取與速率保護。
- AiService.gs：問答小幫手後端，代呼叫使用者自帶的 Gemini 金鑰；含郵件唯讀查詢。
- MailService.gs：訂閱、每日推播（含防重寄鎖）、狀態報告、失敗告警、郵件查詢函式。含假日判斷。每日品質關卡（稽核補漏、內容複審、重寫每日整理）也在這裡，寄信之前一定先跑完它。

下游（前端 HTML，貼進 Apps Script）：
- Index.html：頁面骨架與各分頁結構（含郵件查詢分頁）。
- JavaScript.html：前端邏輯（分頁、圖表、詳情抽屜、聊天、訂閱、郵件查詢、管理刷新）。
- Stylesheet.html：全站樣式與動畫。整份必須只有一組 <style>...</style>，</style> 為最後一行。
- Tech.html：技術說明頁（架構、金鑰、排程、版本沿革、常見問題、管理刷新入口）。
- Unsubscribed.html：退訂完成頁。

---

## 三、需要哪些金鑰與設定

- NOTEBOOKLM_AUTH_JSON（GitHub Secrets）：NotebookLM 登入狀態（storage_state.json 內容），取逐字稿。必要。
- GEMINI_API_KEY（GitHub Secrets + 指令碼屬性）：潤飾、擷取、稽核。必要。
- GOOGLE_SHEETS_SERVICE_ACCOUNT（GitHub Secrets）：服務帳號金鑰，寫試算表。必要。
- SPREADSHEET_ID（GitHub Secrets + 指令碼屬性）：試算表位置。必要。
- YOUTUBE_API_KEY（GitHub Secrets）：取影片清單（避開 RSS 對機房 IP 的 404）。建議。
- YOUTUBE_CHANNEL_ID（GitHub Variables）：目標頻道，未設有內建預設。選用。
- OWNER_EMAIL（指令碼屬性）：失敗告警與稽核通知收件者。必要。
- STATUS_EMAILS（指令碼屬性）：爬取狀態報告收件者，逗號分隔。建議。
- FUGLE_API_KEY（指令碼屬性）：上櫃股票日K；個股現爬。選用。
- ADMIN_KEY（指令碼屬性 + GitHub Secrets）：網站「立即刷新」管理密鑰，這是自己訂的字串，不是別人發的。兩邊必須是同一組，GitHub 才能在跑完後遠端要求下游重算。建議。
- APPS_SCRIPT_URL（GitHub Secrets）：網頁應用程式的部署網址（/exec 結尾），供上游跑完後通知下游刷新。選用。

這兩個值怎麼拿：在 Apps Script 編輯器執行 showDeployInfo()，執行紀錄會一次印出網址與密鑰，
沒設過密鑰時會自動產生一組，並附上一串可直接貼到瀏覽器驗證端點的測試網址。
手動找的話：網址在「部署 → 管理部署作業」，密鑰在「專案設定 → 指令碼屬性」。
網址務必用 /exec 結尾那個（/dev 只有本人登入能開），部署的「誰可以存取」要設成「所有人」，
而且改過 Code.gs 之後一定要重新部署新版本，否則線上跑的還是舊程式碼。

使用者在問答小幫手貼的自己那把 Gemini 金鑰不屬於上表，只存在使用者瀏覽器的 localStorage，隨每次提問傳進後端、用完即丟，不寫入任何地方。

NotebookLM 認證重點：notebooklm-py 0.7.3 用 Google web session cookie（storage_state.json）認證，cookie 會被 Google 輪換、數天內過期。過期時在本機重新登入，把新的 storage_state.json 內容更新到 NOTEBOOKLM_AUTH_JSON。若 Playwright login 產生的 session 過期太快，改用瀏覽器 cookie 來源（需要能安裝 [cookies] extra 的 Python 環境，例如 3.11/3.12，Firefox 最不會被 App-Bound Encryption 擋）。

---

## 四、部署步驟

上游（GitHub）：
1. 把最新版 `pipeline.py` 與 `requirements.txt` 放在儲存庫根目錄；工作流程會在執行前驗證程式版本。
2. daily.yml 放進 .github/workflows/。
3. 到 Settings → Secrets and variables → Actions 設定上表的 Secrets 與 Variables。
   > 注意：更新時請務必讓 `daily.yml` 與根目錄的 `pipeline.py` 同步提交。工作流程會優先執行根目錄版本，只有根目錄不存在時才使用 `pipeline/pipeline.py`。

下游（Apps Script）：
1. 建立一個 Apps Script 專案，綁定目標 Google 試算表。
2. 把 7 個 .gs 與 5 個 .html 逐一貼進去（HTML 檔用「HTML」類型建立，檔名不含副檔名，例如 Index）。
3. 到專案設定的「指令碼屬性」設定上表對應的屬性。
4. 執行一次 Setup.gs 的 installTriggers() 安裝所有觸發器。
5. 部署為網頁應用程式（每次改前端後要「部署新版本」才會生效）。

日後只改了前端（HTML）時，覆蓋對應檔案並「部署新版本」即可，不需要重跑資料。

---

## 五、系統排程（台灣時間，僅平日）

上游 GitHub：cron 只是「觸發」，實際爬取由 pipeline 進來後的內部輪詢循環控制（每次 job 進來自己每 3 分鐘敲一次門，約 25 分鐘收尾，交給下一次接力）。觸發點：11:20/35/50、12:05~12:50、13:05~13:50、14:05/25/45、15:03（最後一次才判定今日無影片）。

下游 Apps Script：
- 每 5 分鐘 refreshQuoteCacheJob（報價快取）
- 每 30 分鐘 authWatchJob（檢查登入是否失效）
- 12:30、13:10、15:50 statusReportJob（狀態報告）
- 13:00、14:00、15:30 dailyPushJob（每日整理，有防重寄鎖）。寄之前會先跑品質關卡，關卡沒跑完就先退出，關卡跑完自己會接回來寄，通常晚三到五分鐘
- 15:20 auditAutoFixJob（品質關卡的收尾保險，逐字稿太晚到手或關卡被中斷時補跑一次，不寄信）
- 14:05 aggregateHourlyJob、14:20 repairCodesJob、14:30 rebuildFundamentalsJob
- 14:35 backfillDailyKJob、14:50 rebuildHoldingsTrackerJob、15:05 snapshotPerformanceJob
- 15:45 failureAlertJob（異常才寄）
- 每週日 04:00 rebuildCodeMapJob、每月 5 日 03:00 yearlyArchiveJob

推播分三時段用鎖搶占：搶到的先標「寄送中」，其餘退出，確保同一天只寄一封。

---

## 六、可手動調動的設定（GitHub Actions → Run workflow，互斥）

- backfill：一次處理 2026 起未完成的全部影片（會呼叫 NotebookLM/Gemini）。
- final：30 分鐘長逾時，手動補跑單一影片。
- fill_blanks：補齊缺逐字稿的列並重跑擷取。
- repair_codes：只重跑代號比對，非個股剔除（不呼叫 AI，幾十秒）。
- reclassify：依理由摘錄情緒把觀望改成觀望不碰/注意（不呼叫 AI，秒級）。
- fix_prices：價位說明校對。修正方向矛盾、非股價數字、概數當精確價三類錯誤。先用純規則快篩，只有可疑的列才送 Gemini。
- reconcile：AI 判定產業並刪除、抽取明講買入價並核對後寫回（只呼叫 Gemini，用已存逐字稿）。
- refresh_site：附掛動作，不是模式。跑完後立刻要求下游重算全站。可與上面任一項同勾，也可單獨勾（只刷新、不動資料）。

Apps Script 端常用函式：
- showDeployInfo()：印出 refresh_site 需要的兩個值，並檢查部署狀態。
- refreshSiteNow()：一鍵刷新網站既有內容（清產業、修代號、補日K、基本面、重算追蹤、記績效）。不抓新影片。想立刻更新網站而不等下個交易日時用這個。
- purgeIndustryRows()：立刻移除記憶體、台塑集團、AB載板等產業列。
- rebuildHoldingsTrackerJob()：重算持股追蹤與逐日說明。
- backfillDailyKJob()：補日K快取。
- installTriggers()：重裝所有排程。
- statusReportJob()：立即寄一封爬取狀態信。
- auditDigest("YYYY/MM/DD")：稽核某天推播與網站是否一致。
- reviewDay("YYYY/MM/DD")：只複審某一天，執行紀錄會列出改分類與刪除了哪幾筆。
- autoFixAuditMissing("YYYY/MM/DD")：只跑某一天的稽核補漏與漏抓判定，執行紀錄會列出每一檔收或不收與原因。
- runGateNow("YYYY/MM/DD")：立刻把某一天的品質關卡三段跑完（稽核、複審、重寫每日整理）。

立即刷新網站的三種方式：
1. 網站管理入口：技術說明頁最底部，輸入 ADMIN_KEY 後按「立即刷新網站內容」。
2. GitHub 一次到底：Actions → Run workflow，勾選要跑的模式並把 refresh_site 設為 true，整理完會自動通知下游重算。只想刷新畫面、資料不要動時，就只勾 refresh_site、其他都不勾。
3. Apps Script 編輯器：直接執行 refreshSiteNow()。

要注意上游改的是試算表，下游 Apps Script 才把試算表算成網站看到的樣子。只在 GitHub 跑完而沒有刷新，試算表會變但畫面要等下游 14:50 那一輪才更新。

---

## 七、試算表分頁

影片清單、操作紀錄、會員持股、每日推播內容（日期／文字稿／寄送狀態）、使用者訂閱清單、日K快取、小時K、即時快取、每日績效、盤中快照、基本面快取、持股追蹤、系統狀態、修正建議。各層只透過這些分頁溝通，程式用表頭名稱動態尋找欄位，不寫死欄號。

---

## 八、網站分頁

每日總覽、持股追蹤、績效走勢、個股查詢、訂閱通知、郵件查詢、AI 助手、技術說明。

- 郵件查詢：查任一天寄出的每日整理內容（與網站同源）。AI 助手也能唯讀查詢郵件內容（無權修改）。
- 持股追蹤：開倉的唯一條件是影片明講買入，會員持股名單只算提及、不能開倉。買入後出現觀望不碰視為出場（出場價取當日收盤，不用明講價），觀望注意不平倉。賣出後又買回來會切成多個回合，表格顯示最新一個回合，進場價與持有天數都從本回合起算。連續無實質操作字眼且首次理由未說明者，視為轉譯錯誤剔除。
- 翻到某一天與郵件查詢共用同一個日曆元件，只有真的有紀錄的日期才點得下去。

---

## 八之二、資料進表格前的兩道關卡

擷取只回答「有沒有提到這一檔」，那不夠。實際跑下來有兩種系統性錯誤：

漏抓。逐字稿點名了某一檔，擷取沒收進來，於是網站與推播都會少一檔。

多抓。講者拿以前的單子講道理被當成今天的操作。例如「漢唐我跌停沒賣，等上來到黑K棒上緣才賣」、「索羅門這支我已經沒了，我都賺錢賣」，那是教學，是完結的舊事，既不是今天的動作也不是現在的立場。這種內容進了表格，網站會顯示他在操作一檔早就出清的股票，持股追蹤還會據此開一個不存在的回合。

所以在寄信之前會自動跑一次品質關卡，三段依序做完：

1. 完整性稽核　對照修飾後逐字稿找出漏抓的個股，判定方向後自動補登。判不出來的留在「修正建議」分頁。
2. 內容複審　　逐筆問「這一次提到該不該記」。純粹回顧舊單、拿舊單當教學、只是報價沒有立場的整列刪掉。買入與賣出另外加高門檻：逐字稿必須看得到「今天、剛剛、這個盤中」實際執行，否則依結論退回觀望不碰、觀望注意或會員持股。
3. 重寫每日整理　紀錄變了，信件內容跟著重生，信與網站永遠同源。

複審會刪資料，所以做了三層保護：模型回沒把握的一律不動；逐字稿裡找不到對應段落的，節錄直接寫「找不到」讓模型回沒把握；單日刪除量超過七成時整批不刪，只寫紀錄。每一筆實際刪除都會寫進「修正建議」分頁留痕。

關卡跑完才寄信，所以訂閱者收到的就是複審後的版本。先前那封「[稽核] 推播與網站可能漏抓個股」的信已經取消——那封信要人自己到 GitHub 重跑，而那件事程式自己就做得到。

想套用到過去的資料，用後台的「全面重整」。它的第二步「稽核與複審」會把上面那整套關卡一天一天跑過歷史，
一加一減都做：只跑複審的話當初漏掉的永遠漏著，只跑稽核的話當初誤收的永遠留著。進度條會顯示看到第幾天。
被改動過的那幾天會連同郵件內容一起重寫，否則那天的信與網站會永久對不起來。

成本要有心得：一天三到四次模型呼叫，一百多個交易日大約四百到六百次，配合免費配額的每分鐘上限，
整段大約一到兩小時。中途可以關掉頁面，額度不夠會自己交棒，回來看進度條就好。

---

## 九、已知的脆弱環節

notebooklm-py 使用 Google 未公開文件化的內部 API，且 web session cookie 會被 Google 輪換、數天內過期。一旦取逐字稿失敗，當天就沒有自動產出——這也是失敗告警與認證守望存在的理由。憑證失效時的恢復動作是在本機重新登入，把新的 storage_state.json 更新到 GitHub Secret。這是整套系統裡唯一無法完全自動化的環節。

---

## 十、維護提醒

- Stylesheet.html 的 </style> 必須是最後一行。用附加方式加 CSS 時務必插在 </style> 之前，否則多出來的 CSS 會被當成網頁內文顯示成亂碼。
- 不要在 <tr> 上加 ::before / ::after 偽元素。在 table 版面它會被當成一個匿名儲存格，把第一個 <td> 擠到第二欄，造成整列右移。要加就加在某個 <td> 上。
- 數字一律不憑印象填，改動前先對照試算表或原始檔驗證。
- 每日推播的「每日推播內容」分頁欄名須為 日期／文字稿／寄送狀態，郵件查詢才讀得到。
