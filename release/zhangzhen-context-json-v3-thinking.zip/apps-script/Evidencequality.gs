/** Evidence-first quality helpers and durable day-edit publication chain. */
function rawTranscript_(row) {
  return String(row['原始逐字稿內容'] || row['修飾後逐字稿內容'] || '');
}

function validEvidence_(quotes, source) {
  function compact(t) { return String(t || '').replace(/\s+/g, ''); }
  var hay = compact(source);
  return Array.isArray(quotes) && quotes.length > 0 && quotes.every(function (q) {
    return typeof q === 'string' && compact(q).length >= 6 && hay.indexOf(compact(q)) >= 0;
  });
}

function recordChapter_(signals, d) {
  function table(head, rows) {
    if (!rows.length) { return '本支影片未說明。\n'; }
    function cell(x) { return String(x || '未說明').replace(/\|/g, '／').replace(/\n/g, ' '); }
    return ['| ' + head.join(' | ') + ' |', '| ' + head.map(function () { return '---'; }).join(' | ') + ' |']
      .concat(rows.map(function (r) { return '| ' + r.map(cell).join(' | ') + ' |'; })).join('\n') + '\n';
  }
  var rows = [];
  [['buy', '買入'], ['sell', '賣出']].forEach(function (pair) {
    (signals[pair[0]] || []).forEach(function (r) {
      rows.push([r.name, r.code, pair[1], r.price, r.reason]);
    });
  });
  var text = '④ 會員操作紀錄與持股明細\n\n④-1 當日明確說明之買入／賣出紀錄\n\n';
  text += rows.length ? table(['股票名稱', '股票代號', '方向', '價位區間／成本說明', '張震口頭說明與操作理由'], rows)
                      : '本支影片未說明當日具體買賣紀錄。\n';
  text += '\n④-2 影片中明講之「會員目前持有股票」\n\n';
  text += table(['股票名稱', '股票代號', '張震在本集節目中的說明重點'],
    (signals.holdings || []).map(function (r) { return [r.name, r.code, r.note]; }));
  text += '\n④-3 觀望個股（當日未執行買賣）\n';
  [['watch_avoid', '觀望不碰'], ['watch_watch', '觀望注意']].forEach(function (pair) {
    text += '\n' + pair[1] + '\n\n' + table(['股票名稱', '股票代號', '價位說明', '張震口頭說明重點'],
      (signals[pair[0]] || []).map(function (r) { return [r.name, r.code, r.price, r.reason]; }));
  });
  return text;
}

// Six-section rendering lives in Articlequality.gs.

var DAY_SYNC_KEY = 'dayEditSyncV1';
var DAY_SYNC_NAMES = ['同步郵件內容', '重算持股追蹤', '重算歷史績效', '記錄目前績效'];

function daySyncState_() {
  return JSON.parse(PropertiesService.getScriptProperties().getProperty(DAY_SYNC_KEY) || 'null');
}
function saveDaySync_(s) {
  s.updatedAt = nowStamp_();
  PropertiesService.getScriptProperties().setProperty(DAY_SYNC_KEY, JSON.stringify(s));
}
function scheduleDaySync_() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'runDayEditSync_') { ScriptApp.deleteTrigger(t); }
  });
  ScriptApp.newTrigger('runDayEditSync_').timeBased().after(2000).create();
}
function apiAdminStartDaySync(key, dateStr) {
  try {
    adminAuth_(key);
    var d = fmtDate_(dateStr);
    if (!/^20\d{2}\/\d{2}\/\d{2}$/.test(d)) { throw new Error('請選擇完整日期'); }
    return withLock_(function () {
      var prev = daySyncState_();
      if (prev && prev.status === '處理中') { throw new Error(prev.date + ' 更新中，請等此輪完成'); }
      saveDaySync_({ id: 'DAY-' + Date.now(), date: d, status: '處理中', index: 0,
        total: DAY_SYNC_NAMES.length, step: DAY_SYNC_NAMES[0], log: [], startedAt: nowStamp_() });
      scheduleDaySync_();
      return { ok: true, message: d + ' 已排程，會接續完成郵件、持股追蹤及績效。' };
    });
  } catch (e) { return { ok: false, reason: String(e.message || e) }; }
}
function apiAdminDaySyncState(key) {
  adminAuth_(key);
  return { ok: true, state: daySyncState_(), names: DAY_SYNC_NAMES };
}
function apiAdminCancelDaySync(key) {
  adminAuth_(key);
  var st = daySyncState_();
  if (st && st.status === '處理中') { st.cancelled = true; saveDaySync_(st); }
  return { ok: true, message: '將在目前步驟結束後停止，已完成的資料保留。' };
}
function runDayEditSync_() {
  // One step per invocation; the cursor advances only after a successful return.
  var st = daySyncState_();
  if (!st || st.status !== '處理中') { return; }
  if (st.cancelled) { st.status = '已取消'; saveDaySync_(st); return; }
  st.step = DAY_SYNC_NAMES[st.index];
  saveDaySync_(st);
  try {
    if (st.index === 0) {
      stepArticle_({ date: st.date, id: st.id, videoId: '', _nested: true });
    } else if (st.index === 1) {
      rebuildHoldingsTrackerJob();
    } else if (st.index === 2) {
      var result = rebuildPerformanceHistoryJob(st.date);
      if (!result || !result.ok) { throw new Error(result && result.reason || '歷史績效未完成'); }
    } else if (st.index === 3) { snapshotPerformanceJob(); }
    st.log.push(st.step + '：完成');
    st.index++;
    var current = daySyncState_();
    if (current && current.id === st.id && current.cancelled) { st.cancelled = true; }
    st.status = st.cancelled ? '已取消' : st.index === st.total ? '完成' : '處理中';
    saveDaySync_(st);
    if (st.status === '處理中') { scheduleDaySync_(); }
  } catch (e) {
    st.status = '失敗'; st.error = String(e.message || e); saveDaySync_(st);
    throw e;
  }
}

/* ------------------------------------------------------------------ *
 * 判定歷程
 *
 * 上游每一輪的稽核都會做很多決定：丟掉哪幾筆、哪幾筆改列歷史、
 * 哪個名字被改判成另一家公司、哪一段沒潤飾到。那些決定原本只印在
 * GitHub 的日誌裡——沒有人會每天去看，而且過幾天就被新的執行洗掉。
 *
 * 上游現在把它們寫進「判定歷程」分頁，這一支只負責讀出來給後台看。
 * 它是給人判讀用的，不參與任何計算。
 * ------------------------------------------------------------------ */
var DECISION_SHEET_ = '判定歷程';

function apiAdminDecisions(key, opts) {
  try {
    adminAuth_(key);
    var o = opts || {};
    var want = String(o.date || '').trim();
    var limit = Math.min(Math.max(Number(o.limit) || 200, 1), 500);

    var sh;
    try { sh = getSheet_(DECISION_SHEET_); }
    catch (e) { return { ok: true, rows: [], runs: [], note: '還沒有任何判定紀錄。' }; }

    var vals = sh.getDataRange().getValues();
    if (vals.length < 2) { return { ok: true, rows: [], runs: [], note: '還沒有任何判定紀錄。' }; }

    var head = vals[0].map(function (h) { return String(h).trim(); });
    var ci = {};
    ['時間', '執行代號', '影片日期', '步驟', '動作', '對象', '說明', '來源']
      .forEach(function (k) { ci[k] = head.indexOf(k); });

    var rows = [], runs = {};
    for (var i = vals.length - 1; i >= 1; i--) {
      var r = vals[i];
      var g = function (k) {
        var j = ci[k];
        return (j >= 0 && j < r.length) ? String(r[j]).trim() : '';
      };
      var d = fmtDate_(g('影片日期'));
      if (want && d !== want) { continue; }
      var run = g('執行代號');
      runs[run] = (runs[run] || 0) + 1;
      if (rows.length < limit) {
        rows.push({ at: g('時間'), run: run, date: d, step: g('步驟'),
                    action: g('動作'), subject: g('對象'),
                    detail: g('說明'), source: g('來源') });
      }
    }

    // 同一種判定重複出現，通常代表提示詞或規則該調了，所以順便統計。
    var tally = {};
    rows.forEach(function (x) {
      var k = x.step + '｜' + x.action;
      tally[k] = (tally[k] || 0) + 1;
    });
    var top = Object.keys(tally).sort(function (a, b) { return tally[b] - tally[a]; })
                .slice(0, 8).map(function (k) { return { what: k, n: tally[k] }; });

    return { ok: true, rows: rows, top: top,
             runs: Object.keys(runs).sort().reverse().slice(0, 20) };
  } catch (e) {
    return { ok: false, reason: String(e.message || e) };
  }
}
