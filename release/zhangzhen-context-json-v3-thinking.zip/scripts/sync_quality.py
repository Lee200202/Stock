"""Synchronize deployment copies; pipeline/pipeline.py is the sole runtime source.

Never reinstall stale runtime fragments over a newer pipeline.
"""
import ast
import json
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
    source=(ROOT/'pipeline/pipeline.py').read_text(encoding='utf-8')
    ast.parse(source)
    # Normalize both copies, including mixed line endings after Windows edits.
    encoded = source.replace('\r\n', '\n').encode('utf-8')
    (ROOT/'pipeline/pipeline.py').write_bytes(encoded)
    (ROOT/'pipeline.py').write_bytes(encoded)
    # Evaluate only string constants needed for prompt mirrors, no API imports.
    values={}
    for node in ast.parse(source).body:
        if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name):
            name=node.targets[0].id
            if name in ('POLICY','POLISH_SYSTEM','EXTRACT_SYSTEM','AUDIT_SYSTEM','ARTICLE_SYSTEM'):
                values[name]=eval(compile(ast.Expression(node.value),'<prompt>','eval'),{'__builtins__':{}},values)
    path=ROOT/'apps-script/Adminpipeline.gs';text=path.read_text(encoding='utf-8-sig')
    for name,value in [('PIPE_POLISH_SYSTEM',values['POLISH_SYSTEM']),('PIPE_ARTICLE_SYSTEM',values['ARTICLE_SYSTEM'])]:
        start=text.index('var '+name+' =');end=start+re.search(r';\s*\n',text[start:]).end()
        text=text[:start]+'var '+name+' = '+json.dumps(value,ensure_ascii=False)+';\n\n'+text[end:]
    path.write_text(text,encoding='utf-8')
    print('Synced root pipeline and active polish/article prompts')
if __name__=='__main__':main()
