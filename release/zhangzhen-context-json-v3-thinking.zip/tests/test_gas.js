const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const path = require('path');
const root = path.resolve(__dirname, '..');
let syntaxCount = 0;
for (const f of fs.readdirSync(path.join(root, 'apps-script'))) {
  const text = fs.readFileSync(path.join(root, 'apps-script', f), 'utf8');
  if (f.endsWith('.gs')) { new vm.Script(text, {filename: f}); syntaxCount++; }
  if (f.endsWith('.html')) {
    for (const match of text.replace(/<!--[\s\S]*?-->/g, '').matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)) {
      new vm.Script(match[1].replace(/<\?[\s\S]*?\?>/g, 'null'), {filename:f}); syntaxCount++;
    }
  }
}
const properties = {};
const calls = [];
const ctx = vm.createContext({
  PropertiesService: {getScriptProperties: () => ({getProperty:k=>properties[k],setProperty:(k,v)=>properties[k]=v})},
  ScriptApp: {getProjectTriggers:()=>[], newTrigger:()=>({timeBased:()=>({after:()=>({create:()=>{}})})})},
  nowStamp_:()=> '2026/09/10 16:00:00', fmtDate_:s=>s, adminAuth_:()=>{}, withLock_:f=>f(),
  stepArticle_:()=> calls.push('mail'), rebuildHoldingsTrackerJob:()=> calls.push('tracker'),
  rebuildPerformanceHistoryJob:d=>{calls.push('history:'+d);return {ok:true};},
  snapshotPerformanceJob:()=> calls.push('perf'),
});
vm.runInContext(fs.readFileSync(path.join(root, 'apps-script/Evidencequality.gs'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(root, 'apps-script/Articlequality.gs'),'utf8'),ctx);
assert(ctx.validEvidence_(['我昨天買世芯-KY，今天還有。'], '我昨天買世芯-KY，今天還有。'));
assert(!ctx.validEvidence_(['新代我們今天買了。'], '我昨天買世芯-KY，今天還有。'));
assert.equal(ctx.rawTranscript_({'原始逐字稿內容':'原文辛耘','修飾後逐字稿內容':'摘要星雲'}),'原文辛耘');
assert(ctx.apiAdminStartDaySync('k','2026/09/09').ok);
assert(!ctx.apiAdminStartDaySync('k','2026/09/10').ok);
ctx.runDayEditSync_();
assert.equal(ctx.daySyncState_().status,'處理中');
assert.equal(ctx.daySyncState_().index,1);
ctx.runDayEditSync_();ctx.runDayEditSync_();ctx.runDayEditSync_();
assert.deepStrictEqual(calls,['mail','tracker','history:2026/09/09','perf']);
assert.equal(ctx.daySyncState_().status,'完成');
ctx.apiAdminStartDaySync('k','2026/09/09');
ctx.runDayEditSync_();
ctx.rebuildHoldingsTrackerJob=()=>{throw new Error('tracker unavailable');};
assert.throws(()=>ctx.runDayEditSync_(),/tracker unavailable/);
assert.equal(ctx.daySyncState_().status,'失敗');
assert.equal(ctx.daySyncState_().index,1);
const oldCalls=calls.length;ctx.runDayEditSync_();assert.equal(calls.length,oldCalls);
ctx.apiAdminStartDaySync('k','2026/09/09');ctx.apiAdminCancelDaySync('k');ctx.runDayEditSync_();
assert.equal(ctx.daySyncState_().status,'已取消');
const sig={buy:[],sell:[],holdings:[{name:'鴻準',code:'2354',note:'目前仍持有。'}],watch_avoid:[],watch_watch:[]};
const article=ctx.enforceArticleRecords_('① 標題\n④ 會員操作紀錄與持股明細\n華城今日賣出\n⑤ 分析師操作邏輯與教學重點\n',sig,'2026/09/10');
assert(!article.includes('華城'));assert(article.includes('鴻準'));assert(article.includes('未說明當日具體買賣'));
assert(ctx.enforceArticleRecords_('不完整文章',sig,'2026/09/10').includes('⑥'));
console.log(`PASS: ${syntaxCount} script syntax checks; evidence, durable day-sync, failure, cancellation and article regression checks.`);
