/** 純常數與版本；避免初始化時呼叫其他模組。 */

var APP_TITLE = '張震股市盤中家教班　逐日追蹤';

var DISCLAIMER = '本站內容僅整理影片中明確講述的內容，不構成任何投資建議，投資決策與盈虧由使用者自行負責。';

// 版本標記。每次改動 doGet 的對外行為就要跟著更新，
// 呼叫端用它確認部署的是不是預期的版本。
var GAS_BUILD = '2026-09-12-context-json-v4';

// 這個版本支援的能力。呼叫端據此決定怎麼呼叫，
// 而不是打了才發現對方不認得參數。
var GAS_FEATURES = ['context-policy-v4', 'refresh-all-resumable', 'perf-history-pending', 'evidence-v2', 'evidence-v1', 'day-edit-sync-v1', 'ping', 'refresh-step', 'admin-page', 'quality-gate', 'full-fix',
                    'chain-state', 'chain-cancel', 'refresh-from', 'fullfix-state',
                    'manual-entry', 'review-rename', 'avoid-provisional', 'autofill-dailyk',
                    'day-edit', 'fullfix-scope',
                    'when-prev', 'trade-seq', 'reason-rewrite', 'shared-settings',
                    'ghost-guard', 'push-diagnostics', 'fine-progress', 'sms-parse', 'sms-detail', 'sms-manage',
                    'sms-checkpoint', 'sms-date-repair', 'natural-reasons', 'sms-sync-progress',
                    'sms-item-verifier', 'sms-direction-column', 'dailyk-safe-chunks',
                    /* 新版會員簡訊：範圍分流（當天／過去空白）、解析版本戳記、
                       配額熔斷與冷卻、逐步落地寫入、逐日稽核後的十三格收錄流程。 */
                    'sms-scope-v6', 'sms-version-stamp', 'sms-quota-cooldown',
                    'sms-incremental-write', 'sms-merge-chunks',
                    /* 資料修正的小工單：同步執行也回報段落進度，可看進度、可取消。 */
                    'fix-job-progress', 'fix-job-cancel',
                    /* 判定歷程與名稱判定紀錄：稽核每一輪做了哪些決定，後台查得到。 */
                    'decision-log', 'name-memo',
                    /* 續跑改成重新派工給 GitHub（先前排的是已退役的觸發器那條路）。 */
                    'resume-via-github', 'job-watchdog', 'step-index-fallback', 'legacy-runner-retired',
                    /* 訂閱管理直接做在頁面上：輸入信箱就列出目前訂了什麼，
                       逐項勾選後儲存，不寄信也不另開頁面。 */
                    'subscription-inline-manage',
                    /* 會員簡訊優先：簡訊的列不交給逐字稿複審，
                       否則複審會因為「逐字稿裡找不到」而把正確的紀錄刪掉。 */
                    'sms-priority-exempt-review',
                    /* 績效歷史可重算，且資料寫入後會自動觸發輕量刷新。 */
                    'perf-history-rebuild', 'auto-refresh-after-write'];

var REFRESH_ORDER_ = ['purge', 'gate1', 'gate2', 'gate3',
                      'codes', 'fund', 'dailyk', 'tracker', 'perf'];

var CHAIN_KEY_ = 'refreshChainState';
