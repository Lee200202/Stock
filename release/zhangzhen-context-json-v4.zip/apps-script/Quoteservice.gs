/**
 * 檔案：QuoteService.gs
 *
 * 報價來源分工：
 *   Fugle      當日即時報價與當日 60 分 K。有金鑰才啟用。
 *   證交所櫃買  歷史日K，由 CacheBuilder 落地到日K快取，線上只讀快取。
 *
 * 前端一律讀試算表快取，不觸發任何對外請求。這是網站載入速度的關鍵。
 *
 * 金鑰規範：FUGLE_API_KEY 只存在 Script Properties，只在本檔的
 * UrlFetchApp 呼叫中使用。前端、回傳值、錯誤訊息都不會出現金鑰內容。
 */

var CACHE = CacheService.getScriptCache();
var CODE_TTL = 21600;

/* ------------------------------------------------------------------ *
 * Fugle
 *
 * 額度：日內行情 60 次/分，歷史行情 60 次/分。
 * 追蹤清單約三十檔，一輪三十次請求，所以最密只能每分鐘一輪。
 * 實際排程是每 5 分鐘一輪，留了充足餘裕。
 * ------------------------------------------------------------------ */
var FUGLE_BASE = 'https://api.fugle.tw/marketdata/v1.0/stock';

function getFugleKey_() {
  return PropertiesService.getScriptProperties().getProperty('FUGLE_API_KEY') || '';
}

function hasFugle_() { return !!getFugleKey_(); }

function fugleFetch_(path) {
  var key = getFugleKey_();
  if (!key) { throw new Error('尚未設定 FUGLE_API_KEY。'); }

  var res = UrlFetchApp.fetch(FUGLE_BASE + path, {
    muteHttpExceptions: true,
    headers: { 'X-API-KEY': key }
  });
  var code = res.getResponseCode();

  if (code !== 200) {
    // 金鑰在 header 不在 URL，所以回應內容可以安全顯示。
    // 先前只印 HTTP 400，完全看不出是區間太長還是別的問題，白花很多時間。
    var body = '';
    try {
      var j = JSON.parse(res.getContentText());
      body = (j.message || j.error || res.getContentText()).toString().slice(0, 160);
    } catch (e) {
      body = res.getContentText().slice(0, 160);
    }
    var err = new Error('Fugle HTTP ' + code + (body ? '：' + body : ''));
    err.httpCode = code;
    throw err;
  }
  return JSON.parse(res.getContentText());
}

/** 當日即時報價 */
/* ==================================================================== *
 * 成交量的單位
 *
 * 全站對外一律用「張」。理由是台股的人在講的就是張，而網站上的數字要能
 * 跟看盤軟體對得起來，對不起來的數字比沒有數字更糟。
 *
 * 但三個資料來源給的單位不一樣，這是 1000 倍誤差的來源：
 *
 *   證交所 STOCK_DAY   成交股數，是「股」  → 程式除以 1000，正確
 *   證交所 MIS 即時    欄位 v，是「張」    → 直接用，正確
 *   Fugle              疑為「股」          → 先前直接用，於是大 1000 倍
 *
 * 為什麼寫「疑為」而不是直接斷定：這件事不該靠記憶。所以做了兩件事——
 * 換算集中在這一支函式，而且可以用指令碼屬性覆寫；另外附一支 checkVolumeUnit()
 * 拿同一檔股票同一天的 Fugle 與 MIS 數字實際比一次，用證據決定。
 *
 * 萬一哪天 Fugle 改了單位，改指令碼屬性 FUGLE_VOLUME_UNIT 為 'lot' 即可，
 * 不必動程式，也不必重新部署。
 * ==================================================================== */

/** Fugle 的量換算成張。 */
function fugleVolToLots_(v) {
  var n = Number(v) || 0;
  if (!n) { return 0; }
  var unit = String(PropertiesService.getScriptProperties()
                      .getProperty('FUGLE_VOLUME_UNIT') || 'share').trim();
  if (unit === 'lot') { return n; }        // 已經是張，不動
  return Math.round(n / 1000);             // 股 → 張
}

/**
 * 實證 Fugle 的量到底是股還是張。
 *
 * 做法是拿同一檔股票、同一個時間點的兩個來源比：
 * 證交所 MIS 的 v 欄位確定是「張」，Fugle 的 total.tradeVolume 未知。
 * 兩者相除就知道差幾個數量級。
 *
 * 盤中跑最準（兩邊都是當日累計）。收盤後跑也可以，只是兩邊的快照時間
 * 可能差一點，所以判斷用範圍而不是剛好等於 1000。
 *
 * 用法：在編輯器執行 checkVolumeUnit('2330')，看執行紀錄。
 */
function checkVolumeUnit(code) {
  code = String(code || '2330').trim();
  var out = ['========================================',
             '  Fugle 成交量單位實測　' + code,
             '========================================'];

  var mis = null, fug = null;
  try { mis = misQuote_(code); } catch (e) { out.push('MIS 取不到：' + e); }
  try { fug = hasFugle_() ? fugleQuote_(code) : null; }
  catch (e) { out.push('Fugle 取不到：' + e); }

  if (!hasFugle_()) {
    out.push('這個專案沒有設定 FUGLE_API_KEY，日K 只會走證交所那條路，');
    out.push('而那條路本來就有除以 1000，不會有這個問題。');
    Logger.log(out.join('\n'));
    return { skipped: '沒有 Fugle 金鑰' };
  }
  if (!mis || !fug || !mis.volume || !fug.volume) {
    out.push('兩邊至少有一邊沒有量（可能是非交易時段或這一檔今天沒成交）。');
    out.push('MIS   ' + (mis ? mis.volume : '取不到'));
    out.push('Fugle ' + (fug ? fug.volume : '取不到'));
    out.push('請在盤中再跑一次，或換一檔成交量大的（例如 2330）。');
    Logger.log(out.join('\n'));
    return { inconclusive: true };
  }

  // 注意：fugleQuote_ 現在回傳的已經是換算後的張，所以要把換算還原回去，
  // 才是 Fugle 原始給的數字。不還原的話這支永遠會說「已經是張」。
  var unitProp = String(PropertiesService.getScriptProperties()
                          .getProperty('FUGLE_VOLUME_UNIT') || 'share').trim();
  var fugRaw = (unitProp === 'lot') ? fug.volume : fug.volume * 1000;

  var ratio = fugRaw / mis.volume;
  out.push('證交所 MIS（確定是張）　' + mis.volume);
  out.push('Fugle 原始數字　　　　　' + fugRaw);
  out.push('比值　　　　　　　　　　' + ratio.toFixed(1));
  out.push('');

  var verdict;
  if (ratio > 300 && ratio < 3000) {
    verdict = 'share';
    out.push('判定：Fugle 給的是「股」。');
    out.push('目前的設定 FUGLE_VOLUME_UNIT=' + unitProp +
             (unitProp === 'share' ? '　正確，不必改。' : '　不對，請改成 share。'));
  } else if (ratio > 0.3 && ratio < 3) {
    verdict = 'lot';
    out.push('判定：Fugle 給的是「張」。');
    out.push('目前的設定 FUGLE_VOLUME_UNIT=' + unitProp +
             (unitProp === 'lot' ? '　正確，不必改。' : '　不對，請到指令碼屬性設成 lot。'));
  } else {
    verdict = 'unclear';
    out.push('判定：比值不在預期範圍，可能兩邊的快照時間差太多。');
    out.push('請在盤中交易時段再跑一次。');
  }

  Logger.log(out.join('\n'));
  return { mis: mis.volume, fugleRaw: fugRaw, ratio: ratio, verdict: verdict };
}

/**
 * 修既有的日K快取。
 *
 * 判斷方式刻意用「每一檔的中位數」而不是逐列比大小：
 * 同一檔的資料幾乎都來自同一個來源，所以整條序列要嘛都是股、要嘛都是張，
 * 中位數比單列穩定，不會被某一天的爆量或零成交帶偏。
 *
 * 門檻放在 100 萬張。台股單日成交量最大的個股也就幾萬張到十幾萬張，
 * 中位數到 100 萬張在物理上不可能，所以超過就確定是「股」沒換算。
 * 這個門檻離真實值有一個數量級以上的距離，不會誤判。
 *
 * 先用 repairDailyKVolume(true) 乾跑看名單，確認了再 repairDailyKVolume()。
 */
function repairDailyKVolume(dryRun) {
  var sh = getSheet_('日K快取');
  var vals = sh.getDataRange().getValues();
  if (vals.length < 2) { Logger.log('日K快取是空的'); return { fixed: 0 }; }

  var head = vals[0];
  var cCode = head.indexOf('代號'), cVol = head.indexOf('量');
  if (cCode < 0 || cVol < 0) { Logger.log('找不到代號或量欄'); return { fixed: 0 }; }

  var THRESHOLD = 1000000;   // 中位數超過這個張數就是沒換算的股

  // 依代號分組
  var byCode = {};
  for (var i = 1; i < vals.length; i++) {
    var c = String(vals[i][cCode] || '').trim();
    var v = Number(vals[i][cVol]);
    if (!c || !isFinite(v) || v <= 0) { continue; }
    (byCode[c] = byCode[c] || []).push({ row: i + 1, v: v });
  }

  var bad = [];
  Object.keys(byCode).forEach(function (c) {
    var arr = byCode[c].map(function (x) { return x.v; }).sort(function (a, b) { return a - b; });
    var med = arr[Math.floor(arr.length / 2)];
    if (med >= THRESHOLD) { bad.push({ code: c, median: med, rows: byCode[c] }); }
  });

  Logger.log('掃描 ' + Object.keys(byCode).length + ' 檔，判定量沒換算的有 ' + bad.length + ' 檔');
  bad.slice(0, 40).forEach(function (b) {
    Logger.log('  ' + b.code + '　中位數 ' + b.median.toLocaleString() +
               '　共 ' + b.rows.length + ' 列');
  });
  if (bad.length > 40) { Logger.log('  ……另有 ' + (bad.length - 40) + ' 檔'); }

  if (dryRun) {
    Logger.log('');
    Logger.log('這是乾跑，沒有寫入任何資料。');
    Logger.log('確認名單沒問題後執行 repairDailyKVolume() 真的修。');
    return { stocks: bad.length, dryRun: true };
  }

  // 整欄讀進來改完一次寫回。逐格 setValue 會是幾千次寫入，必爆配額。
  var col = [];
  for (var r = 2; r <= vals.length; r++) { col.push([vals[r - 1][cVol]]); }
  var n = 0;
  bad.forEach(function (b) {
    b.rows.forEach(function (x) {
      col[x.row - 2] = [Math.round(x.v / 1000)];
      n++;
    });
  });
  sh.getRange(2, cVol + 1, col.length, 1).setValues(col);

  CACHE.remove('tracker');
  _DK_INDEX = null;
  Logger.log('');
  Logger.log('已修正 ' + bad.length + ' 檔共 ' + n + ' 列。');
  Logger.log('個股面板的量會在快取過期後更新，想立刻看到就到後台按「只刷新畫面」。');
  return { stocks: bad.length, rows: n };
}


function fugleQuote_(code) {
  var j = fugleFetch_('/intraday/quote/' + encodeURIComponent(code));
  var last = (j.lastPrice != null) ? Number(j.lastPrice)
    : (j.closePrice != null) ? Number(j.closePrice) : null;
  if (last == null) { return null; }

  return {
    code: String(j.symbol || code),
    name: j.name || '',
    last: last,
    prevClose: j.previousClose != null ? Number(j.previousClose) : null,
    open: j.openPrice != null ? Number(j.openPrice) : null,
    high: j.highPrice != null ? Number(j.highPrice) : null,
    low: j.lowPrice != null ? Number(j.lowPrice) : null,
    volume: fugleVolToLots_(j.total && j.total.tradeVolume),
    change: j.change != null ? Number(j.change) : null,
    changePct: j.changePercent != null ? Number(j.changePercent) : null
  };
}

/** 當日 60 分 K。Fugle 只提供當日，歷史部分靠每天收盤落地累積。 */
function fugleHourly_(code) {
  var j = fugleFetch_('/intraday/candles/' + encodeURIComponent(code) + '?timeframe=60');
  return (j.data || []).map(function (r) {
    var d = new Date(r.date);
    return {
      date: Utilities.formatDate(d, TZ, 'yyyy/MM/dd') + ' ' + Utilities.formatDate(d, TZ, 'HH:mm'),
      open: Number(r.open), high: Number(r.high), low: Number(r.low),
      close: Number(r.close), volume: fugleVolToLots_(r.volume)
    };
  }).filter(function (r) { return r.close; });
}

/**
 * 歷史日K。一次拿一檔的完整區間，上市上櫃通吃。
 *
 * 這條路是上櫃股票日K 的唯一來源。櫃買的 st43_result.php 掛在舊站
 * wwwov.tpex.org.tw，該站 2025/05/31 已停用，現在回傳 404。
 * 證交所的 STOCK_DAY 只有上市，而且要逐月抓。
 *
 * 區間自適應：Fugle 方案對歷史回溯有上限，超過就回 400。
 * 實測 46 天可以、730 天不行，而且失敗名單橫跨上市上櫃，
 * 所以那是區間限制不是權限問題。這裡從長的開始試，撞牆就對半砍，
 * 拿到多少算多少。持股追蹤只需要涵蓋首次買入日，通常一個月就夠。
 */
var FUGLE_RANGE_PROP = 'FUGLE_MAX_DAYS';

/** 記住這把金鑰實際能回溯幾天，下一檔直接從這裡開始，不用重試整條階梯 */
function rememberFugleRange_(days) {
  PropertiesService.getScriptProperties().setProperty(FUGLE_RANGE_PROP, String(days));
}
function knownFugleRange_() {
  var v = PropertiesService.getScriptProperties().getProperty(FUGLE_RANGE_PROP);
  return v ? Number(v) : 0;
}

function fugleHistorical_(code, from, to) {
  var days = Math.round((new Date(to) - new Date(from)) / 86400000);

  // 已經知道這把金鑰的上限就直接用，不要每一檔都重跑一次階梯。
  // 實測 72 檔各試 730 -> 365 -> 180 要花 4.7 分鐘，其中 3.3 分鐘純粹浪費在
  // 重複撞同一堵牆。記住之後只要 1.4 分鐘。
  // 目標區間近十二個月（約 370 個日曆日）。
  //
  // 這個值必須與 CacheBuilder 的 KLINE_MONTHS 對應。兩邊不一致時不會報錯，
  // 只會安靜地拿到比預期短的資料——先前 KLINE_MONTHS 要一年、這裡卻卡在
  // 半年，圖上就少了一半，而且完全看不出原因。
  //
  // 若呼叫端要的區間比一年短，就照它的，不要多抓。
  var TARGET_DAYS = 370;
  var want = Math.min(days, TARGET_DAYS);

  // 階梯是為了應付金鑰額度不同：先要完整區間，被拒就逐級退讓。
  var known = knownFugleRange_();
  var ladder = [want, 370, 270, 180, 90, 45];
  if (known) { ladder = [Math.min(known, want), 180, 90, 45]; }

  var tries = ladder.filter(function (d, i, a) {
    return d > 0 && d <= days && a.indexOf(d) === i;
  });

  var lastErr = null;
  for (var i = 0; i < tries.length; i++) {
    var f = new Date(to);
    f.setDate(f.getDate() - tries[i]);
    var fromStr = Utilities.formatDate(f, TZ, 'yyyy-MM-dd');

    try {
      var rows = fugleHistoricalOnce_(code, fromStr, to);
      if (rows.length) {
        if (!known || tries[i] < known) { rememberFugleRange_(tries[i]); }
        if (i > 0 && !known) {
          Logger.log('    這把金鑰的回溯上限是 ' + tries[i] + ' 天（' + fromStr +
                     ' 起），已記住，後續代號直接用這個區間。');
        }
        return rows;
      }
      lastErr = new Error('回傳 0 根');
    } catch (e) {
      lastErr = e;
      // 400 才值得縮短區間再試。401 403 429 縮了也沒用。
      if (e.httpCode && e.httpCode !== 400) { throw e; }
      Utilities.sleep(300);
    }
  }
  throw lastErr || new Error('取不到資料');
}

function fugleHistoricalOnce_(code, from, to) {
  var j = fugleFetch_('/historical/candles/' + encodeURIComponent(code) +
    '?from=' + from + '&to=' + to + '&fields=open,high,low,close,volume');

  return (j.data || []).map(function (r) {
    return {
      date: String(r.date).replace(/-/g, '/'),
      open: Number(r.open), high: Number(r.high),
      low: Number(r.low), close: Number(r.close),
      volume: fugleVolToLots_(r.volume)
    };
  }).filter(function (r) {
    return r.close && r.date;
  }).sort(function (a, b) {
    return a.date < b.date ? -1 : 1;
  });
}

/* ------------------------------------------------------------------ *
 * 即時快取
 * 盤中每 5 分鐘更新一次寫進試算表。前端直接讀，不對外請求。
 * ------------------------------------------------------------------ */

function isTradingNow_() {
  var now = new Date();
  var dow = now.getDay();
  if (dow === 0 || dow === 6) { return false; }
  var hhmm = Number(Utilities.formatDate(now, TZ, 'HHmm'));
  return hhmm >= 900 && hhmm <= 1340;
}

function refreshQuoteCacheJob() {
  if (!isTradingNow_()) { return; }

  var codes = trackedCodes_();
  if (!codes.length) { return; }

  var map = loadCodeMap_().byCode;
  // 帶秒。盤中每幾分鐘更新一次，只到分的話連兩次抓的時間看起來一樣，
  // 分不出「這個價剛更新」還是「已經停在這裡好幾分鐘了」。
  var stamp = Utilities.formatDate(new Date(), TZ, 'yyyy/MM/dd HH:mm:ss');
  var rows = [];

  codes.forEach(function (code) {
    var q = null;
    if (hasFugle_()) {
      try { q = fugleQuote_(code); } catch (e) { q = null; }
    }
    if (!q) {
      try { q = misQuote_(code); } catch (e) { q = null; }
    }
    if (!q || q.last == null) { return; }

    var chg = q.change;
    var pct = q.changePct;
    if (chg == null && q.prevClose) { chg = q.last - q.prevClose; }
    if (pct == null && q.prevClose) { pct = (q.last - q.prevClose) / q.prevClose * 100; }

    rows.push([
      code,
      q.name || (map[code] ? map[code].name : ''),
      q.last,
      q.prevClose || '',
      chg != null ? Math.round(chg * 100) / 100 : '',
      pct != null ? Math.round(pct * 100) / 100 : '',
      q.volume || 0,
      stamp
    ]);
  });

  if (!rows.length) { return; }

  withLock_(function () {
    var sh = getSheet_('即時快取');
    sh.clearContents();
    sh.getRange(1, 1, 1, 8).setValues([['代號', '名稱', '現價', '昨收', '漲跌', '漲跌幅', '成交量', '更新時間']]);
    sh.getRange(2, 1, rows.length, 8).setValues(rows);
  });

  CACHE.remove('qcache');
}

/* 報價時間一律轉成「MM-dd HH:mm:ss」（台北時間）。

   問題長這樣：前端印出「2026-09-04T05:38:00.000Z」。
   試算表把「2026/09/04 13:38」這種字串存成日期值，readSheetObjects_ 讀回來
   是 Date 物件，google.script.run 再把它序列化成 ISO 字串送到瀏覽器——
   於是變成 UTC、帶毫秒、還少了八小時。

   看盤的人要的是「這個價是幾點的」。年份、毫秒、時區標記都不是答案的一部分，
   而時區錯八小時會讓人以為報價是早上抓的。

   轉換放在讀出的那一刻，不是放在前端：前端只是其中一個消費者，
   狀態信、AI 助手的上下文都會讀到同一個欄位。 */
function qTime_(v) {
  if (v == null || v === '') { return ''; }

  if (Object.prototype.toString.call(v) === '[object Date]') {
    return Utilities.formatDate(v, TZ, 'MM-dd HH:mm:ss');
  }

  var t = String(v).trim();

  // 已經被序列化成 ISO 的（舊快取、或別處直接塞了 toISOString）
  if (/^\d{4}-\d{2}-\d{2}T/.test(t)) {
    var d = new Date(t);
    if (!isNaN(d.getTime())) { return Utilities.formatDate(d, TZ, 'MM-dd HH:mm:ss'); }
  }

  // 「2026/09/04 13:38」→「09-04 13:38:00」
  var m = t.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})[ T](\d{1,2}):(\d{2})(?::(\d{2}))?/);
  if (m) {
    return pad2_(m[2]) + '-' + pad2_(m[3]) + ' ' +
           pad2_(m[4]) + ':' + m[5] + ':' + (m[6] || '00');
  }

  // 「2026/09/03 收盤」→「09-03 收盤」
  var m2 = t.match(/^(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})\s*(.*)$/);
  if (m2) {
    return pad2_(m2[2]) + '-' + pad2_(m2[3]) + (m2[4] ? ' ' + m2[4] : '');
  }

  return t;   // 「即時」這類文字原樣留著
}

function pad2_(v) { return ('0' + String(v)).slice(-2); }

/** 讀即時快取。這是前端表格現價的來源。 */
function getQuoteCache() {
  var hit = CACHE.get('qcache');
  if (hit) { return JSON.parse(hit); }

  var out = {};
  readSheetObjects_('即時快取').forEach(function (r) {
    var c = String(r['代號']).trim();
    if (!c) { return; }
    out[c] = {
      name: r['名稱'], last: Number(r['現價']) || null,
      prevClose: Number(r['昨收']) || null,
      change: r['漲跌'] === '' ? null : Number(r['漲跌']),
      changePct: r['漲跌幅'] === '' ? null : Number(r['漲跌幅']),
      volume: Number(r['成交量']) || 0,
      time: qTime_(r['更新時間'])
    };
  });

  CACHE.put('qcache', JSON.stringify(out), 120);
  return out;
}

/**
 * 前端要的批次報價。先讀快取，快取沒有的補抓。
 *
 * 先前這裡寫了 missing.slice(0, 10)，只補抓十檔。追蹤清單有七十幾檔，
 * 而 refreshQuoteCacheJob 只在 09:00 到 13:40 執行，所以盤後或假日
 * 快取是空的，七十幾檔只有十檔拿得到價格。
 *
 * 更糟的是這會污染平均報酬：沒有現價的標的 ret 是 null 而被排除，
 * 平均值其實只用那十檔算出來，卻標示成全部。所以上限拿掉，
 * 並且缺價的用日K快取的最後一根收盤價補，這樣至少每一檔都有數字。
 */
function getQuotesFor(codes) {
  var cache = getQuoteCache();
  var out = {}, missing = [];

  (codes || []).forEach(function (c) {
    c = String(c).trim();
    if (!/^\d{4,6}$/.test(c)) { return; }
    if (cache[c]) { out[c] = cache[c]; } else { missing.push(c); }
  });

  if (!missing.length) { return out; }

  // 盤中才值得為了即時性逐檔對外請求。盤後直接用日K快取的最後收盤價，
  // 那本來就是正確答案，而且不花任何請求。
  if (!isTradingNow_()) {
    missing.forEach(function (c) {
      var k = getCachedDailyK(c);
      if (!k.length) { return; }
      var last = k[k.length - 1];
      var prev = k.length > 1 ? k[k.length - 2] : null;
      var chg = prev ? last.close - prev.close : null;
      out[c] = {
        name: '', last: last.close, prevClose: prev ? prev.close : null,
        change: chg != null ? Math.round(chg * 100) / 100 : null,
        changePct: (chg != null && prev.close) ? Math.round(chg / prev.close * 10000) / 100 : null,
        volume: last.volume, time: qTime_(last.date + ' 收盤')
      };
    });
    return out;
  }

  // 盤中：逐檔補抓。Fugle 日內行情 60 次/分，所以每次最多 50 檔，留餘裕。
  var fetched = 0;
  for (var i = 0; i < missing.length && fetched < 50; i++) {
    var c = missing[i];
    var q = null;
    if (hasFugle_()) { try { q = fugleQuote_(c); } catch (e) { q = null; } }
    if (!q) { try { q = misQuote_(c); } catch (e) { q = null; } }

    if (!q) {
      // 對外也拿不到就退回日K最後一根，總比顯示破折號好
      var k = getCachedDailyK(c);
      if (k.length) {
        var l = k[k.length - 1];
        out[c] = { name: '', last: l.close, prevClose: null, change: null,
                   changePct: null, volume: l.volume,
                   time: qTime_(l.date + ' 收盤') };
      }
      continue;
    }
    fetched++;

    var chg = q.change, pct = q.changePct;
    if (chg == null && q.prevClose) { chg = q.last - q.prevClose; }
    if (pct == null && q.prevClose) { pct = (q.last - q.prevClose) / q.prevClose * 100; }

    out[c] = {
      name: q.name, last: q.last, prevClose: q.prevClose,
      change: chg != null ? Math.round(chg * 100) / 100 : null,
      changePct: pct != null ? Math.round(pct * 100) / 100 : null,
      volume: q.volume, time: '即時'
    };
    Utilities.sleep(1100);
  }

  // 逐檔補抓有 50 檔上限（對外請求速率限制）。
  // 先前超過上限的那些會直接被跳過，連日K收盤價都沒有，
  // 前端就顯示破折號。這裡把所有還沒有值的補上收盤價。
  missing.forEach(function (c) {
    if (out[c]) { return; }
    var lc = lastCloseOf_(c);
    if (!lc) { return; }
    var chg = lc.prevClose ? lc.last - lc.prevClose : null;
    out[c] = {
      name: '', last: lc.last, prevClose: lc.prevClose,
      change: chg != null ? Math.round(chg * 100) / 100 : null,
      changePct: (chg != null && lc.prevClose) ? Math.round(chg / lc.prevClose * 10000) / 100 : null,
      volume: lc.volume, time: qTime_(lc.date + ' 收盤')
    };
  });

  return out;
}

/* ------------------------------------------------------------------ *
 * 證交所 MIS 備援
 * 沒有 Fugle 金鑰、或 Fugle 出錯時走這裡。
 * 有每 5 秒 3 次的限制，所以只當備援，不當主力。
 * ------------------------------------------------------------------ */

function throttleMis_() {
  var lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    var now = Date.now();
    var raw = CACHE.get('mis_calls');
    var calls = raw ? JSON.parse(raw) : [];
    calls = calls.filter(function (t) { return now - t < 5000; });
    if (calls.length >= 3) {
      Utilities.sleep(Math.max(5000 - (now - calls[0]) + 120, 200));
      now = Date.now();
      calls = calls.filter(function (t) { return now - t < 5000; });
    }
    calls.push(now);
    CACHE.put('mis_calls', JSON.stringify(calls), 30);
  } finally {
    lock.releaseLock();
  }
}

function misQuote_(code) {
  var map = loadCodeMap_().byCode;
  // 對照表市場別可能分類錯或缺（KY 股、剛上市櫃、上市轉上櫃等），
  // 前綴一錯 MIS 就回空。所以先猜一個，抓不到再換另一個市場前綴試一次。
  var first = (map[code] && map[code].market === '上櫃') ? 'otc' : 'tse';
  var second = first === 'otc' ? 'tse' : 'otc';
  return misOnce_(code, first, map) || misOnce_(code, second, map);
}

function misOnce_(code, market, map) {
  throttleMis_();
  var url = 'https://mis.twse.com.tw/stock/api/getStockInfo.jsp?ex_ch=' +
    encodeURIComponent(market + '_' + code + '.tw') + '&json=1&delay=0&_=' + Date.now();

  var res = UrlFetchApp.fetch(url, {
    muteHttpExceptions: true,
    headers: { 'Referer': 'https://mis.twse.com.tw/stock/index.jsp' }
  });

  var data;
  try { data = JSON.parse(res.getContentText()); } catch (e) { return null; }
  if (!data || !data.msgArray || !data.msgArray.length) { return null; }

  var m = data.msgArray[0];
  var last = parseFloat(m.z);
  if (isNaN(last)) { last = parseFloat(m.b ? m.b.split('_')[0] : NaN); }
  if (isNaN(last)) { last = parseFloat(m.y); }
  if (isNaN(last)) { return null; }

  var prev = parseFloat(m.y);
  return {
    code: code, name: m.n || (map[code] ? map[code].name : ''),
    last: last, prevClose: isNaN(prev) ? null : prev,
    open: parseFloat(m.o) || null, high: parseFloat(m.h) || null, low: parseFloat(m.l) || null,
    volume: parseInt(m.v, 10) || 0, change: null, changePct: null
  };
}

/** 單檔即時報價 */
function getRealtimeQuote(code) {
  code = String(code || '').trim();
  if (!code) { return null; }

  var q = getQuotesFor([code])[code];
  if (!q) { return { code: code, ok: false, message: '目前取不到這檔股票的報價。' }; }

  var map = loadCodeMap_().byCode;
  return {
    code: code, ok: true,
    name: q.name || (map[code] ? map[code].name : code),
    last: q.last, prevClose: q.prevClose,
    change: q.change, changePct: q.changePct,
    volume: q.volume, time: q.time,
    market: (map[code] && map[code].market) || ''
  };
}

/* ------------------------------------------------------------------ *
 * 代號建議
 * ------------------------------------------------------------------ */
function getCodeMap_() {
  var m = loadCodeMap_().byCode;
  var out = {};
  Object.keys(m).forEach(function (c) {
    out[c] = { name: m[c].name, market: m[c].market === '上櫃' ? 'otc' : 'tse' };
  });
  return out;
}

function suggestCodes(keyword) {
  var kw = String(keyword || '').trim();
  if (!kw) { return []; }

  var m = loadCodeMap_().byCode;
  var out = [];
  var codes = Object.keys(m);

  for (var i = 0; i < codes.length && out.length < 12; i++) {
    var c = codes[i];
    if (c.indexOf(kw) === 0 || m[c].name.indexOf(kw) >= 0) {
      out.push({ code: c, name: m[c].name, market: m[c].market });
    }
  }
  return out;
}

/* ------------------------------------------------------------------ *
 * K 線
 * ------------------------------------------------------------------ */

/**
 * period：'hour' | 'day' | 'week' | 'month'
 *
 * hour  已落地的歷史 60 分 K，加上 Fugle 提供的當日部分。
 * day   讀日K快取。快取由 backfillDailyKJob 每日補，涵蓋 24 個月。
 * week  由日K聚合。
 * month 由日K聚合。網站的個股面板已經不提供月K了（只留日與週），
 *       但這一支是公開 API，這個分支保留著。
 *       拿掉的話 period='month' 會掉到最後一行回傳日K——
 *       那不是壞掉，是安靜地回錯資料，比直接不支援糟得多。
 */
function getCandles(code, period) {
  code = String(code || '').trim();

  if (period === 'hour') {
    var hist = getHourlyCandles_(code);
    if (hasFugle_()) {
      try {
        var today = fugleHourly_(code);
        var seen = {};
        hist.forEach(function (r) { seen[r.date] = 1; });
        today.forEach(function (r) { if (!seen[r.date]) { hist.push(r); } });
        hist.sort(function (a, b) { return a.date < b.date ? -1 : 1; });
      } catch (e) { /* Fugle 取不到就只顯示已落地的部分 */ }
    }
    return hist;
  }

  var daily = getCachedDailyK(code);
  if (period === 'week') { return aggregate_(daily, 'week'); }
  if (period === 'month') { return aggregate_(daily, 'month'); }
  return daily;
}

/** 已落地的 60 分 K。與日K同理，整張表只讀一次並建索引。 */
var _HK_INDEX = null;

function loadAllHourly_() {
  if (_HK_INDEX) { return _HK_INDEX; }
  var map = {};
  readSheetObjects_('小時K').forEach(function (r) {
    var c = String(r['代號']).trim();
    if (!c) { return; }
    if (!map[c]) { map[c] = []; }
    map[c].push({
      date: fmtDate_(r['日期']) + ' ' + String(r['時段']),
      open: Number(r['開']), high: Number(r['高']),
      low: Number(r['低']), close: Number(r['收']), volume: Number(r['量'])
    });
  });
  Object.keys(map).forEach(function (c) {
    map[c].sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : 0; });
  });
  _HK_INDEX = map;
  return map;
}

function getHourlyCandles_(code) {
  code = String(code || '').trim();
  return loadAllHourly_()[code] || [];
}

/** 14:05 觸發。把當日 60 分 K 從 Fugle 抓下來落地。 */
function aggregateHourlyJob() {
  if (!hasFugle_()) {
    Logger.log('尚未設定 FUGLE_API_KEY，跳過 60 分 K 落地。');
    return;
  }

  var today = todayStr_();
  var codes = trackedCodes_();
  if (!codes.length) { return; }

  var have = {};
  readSheetObjects_('小時K').forEach(function (r) {
    have[String(r['代號']) + '|' + fmtDate_(r['日期']) + '|' + String(r['時段'])] = 1;
  });

  var rows = [];
  codes.forEach(function (code) {
    try {
      fugleHourly_(code).forEach(function (b) {
        var parts = b.date.split(' ');
        if (parts[0] !== today) { return; }
        if (have[code + '|' + parts[0] + '|' + parts[1]]) { return; }
        rows.push([parts[0], parts[1], code, b.open, b.high, b.low, b.close, b.volume]);
      });
    } catch (e) { /* 單檔失敗不影響其他 */ }
    Utilities.sleep(1100);   // Fugle 日內行情 60 次/分
  });

  if (!rows.length) { Logger.log('今日無新的 60 分 K'); return; }

  withLock_(function () {
    var sh = getSheet_('小時K');
    sh.getRange(sh.getLastRow() + 1, 1, rows.length, 8).setValues(rows);
  });

  CACHE.remove('hk_meta');
  Logger.log('落地 ' + rows.length + ' 根 60 分 K');
}

function getHourlyMeta() {
  var hit = CACHE.get('hk_meta');
  if (hit) { return JSON.parse(hit); }

  var rows = readSheetObjects_('小時K');
  var dates = rows.map(function (r) { return fmtDate_(r['日期']); }).filter(String).sort();
  var meta = {
    since: dates.length ? dates[0] : '',
    until: dates.length ? dates[dates.length - 1] : '',
    days: dates.filter(function (v, i, a) { return a.indexOf(v) === i; }).length,
    bars: rows.length,
    hasFugle: hasFugle_()
  };
  CACHE.put('hk_meta', JSON.stringify(meta), 1800);
  return meta;
}

/** 日 K 聚合為週 K 或月 K */
function aggregate_(daily, unit) {
  var buckets = {};
  daily.forEach(function (r) {
    var key;
    if (unit === 'month') {
      key = r.date.slice(0, 7);
    } else {
      var d = new Date(r.date);
      var day = d.getDay() === 0 ? 7 : d.getDay();
      d.setDate(d.getDate() - day + 1);
      key = Utilities.formatDate(d, TZ, 'yyyy/MM/dd');
    }
    if (!buckets[key]) {
      buckets[key] = { date: r.date, open: r.open, high: r.high, low: r.low, close: r.close, volume: r.volume };
    } else {
      var b = buckets[key];
      b.high = Math.max(b.high, r.high);
      b.low = Math.min(b.low, r.low);
      b.close = r.close;
      b.volume += r.volume;
      b.date = r.date;
    }
  });
  return Object.keys(buckets).sort().map(function (k) { return buckets[k]; });
}

/* ------------------------------------------------------------------ *
 * 基本面
 * ------------------------------------------------------------------ */

function getValuationTable_() {
  var hit = CACHE.get('val_tbl');
  if (hit) { return JSON.parse(hit); }

  var map = {};

  try {
    fetchJson_('https://openapi.twse.com.tw/v1/exchangeReport/BWIBBU_ALL').forEach(function (r) {
      var c = pickField_(r, ['Code', '證券代號']);
      if (!c) { return; }
      map[c] = {
        per: parseFloat(pickField_(r, ['PEratio', '本益比'])) || null,
        pbr: parseFloat(pickField_(r, ['PBratio', '股價淨值比'])) || null,
        yld: parseFloat(pickField_(r, ['DividendYield', '殖利率(%)'])) || null
      };
    });
  } catch (e) {
    Logger.log('上市估值表取得失敗：' + e.message + '。本益比等欄位會顯示未提供。');
  }

  try {
    fetchJson_('https://www.tpex.org.tw/openapi/v1/tpex_mainboard_peratio_analysis').forEach(function (r) {
      var c = pickField_(r, ['SecuritiesCompanyCode', 'Code']);
      if (!c) { return; }
      map[c] = {
        per: parseFloat(pickField_(r, ['PriceEarningRatio', 'PERatio'])) || null,
        pbr: parseFloat(pickField_(r, ['PriceBookRatio', 'PBRatio'])) || null,
        yld: parseFloat(pickField_(r, ['YieldRatio', 'DividendYield'])) || null
      };
    });
  } catch (e) {
    Logger.log('上櫃估值表取得失敗：' + e.message + '。上櫃股票的本益比等欄位會顯示未提供。');
  }

  if (Object.keys(map).length) {
    var p = JSON.stringify(map);
    if (p.length < 95000) { CACHE.put('val_tbl', p, 21600); }
  }
  return map;
}

function getProfileTable_() {
  var hit = CACHE.get('prof_tbl');
  if (hit) { return JSON.parse(hit); }

  var map = {};

  // 公司基本資料與對照表同源，直接沿用 trySources_，一個死了自動換下一個
  [{ src: LISTED_SOURCES, mk: '上市' }, { src: OTC_SOURCES, mk: '上櫃' }].forEach(function (cfg) {
    for (var i = 0; i < cfg.src.length; i++) {
      var s = cfg.src[i];
      try {
        var raw = (s.type === 'csv') ? fetchCsv_(s.url) : fetchJson_(s.url);
        raw.forEach(function (r) {
          var c = pickField_(r, s.code);
          if (!/^\d{4,6}$/.test(c)) { return; }
          map[c] = {
            full: pickField_(r, ['公司名稱', 'CompanyName']),
            industry: pickField_(r, s.industry),
            listed: pickField_(r, ['上市日期', '上櫃日期', 'ListingDate']),
            chairman: pickField_(r, ['董事長', 'Chairman'])
          };
        });
        break;
      } catch (e) { /* 換下一個來源 */ }
    }
  });

  if (Object.keys(map).length) {
    var p = JSON.stringify(map);
    if (p.length < 95000) { CACHE.put('prof_tbl', p, 21600); }
  }
  return map;
}

/**
 * 每日 14:30 觸發。把追蹤清單的基本面抓下來落地。
 *
 * 存在理由：先前每次開個股面板都現抓 BWIBBU_ALL 加 t187ap03_L 共兩千筆，
 * 快取一過期就要等好幾秒，整個面板卡在「讀取中」。改成每天算一次存起來。
 */
function rebuildFundamentalsJob() {
  var codes = trackedCodes_();
  if (!codes.length) { Logger.log('沒有追蹤中的代號，略過'); return; }

  var val = getValuationTable_();
  var prof = getProfileTable_();
  var map = loadCodeMap_().byCode;
  var now = todayStr_();

  var rows = codes.sort().map(function (c) {
    var v = val[c] || {}, p = prof[c] || {}, m = map[c] || {};
    return [
      c, m.name || '', m.market || '', p.industry || m.industry || '',
      v.per || '', v.pbr || '', v.yld || '',
      p.listed || '', p.chairman || '', now
    ];
  });

  withLock_(function () {
    var sh = getSheet_('基本面快取');
    sh.clearContents();
    sh.getRange(1, 1, 1, 10).setValues([['代號', '名稱', '市場', '產業', '本益比',
      '股價淨值比', '殖利率', '上市櫃日', '董事長', '更新時間']]);
    sh.getRange(2, 1, rows.length, 10).setValues(rows);
  });

  CACHE.remove('fund_cache');

  var withVal = rows.filter(function (r) { return r[4] !== ''; }).length;
  Logger.log('基本面快取更新：' + rows.length + ' 檔，其中 ' + withVal + ' 檔有估值資料');
  if (withVal < rows.length) {
    Logger.log('沒有估值的多半是上櫃股。若上櫃全部沒有，執行 probeEndpoints() 看櫃買端點是否改版。');
  }
}

function loadFundCache_() {
  var hit = CACHE.get('fund_cache');
  if (hit) { return JSON.parse(hit); }

  var out = {};
  readSheetObjects_('基本面快取').forEach(function (r) {
    var c = String(r['代號']).trim();
    if (!c) { return; }
    out[c] = {
      name: r['名稱'], market: r['市場'], industry: industryName_(r['產業']),
      per: Number(r['本益比']) || null, pbr: Number(r['股價淨值比']) || null,
      yld: Number(r['殖利率']) || null,
      listed: listedDate_(r['上市櫃日']), chairman: r['董事長'], updated: r['更新時間']
    };
  });

  var p = JSON.stringify(out);
  if (p.length < 95000) { CACHE.put('fund_cache', p, 3600); }
  return out;
}

/* ------------------------------------------------------------------ *
 * 基本面欄位的顯示轉換
 *
 * 兩個欄位是直接把來源的原始值搬到畫面上的：
 *   產業別   證交所的公司基本資料回的是代碼，畫面上就出現一個「22」
 *   上市櫃日 回的是「20191007」這種連在一起的八碼
 *
 * 轉換放在讀出的那一刻，不是放在抓取的那一刻——已經落地在快取分頁裡的
 * 幾十列舊資料也要跟著變乾淨，否則得等下一次重抓才會對。
 * ------------------------------------------------------------------ */

/* 證交所與櫃買中心的產業別代碼。兩邊共用同一套編碼。
   查不到的代碼原樣顯示，不要吞掉——那代表這份表該補了，
   顯示成空白只會讓人以為那一檔沒有產業別。 */
var INDUSTRY_CODES_ = {
  '01': '水泥工業', '02': '食品工業', '03': '塑膠工業', '04': '紡織纖維',
  '05': '電機機械', '06': '電器電纜', '07': '化學生技醫療', '08': '玻璃陶瓷',
  '09': '造紙工業', '10': '鋼鐵工業', '11': '橡膠工業', '12': '汽車工業',
  '13': '電子工業', '14': '建材營造', '15': '航運業', '16': '觀光餐旅',
  '17': '金融保險', '18': '貿易百貨', '19': '綜合', '20': '其他',
  '21': '化學工業', '22': '生技醫療業', '23': '油電燃氣業', '24': '半導體業',
  '25': '電腦及週邊設備業', '26': '光電業', '27': '通信網路業',
  '28': '電子零組件業', '29': '電子通路業', '30': '資訊服務業',
  '31': '其他電子業', '32': '文化創意業', '33': '農業科技業',
  '34': '電子商務', '35': '綠能環保', '36': '數位雲端', '37': '運動休閒',
  '38': '居家生活', '80': '管理股票', '97': '存託憑證', '98': '受益證券',
  '99': 'ETF'
};

/** 「22」→「生技醫療業」。本來就是中文的原樣返回。 */
function industryName_(v) {
  var t = String(v == null ? '' : v).trim();
  if (!t) { return ''; }
  if (!/^\d{1,2}$/.test(t)) { return t; }      // 已經是中文
  return INDUSTRY_CODES_[('0' + t).slice(-2)] || t;
}

/** 「20191007」→「2019/10/07」。已經有分隔符號或看不懂的原樣返回。 */
function listedDate_(v) {
  var t = String(v == null ? '' : v).trim();
  if (!t) { return ''; }
  var m = t.match(/^(\d{4})(\d{2})(\d{2})$/);
  if (m) { return m[1] + '/' + m[2] + '/' + m[3]; }
  // 民國年：「1081007」這種七碼
  var r = t.match(/^(\d{3})(\d{2})(\d{2})$/);
  if (r) { return (Number(r[1]) + 1911) + '/' + r[2] + '/' + r[3]; }
  return t.replace(/-/g, '/');
}

/**
 * 個股基本面。先讀落地快取，沒有才現抓。取不到的欄位一律 null，
 * 前端顯示「未提供」，不編數字。
 */
function getFundamentals(code) {
  code = String(code || '').trim();
  var m = loadCodeMap_().byCode[code] || {};

  var f = loadFundCache_()[code];
  if (f) {
    return {
      code: code, name: f.name || m.name || '', market: f.market || m.market || '',
      per: f.per, pbr: f.pbr, yld: f.yld,
      industry: f.industry || '', listed: f.listed || '', chairman: f.chairman || '',
      cached: true,
      source: '本益比、股價淨值比、殖利率來自證交所與櫃買中心公開資料，更新於 ' + (f.updated || '未知') + '。'
    };
  }

  // 追蹤清單以外的冷門股，現抓一次
  var v = getValuationTable_()[code] || {};
  var p = getProfileTable_()[code] || {};
  return {
    code: code, name: m.name || '', market: m.market || '',
    per: v.per || null, pbr: v.pbr || null, yld: v.yld || null,
    industry: industryName_(p.industry || m.industry || ''),
    listed: listedDate_(p.listed || ''), chairman: p.chairman || '',
    cached: false,
    source: '本益比、股價淨值比、殖利率來自證交所與櫃買中心公開資料，為前一交易日數值。'
  };
}