/**
 * 張震股市盤中家教班 逐日追蹤網站
 * 檔案：Code.gs（主入口）
 *
 * 對應規格：01_AI開發指令與功能規格書 v3，二、2 節（GAS + HTML Service 前端與資料服務層）
 *
 * 本檔負責：
 *   1. doGet 路由：正常開啟網站、以及取消訂閱連結的處理
 *   2. HTML 檔案 include 機制
 *   3. 前端可呼叫的公開 API 收斂在此，實作分散於各 Service 檔
 *
 * 金鑰規範（規格書第八節）：
 *   本檔與所有 .gs 檔案皆不得出現任何金鑰明碼。
 *   GEMINI_API_KEY 一律存放於 Script Properties，僅後端讀取。
 */

/** 網站標題與固定文案 */
var APP_TITLE = '張震股市盤中家教班　逐日追蹤';
var DISCLAIMER = '本站內容僅整理影片中明確講述的內容，不構成任何投資建議，投資決策與盈虧由使用者自行負責。';

/**
 * 網頁進入點。
 * 支援 ?action=unsubscribe&email=...&token=... 取消訂閱（規格書 4.5 節）
 */
function doGet(e) {
  var params = (e && e.parameter) ? e.parameter : {};

  if (params.action === 'unsubscribe') {
    var result = unsubscribeByToken(params.email, params.token);
    return renderUnsubscribePage_(result);
  }

  /**
   * 遠端刷新入口：?action=refresh&key=ADMIN_KEY
   *
   * 存在的理由：上游 GitHub 改的是試算表，下游 Apps Script 才把試算表算成
   * 網站看到的樣子。少了這個入口，在 GitHub 手動整理完資料之後，
   * 還得自己再去 Apps Script 按一次執行，或乾脆等下一個交易日的排程。
   * 有了它，pipeline.py 跑完可以直接打這一支，資料整理與網站更新一次到底。
   *
   * 一定要帶對 ADMIN_KEY。沒有密鑰的人打這個網址只會拿到 401，
   * 不會觸發任何運算，也不會洩漏任何內容。
   * 回傳純 JSON 而不是網頁，方便 workflow 直接判讀結果。
   */
  /**
   * 最小診斷端點。?action=ping
   *
   * 它什麼都不做，只回一段固定的 JSON，不碰試算表、不連外、不寄信、
   * 不建觸發器——也就是不需要任何額外授權。
   *
   * 用途是把問題一刀切開：
   *   ping 回 JSON、refresh 回錯誤頁 → 程式碼跑得動，是 refresh 那條鏈出錯
   *   ping 也回錯誤頁               → 程式碼根本沒被執行，
   *                                   問題出在授權或部署，try/catch 接不到
   *
   * 之所以需要這個，是因為授權不足時 Apps Script 會在執行你的程式之前
   * 就回錯誤頁，看起來和程式內部出錯一模一樣，光看回應分不出來。
   */
  if (params.action === 'ping') {
    return jsonOut_({
      ok: true, pong: true,
      time: Utilities.formatDate(new Date(), 'Asia/Taipei', 'yyyy/MM/dd HH:mm:ss'),
      // 版本標記與支援的能力。
      //
      // 存在的理由：貼了新程式碼但沒有部署新版本，是這個專案最常見的坑，
      // 而且症狀常常偽裝成別的問題——舊版收到它不認得的參數會直接忽略，
      // 照著舊邏輯跑，於是回應看起來像超時或當機，跟版本沒對上完全看不出關係。
      // 呼叫端先問一次 ping，就能在動手之前確認雙方版本是否一致。
      build: GAS_BUILD,
      features: GAS_FEATURES,
      steps: Object.keys(REFRESH_STEPS_),
      /* 身分。
       *
       * 「貼了新程式碼卻還是舊版」這件事有三種成因，光看 build 分不出來：
       *   一個專案有多個部署，設定的網址指向的不是你剛更新的那一個
       *   更新時版本沒選「新版本」，於是那個部署仍釘在舊版本
       *   根本有兩份專案，你改的是 A，網址指向 B
       * 把 scriptId 與這個部署自己認得的網址回報出來，三種就分得開：
       * scriptId 與編輯器網址裡那一串不同 → 改錯專案
       * scriptId 相同但 build 是舊的 → 部署或版本沒更新
       */
      scriptId: (function () {
        try { return ScriptApp.getScriptId(); } catch (e) { return '取不到'; }
      })(),
      webAppUrl: (function () {
        try { return ScriptApp.getService().getUrl(); } catch (e) { return '取不到'; }
      })(),
      note: '能看到這段就代表程式碼跑得動。請比對 build 與 features 是否為預期版本。'
    });
  }

  if (params.action === 'refresh') {
    // 包起來回傳 JSON。不包的話，任何例外都會變成 Apps Script 的通用錯誤頁，
    // 呼叫端只會看到一坨 HTML，看不出真正的原因——實際踩過，
    // 授權不足時就是這樣，訊息卻被誤判成「部署版本太舊」。
    try {
      // step 參數把整條鏈拆成獨立的請求。
      //
      // 為什麼一定要拆：整條重算鏈（清產業、代號比對、基本面、補日K、
      // 持股追蹤、績效）跑完遠超過 6 分鐘，而網頁請求超過就會被直接砍掉。
      // 那不是拋例外，是執行被中止，所以 try/catch 接不到，
      // 呼叫端只會拿到一張看不出原因的錯誤頁——先前查了很久就是卡在這裡。
      //
      // 拆開之後每一步都是獨立請求，各自享有完整的時間額度，
      // 呼叫端依序打六次即可，而且每一步的成敗都看得到。
      return jsonOut_(apiRefreshStep_(params.key || '', params.step || 'all', params.date || '', params));
    } catch (err) {
      return jsonOut_({
        ok: false,
        error: String(err && err.message || err),
        hint: '若訊息提到授權或 Authorization，請到 Apps Script 編輯器手動執行一次任一函式並允許新權限，再重新部署新版本。'
      });
    }
  }

  /**
   * 後台：手動投稿逐字稿。網址 ?page=admin
   *
   * 這一頁本身不含任何機密，也不會顯示任何資料——所有內容都要先通過
   * apiAdminLogin 驗證管理密鑰才拿得到。所以直接讓它可以開啟是安全的，
   * 沒有密鑰的人只會看到一個登入框。
   * 加 noindex 是不希望它被搜尋引擎收錄。
   */
  if (params.page === 'admin') {
    try {
      // 用 Template 而不是 HtmlOutput，才能把網頁應用程式的絕對網址注入進去。
      // 後台頁面裡的「回首頁」連結需要它：沙箱 iframe 內的相對網址
      // 會指向 googleusercontent.com，那不是進入點，點了只會得到空白頁。
      var at = HtmlService.createTemplateFromFile('Admin');
      at.webAppUrl = ScriptApp.getService().getUrl();
      return at.evaluate()
        .setTitle('後台　手動投稿')
        // viewport 要與前台逐字相同。少了 viewport-fit=cover，有瀏海的機型
        // 左右會多出一條空白，前後台一比就看得出不是同一個站。
        .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover')
        // 一定要 ALLOWALL，不能用 DEFAULT。
        //
        // Apps Script 不會直接把你的 HTML 交給瀏覽器，而是包進一層位於
        // googleusercontent.com 的巢狀 iframe（網址會變成 userCodeAppPanel）。
        // DEFAULT 會送出限制 framing 的標頭，瀏覽器就把那層 iframe 擋掉，
        // 結果是網址正常、標題正常，但內容區一片空白，主控台也不見得有錯誤。
        // 主網站一直是 ALLOWALL，後台也必須一致。
        .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
    } catch (err) {
      // 檔案不存在或名稱打錯時，給一個看得懂的訊息，而不是又一個空白頁。
      return HtmlService.createHtmlOutput(
        '<div style="font-family:sans-serif;padding:40px;line-height:1.8">' +
        '<h2>後台載入失敗</h2>' +
        '<p>' + String(err).replace(/</g, '&lt;') + '</p>' +
        '<p>請確認 Apps Script 專案裡有一個名為 <b>Admin</b> 的 HTML 檔案' +
        '（新增時選「HTML」，檔名輸入 Admin，不要加副檔名）。</p></div>')
        .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
    }
  }

  var t = HtmlService.createTemplateFromFile('Index');
  t.appTitle = APP_TITLE;
  t.disclaimer = DISCLAIMER;
  t.webAppUrl = ScriptApp.getService().getUrl();

  return t.evaluate()
    .setTitle(APP_TITLE)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

/** 在 HTML 內以 <?!= include('Stylesheet') ?> 引入其他 HTML 檔 */
function include(filename) {
  return HtmlService.createHtmlOutputFromFile(filename).getContent();
}

// 版本標記。每次改動 doGet 的對外行為就要跟著更新，
// 呼叫端用它確認部署的是不是預期的版本。
var GAS_BUILD = '2026-09-10-evidence-v2';

// 這個版本支援的能力。呼叫端據此決定怎麼呼叫，
// 而不是打了才發現對方不認得參數。
var GAS_FEATURES = ['evidence-v2', 'evidence-v1', 'day-edit-sync-v1', 'ping', 'refresh-step', 'admin-page', 'quality-gate', 'full-fix',
                    'chain-state', 'chain-cancel', 'refresh-from', 'fullfix-state',
                    'manual-entry', 'review-rename', 'avoid-provisional', 'autofill-dailyk',
                    'day-edit', 'fullfix-scope',
                    'when-prev', 'trade-seq', 'reason-rewrite', 'shared-settings',
                    'ghost-guard', 'push-diagnostics', 'fine-progress', 'sms-parse', 'sms-detail', 'sms-manage',
                    'sms-checkpoint', 'sms-date-repair', 'natural-reasons', 'sms-sync-progress',
                    'sms-item-verifier', 'sms-direction-column', 'dailyk-safe-chunks',
                    /* 新版會員簡訊：範圍分流（當天／過去空白）、解析版本戳記、
                       配額熔斷與冷卻、逐步落地寫入、逐日稽核後的十三格收錄流程。 */
                    'sms-scope-v6', 'sms-version-stamp', 'sms-quota-cooldown',
                    'sms-incremental-write', 'sms-merge-chunks',
                    /* 資料修正的小工單：同步執行也回報段落進度，可看進度、可取消。 */
                    'fix-job-progress', 'fix-job-cancel',
                    /* 判定歷程與名稱判定紀錄：稽核每一輪做了哪些決定，後台查得到。 */
                    'decision-log', 'name-memo',
                    /* 續跑改成重新派工給 GitHub（先前排的是已退役的觸發器那條路）。 */
                    'resume-via-github', 'job-watchdog', 'step-index-fallback', 'legacy-runner-retired',
                    /* 訂閱管理直接做在頁面上：輸入信箱就列出目前訂了什麼，
                       逐項勾選後儲存，不寄信也不另開頁面。 */
                    'subscription-inline-manage',
                    /* 會員簡訊優先：簡訊的列不交給逐字稿複審，
                       否則複審會因為「逐字稿裡找不到」而把正確的紀錄刪掉。 */
                    'sms-priority-exempt-review',
                    /* 績效歷史可重算，且資料寫入後會自動觸發輕量刷新。 */
                    'perf-history-rebuild', 'auto-refresh-after-write'];

/** 純 JSON 回應，供 GitHub Actions 這類程式呼叫端判讀 */
function jsonOut_(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/**
 * 後台／前台「管理現有訂閱」用：讀出這個信箱目前訂了什麼。
 *
 * 這是依要求做的：直接在介面上查看與勾選，不寄信、不另開頁面。
 * 取捨要寫清楚——少了信箱驗證這一層，任何人輸入別人的 Email 就看得到、
 * 也改得動那個人的訂閱內容。若之後要補回驗證，最小的作法是
 * 送出前先寄一組六位數驗證碼，填對才往下走，不必再回到寄連結那套。
 */
function apiLookupSubscription(email) {
  email = String(email || '').trim();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return { ok: false, message: '請填寫正確的 Email 格式。' };
  }
  var hit = findSubscription_(email);
  if (!hit) {
    return { ok: false, message: '這個信箱目前沒有生效中的訂閱。要新增請用上面的訂閱表單。' };
  }
  var items = String(hit.row['訂閱項目'] || '');
  var map = {};
  try { map = loadCodeMap_().byCode || {}; } catch (e) { map = {}; }
  return {
    ok: true,
    email: String(hit.row['Email'] || ''),
    daily: items.indexOf('每日總覽') >= 0,
    sms: items.indexOf('會員簡訊') >= 0,
    createdAt: fmtDate_(hit.row['建立時間']),
    stocks: String(hit.row['關注股票代號'] || '').split(',')
      .map(function (c) { return String(c).trim(); })
      .filter(String)
      .map(function (c) { return { code: c, name: map[c] ? map[c].name : '' }; })
  };
}


/** 依 Email 找出那一列生效中的訂閱。找不到或已取消都回 null。 */
function findSubscription_(email) {
  email = String(email || '').trim().toLowerCase();
  if (!email) { return null; }
  var sh = getSheet_('使用者訂閱清單');
  var vals = sh.getDataRange().getValues();
  if (vals.length < 2) { return null; }
  var head = vals[0].map(function (h) { return String(h).trim(); });
  var iEmail = head.indexOf('Email');
  var iState = head.indexOf('狀態');
  if (iEmail < 0) { return null; }
  for (var i = 1; i < vals.length; i++) {
    if (String(vals[i][iEmail]).trim().toLowerCase() !== email) { continue; }
    if (iState >= 0 && String(vals[i][iState]).trim() === '已取消') { continue; }
    var row = {};
    head.forEach(function (h, n) { row[h] = vals[i][n]; });
    return { rowNum: i + 1, head: head, row: row, sheet: sh };
  }
  return null;
}


/**
 * 儲存管理頁上的勾選結果。
 *
 * 三項都沒勾就等於退訂——那是使用者明確的意思，不要留一筆什麼都不寄的
 * 「生效中」訂閱，那種列會一直出現在訂閱人數裡卻永遠不寄東西。
 */
function apiUpdateSubscription(email, payload) {
  var hit = findSubscription_(email);
  if (!hit) { return { ok: false, message: '這個信箱目前沒有生效中的訂閱。' }; }
  payload = payload || {};

  var codes = (payload.codes || []).map(function (c) {
    return String(c).trim();
  }).filter(function (c) { return /^\d{4,6}$/.test(c); });

  var items = [];
  if (payload.daily) { items.push('每日總覽'); }
  if (payload.sms) { items.push('會員簡訊'); }
  if (codes.length) { items.push('關注股票'); }

  var iItems = hit.head.indexOf('訂閱項目');
  var iCodes = hit.head.indexOf('關注股票代號');
  var iState = hit.head.indexOf('狀態');

  if (!items.length) {
    if (iState >= 0) { hit.sheet.getRange(hit.rowNum, iState + 1).setValue('已取消'); }
    return { ok: true, message: '三項都沒有勾選，已停止接收所有信件。之後可以回網站重新訂閱。' };
  }

  if (iItems >= 0) { hit.sheet.getRange(hit.rowNum, iItems + 1).setValue(items.join('、')); }
  if (iCodes >= 0) { hit.sheet.getRange(hit.rowNum, iCodes + 1).setValue(codes.join(',')); }
  if (iState >= 0) { hit.sheet.getRange(hit.rowNum, iState + 1).setValue('生效中'); }

  return { ok: true, message: '已儲存：' + items.join('、')
           + (codes.length ? '（關注 ' + codes.length + ' 檔）' : '') + '。' };
}


/** 管理介面上的「停止接收所有信件」。與信裡那個連結做的是同一件事。 */
function apiStopAllMail(email) {
  var hit = findSubscription_(email);
  if (!hit) { return { ok: false, message: '這個信箱目前沒有生效中的訂閱。' }; }
  var iState = hit.head.indexOf('狀態');
  if (iState >= 0) { hit.sheet.getRange(hit.rowNum, iState + 1).setValue('已取消'); }
  return { ok: true, message: '已停止接收所有信件。之後可以回上面的表單重新訂閱。' };
}


/** 取消訂閱結果頁 */
function renderUnsubscribePage_(result) {
  var t = HtmlService.createTemplateFromFile('Unsubscribed');
  t.ok = result.ok;
  t.message = result.message;
  t.appTitle = APP_TITLE;
  return t.evaluate()
    .setTitle('取消訂閱　' + APP_TITLE)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

/* ------------------------------------------------------------------ *
 * 以下為前端 google.script.run 可呼叫的公開介面
 * 全部只回傳純資料物件，不回傳任何金鑰或內部設定
 * ------------------------------------------------------------------ */

/** 首頁需要的一次性資料：今日總覽 + 期間統計 */
function apiGetDashboard() {
  return {
    today: getTodayOverview(),
    stats: getPerformanceSummary(),
    updatedAt: Utilities.formatDate(new Date(), 'Asia/Taipei', 'yyyy/MM/dd HH:mm')
  };
}

/** 依股票代號或名稱查詢（規格書 4.4 節） */
function apiSearchStock(keyword, email) {
  var res = searchStock(keyword);
  if (email) { rememberQuery(email, keyword); }
  return res;
}

/* 使用紀錄。前端批次送上來，這裡只負責寫進試算表。

   刻意不接受 Email：訪客識別是瀏覽器本地產生的隨機碼，
   清掉瀏覽器資料就換一個新的，這邊無從還原成任何真人身分。
   要記的是「大家在看什麼」，不是「誰在看」。 */
function apiLogUsage(who, events) {
  return apiLogUse(who, events);
}

/** 依日期查詢（規格書 4.4 節） */
function apiSearchByDate(dateStr) {
  return searchByDate(dateStr);
}

/**
 * 有紀錄的日期清單（新到舊）。
 * 「翻到某一天」的日曆用它決定哪幾天點得下去，
 * 使用者就不必先點下去才發現那天沒東西。
 */
/** 有逐字稿的日期清單 */
function apiListTranscriptDates() {
  try { return listTranscriptDates(); } catch (e) { return []; }
}

/** 某一天的逐字稿（規則分段，不花額度） */
function apiGetTranscript(dateStr) {
  try { return getTranscript(dateStr); }
  catch (e) { return { found: false, reason: String(e.message || e) }; }
}

/** 某一天的逐字稿（AI 排版，使用者按下才呼叫） */
function apiFormatTranscript(dateStr) {
  try { return formatTranscript(dateStr); }
  catch (e) { return { found: false, reason: String(e.message || e) }; }
}

function apiListRecordDates() {
  try { return listRecordDates(); } catch (e) { return []; }
}

/** 個股即時報價（共用快取，規格書 4.2 節） */
function apiGetQuote(code) {
  return getRealtimeQuote(code);
}

/** 個股歷史 K 線，period: 'hour' | 'day' | 'week' | 'month' */
function apiGetCandles(code, period) {
  return getCandles(code, period || 'day');
}

/** 個股現爬已移除：證交所逐月現爬太慢會讓前端空轉，改為資料庫沒有就明確告知。 */
function apiFetchStockOnDemand(code) {
  return { ok: false, reason: '已停用現爬' };
}

/** 持股追蹤：每一檔從第一次提到買入至今的持有天數與報酬 */
function apiGetHoldingsTracker() {
  return getHoldingsTracker();
}

/**
 * 個股面板拆成四個獨立呼叫。
 *
 * 先前是一次回傳全部，四件事序列執行，基本面冷快取要抓兩千筆，
 * 整個面板就卡在「讀取中」，連左上角的股票名稱都出不來。
 * 拆開之後每一塊到了就顯示，名稱與報價幾乎立刻出現。
 */

/** 最快的一塊：名稱與報價。名稱來自對照表，就算報價掛掉也一定有名字。 */
function apiGetStockHeader(code) {
  code = String(code || '').trim();
  var m = loadCodeMap_().byCode[code] || {};
  var out = { code: code, name: m.name || '', market: m.market || '', quote: null };
  try { out.quote = getRealtimeQuote(code); } catch (e) { out.quote = null; }
  if (out.quote && out.quote.ok && out.quote.name) { out.name = out.quote.name; }
  if (!out.name) { out.name = code; }
  return out;
}

function apiGetStockTracker(code) {
  try { return getStockTracker(code); } catch (e) { return null; }
}

function apiGetStockRecord(code) {
  try { return searchStock(code); } catch (e) { return null; }
}

function apiGetStockFundamentals(code) {
  try { return getFundamentals(code); } catch (e) { return null; }
}

/** 小時K 的累積範圍，前端據此說明資料從哪天開始 */
function apiGetHourlyMeta() {
  return getHourlyMeta();
}

/** 為總覽表格補上現價。讀即時快取，不對外請求。 */
function apiGetQuotesFor(codes) {
  try { return getQuotesFor(codes || []); } catch (e) { return {}; }
}

/** 郵件查詢：列出所有已產生郵件內容的日期（新到舊）。 */
function apiListMailDates() {
  try { return listMailDates(); } catch (e) { return []; }
}

/** 郵件查詢：取某一天的郵件完整內容（文章＋結構化對照表，HTML）。 */
function apiGetMailContent(dateStr) {
  try { return getMailContent(dateStr); } catch (e) { return null; }
}

/**
 * 立即刷新網站既有內容（受保護）。
 * 這會重算全站顯示，屬管理操作，必須帶對管理密鑰才會執行。
 * 密鑰存在 Script Properties 的 ADMIN_KEY，只有站方知道。
 * 前端從管理入口呼叫並附上密鑰；一般訪客沒有密鑰，按不動。
 */
function apiRefreshSiteNow(adminKey) {
  var key = PropertiesService.getScriptProperties().getProperty('ADMIN_KEY');
  if (!key) {
    return { ok: false, reason: '尚未設定 ADMIN_KEY，請先到 Apps Script 指令碼屬性設定一組管理密鑰。' };
  }
  if (String(adminKey || '') !== key) {
    return { ok: false, reason: '管理密鑰不正確，沒有權限執行刷新。' };
  }
  try {
    var summary = refreshSiteNow();
    return { ok: true, summary: summary };
  } catch (e) {
    return { ok: false, reason: String(e).slice(0, 200) };
  }
}

/** 績效走勢，供折線圖 */
function apiGetPerformanceSeries() {
  return getPerformanceSeries();
}

/** 日K快取涵蓋範圍 */
function apiGetKCacheMeta() {
  return getKCacheMeta();
}

/** 股票代號名稱自動建議 */
function apiSuggestCodes(keyword) {
  return suggestCodes(keyword);
}

/** 建立訂閱 */
/** 會員通知分頁：有簡訊的日期，給日曆用。 */
function apiListSmsDates() {
  return smsDates_();
}

/** 會員通知分頁的資料。date 有給就只回那一天。含原文與解析出來的每一列。 */
function apiGetMemberSms(limit, date) {
  return memberSmsData_(limit, date);
}

function apiSubscribe(payload) {
  return createSubscription(payload);
}

/** 使用者上下文：回傳常查詢股票（規格書 4.6 節） */
function apiGetUserContext(email) {
  return getUserContext(email);
}

/**
 * 站內助手。可協助訂閱、查詢紀錄、說明功能。
 * 後端呼叫 Gemini，前端看不到金鑰。模型只負責理解，寫入由後端驗證後決定。
 */
function apiAsk(question, sessionId, model, userKey) {
  return askAssistant(question, sessionId, model, userKey);
}

/** 驗證使用者貼上的金鑰，回傳這把金鑰能用哪些模型 */
function apiValidateKey(userKey) {
  return validateKey(userKey);
}

/** 寄送取消訂閱連結到指定信箱 */
function apiSendUnsubscribeLink(email) {
  return sendUnsubscribeLink(email);
}

/** 可用的模型選單 */
function apiListModels() {
  return listModels();
}

/** 清空這一段對話的記憶 */
function apiResetSession(sessionId) {
  return resetSession(sessionId);
}


/**
 * 分步重算。每一步是一次獨立的網頁請求，各自享有完整的執行時間額度。
 *
 * step 可以是：
 *   purge   清除產業列
 *   gate    稽核與複審（分三次請求：完整性稽核 → 內容複審 → 重寫每日整理）
 *           可另外帶 date=YYYY/MM/DD 指定日期，沒帶就是今天
 *   codes   代號比對
 *   fund    更新基本面
 *   dailyk  補齊日K
 *   tracker 重算持股追蹤
 *   perf    記錄績效
 *   all     依序全部跑（保留給手動測試，正式呼叫請一步一步來，
 *           因為 all 很可能再次撞上時間上限）
 */
var REFRESH_STEPS_ = {
  purge:   { name: '清除產業列',   fn: function () { return purgeIndustryRows() + ' 列'; } },
  /* 品質關卡的三段，各自一格。

        本來就是分三次請求做完的（稽核 → 複審 → 重寫每日整理），
        先前卻擠成一格「稽核與複審」——那一格會亮三到六分鐘，
        期間分不出它在做哪一段，卡住時也看不出卡在哪一段。
        拆成三格不多花任何一次模型呼叫。

        排在代號比對之前，是因為稽核會補進新的列，那些列還沒有代號。

        gate 保留著沒有拿掉：舊版的 pipeline.py 與任何直接打
        ?action=refresh&step=gate 的東西還在用它。它不在 REFRESH_ORDER_ 裡，
        所以每日刷新走的是拆開後的三格。 */
  gate:    { name: '稽核與複審', chunked: true,
             fn: function (dateStr) { return qualityGateChunk_(dateStr); } },
  gate1:   { name: '稽核補漏', chunked: true,
             fn: function (dateStr) { return gatePhaseChunk_(dateStr, '稽核'); } },
  gate2:   { name: '內容複審', chunked: true,
             fn: function (dateStr) { return gatePhaseChunk_(dateStr, '複審'); } },
  gate3:   { name: '重寫整理', chunked: true,
             fn: function (dateStr) { return gatePhaseChunk_(dateStr, '重寫'); } },
  codes:   { name: '代號比對',     fn: function () { repairCodesJob(); return '完成'; } },
  fund:    { name: '更新基本面',   fn: function () { rebuildFundamentalsJob(); return '完成'; } },
  // 補日K改用安全小批次：每次最多約四十五秒，剩下的由呼叫端再打一次。
  // 一次跑完會久到讓 Google 前端把連線切掉，呼叫端只會看到
  // 「連線被切斷且沒有回應」，完全看不出是超時。
  dailyk:  { name: '補齊日K', chunked: true,
             fn: function () { return backfillDailyKChunk_(45); } },
  tracker: { name: '重算持股追蹤', fn: function () { rebuildHoldingsTrackerJob(); return '完成'; } },
  perf:    { name: '記錄績效',     fn: function () { snapshotPerformanceJob(); return '完成'; } },
  /* 績效歷史重算。不在 REFRESH_ORDER_ 裡，所以每日刷新不會碰到它——
     每日只需要補今天那一個點（perf），整條曲線重算是資料被修正之後才要做的事。
     用「持股追蹤的回合JSON ＋ 日K收盤價」直接算，不重跑追蹤，也不花模型額度。 */
  perfhist: { name: '重算績效歷史',
              fn: function (dateStr) {
                var r = rebuildPerformanceHistoryJob(dateStr || '');
                if (!r || !r.ok) { throw new Error('績效歷史未重算：' + ((r && r.reason) || '未知')); }
                // 「沒有東西可以重算」與「重算了 0 天」在日誌上要看得出差別，
                // 否則下次有人看到 0 會以為壞了。
                if (r.skipped) { return '略過（' + (r.reason || '沒有可重算的資料') + '）'; }
                return '重算 ' + r.days + ' 個交易日，' + r.codes + ' 檔';
              } },
  // 全面重整。不在 REFRESH_ORDER_ 裡，所以每日刷新不會碰到它，
  // 只有 GitHub 的 full_fix 模式會指名呼叫。一次做一棒，呼叫端重複打到 done。
  fullfix: { name: '全面重整', chunked: true,
             fn: function () { return runFullFixChunk_(); } },
  /* 唯讀查進度，不做任何事。
     驅動端遇到讀取逾時時用它判斷「那一棒到底有沒有做成」——
     逾時只代表連線沒等到回應，不代表工作沒進行：Apps Script 被時間上限
     砍掉時執行是被中止的，但砍掉之前寫進去的進度都還在。
     沒有這一支的話，驅動端只能把逾時一律當失敗，重試三次就放棄，
     而實際上每一次它都在前進。 */
  fullfixstate: { name: '全面重整進度', chunked: true,
                  fn: function () {
                    var st = fullFixState_() || {};
                    return { done: st.status !== '處理中',
                             processed: Number(st.index) || 0,
                             total: Number(st.total) || (FULLFIX_STEPS.length - 1),
                             note: (st.step || '（沒有進行中的重整）') +
                                   (st.sub && st.sub.total
                                     ? '　' + st.sub.done + '/' + st.sub.total : '') +
                                   '　' + (st.status || '') };
                  } },
  /* 會員簡訊進度：讀取或由 GitHub Actions 回報即時進度 */
  smsstate: { name: '會員簡訊進度', chunked: true,
              fn: function (d, params) {
                if (params && (params.status || params.pct || params.sub_step)) {
                  var prev = getSmsParseState_() || {};
                  var next = {
                    jobId: params.job_id || prev.jobId || '',
                    runId: prev.runId || '',
                    runUrl: prev.runUrl || '',
                    mode: prev.mode || params.mode || 'parse',
                    execution: prev.execution || 'github',
                    status: params.status || prev.status || '處理中',
                    step: params.sub_step || params.step_name || prev.step || 'AI模型解析',
                    index: params.index !== undefined ? Number(params.index) : (prev.index || 2),
                    total: params.total !== undefined ? Number(params.total) : (prev.total || 4),
                    done: params.done !== undefined ? Number(params.done) : (prev.done || 0),
                    pct: params.pct !== undefined ? Number(params.pct) : (prev.pct || 50),
                    note: params.note || prev.note || '',
                    lastError: params.status === '失敗' ? (params.note || prev.lastError || '') : '',
                    since: prev.since || '', through: prev.through || todayStr_(),
                    scanned: params.scanned !== undefined ? Number(params.scanned) : (prev.scanned || 0),
                    zhang: params.zhang !== undefined ? Number(params.zhang) : (prev.zhang || 0),
                    saved: params.saved !== undefined ? Number(params.saved) : (prev.saved || 0),
                    existed: params.existed !== undefined ? Number(params.existed) : (prev.existed || 0),
                    errors: params.errors !== undefined ? Number(params.errors) : (prev.errors || 0),
                    /* 步驟清單由 GitHub 回報，後台照著畫。兩邊版本不同步時
                       進度條的格數才不會對不上（例如後台畫 8 格、實際已跑到第 12 步）。 */
                    steps: params.steps ? String(params.steps).split('|') : (prev.steps || null),
                    /* 配額冷卻。撞到「每日請求數」上限時，pipeline.py 會算出
                       太平洋時間午夜換算成台北時間的重置點並送過來。
                       後台派工前會看這個值，還沒到就直接擋下，
                       不要再讓人每十五分鐘按一次、每次都白跑十四分鐘。 */
                    cooldownUntil: params.cooldown_until !== undefined ?
                                   String(params.cooldown_until) : (prev.cooldownUntil || ''),
                    quotaKind: params.quota_kind !== undefined ?
                               String(params.quota_kind) : (prev.quotaKind || ''),
                    /* 分桶計數：已判定有資料、已判定無個股、空白待解析、待寫入。
                       這是「哪些要花配額、哪些不用」在畫面上的依據。 */
                    blankRows: params.blank !== undefined ? Number(params.blank) : (prev.blankRows || 0),
                    doneRows: params.doneRows !== undefined ? Number(params.doneRows) : (prev.doneRows || 0),
                    emptyRows: params.emptyRows !== undefined ? Number(params.emptyRows) : (prev.emptyRows || 0),
                    pendingWrite: params.pendingWrite !== undefined ? Number(params.pendingWrite) : (prev.pendingWrite || 0),
                    aiQueued: params.aiQueued !== undefined ? Number(params.aiQueued) : (prev.aiQueued || 0),
                    aiUsed: params.aiUsed !== undefined ? Number(params.aiUsed) : (prev.aiUsed || 0),
                    reused: params.reused !== undefined ? Number(params.reused) : (prev.reused || 0),
                    deferred: params.deferred !== undefined ? Number(params.deferred) : (prev.deferred || 0),
                    writtenRows: params.written !== undefined ? Number(params.written) : (prev.writtenRows || 0),
                    remaining: params.remaining !== undefined ? Number(params.remaining) : (prev.remaining || 0),
                    auditReady: String(params.audit_ready || '').toLowerCase() === 'true' ||
                                (params.status === '完成') || !!prev.auditReady,
                    startedAt: prev.startedAt || Utilities.formatDate(new Date(), TZ, 'yyyy/MM/dd HH:mm:ss'),
                    updatedAt: Utilities.formatDate(new Date(), TZ, 'yyyy/MM/dd HH:mm:ss')
                  };
                  setSmsParseState_(next);
                  // 每日配額用盡時把冷卻時間鎖起來，後台派工那一關會擋。
                  if (next.quotaKind === 'daily' && next.cooldownUntil) {
                    smsSetCooldown_(next.cooldownUntil);
                  }
                  // 順利跑完就解除冷卻，不要讓昨天的鎖擋住今天。
                  if (next.status === '完成') {
                    PropertiesService.getScriptProperties().deleteProperty(SMS_COOLDOWN_PROP_);
                  }
                  return { ok: true, state: next };
                }
                return { ok: true, state: getSmsParseState_() };
              } },
  /* 會員簡訊改動某個歷史日期後，單獨重寫該日的每日整理。
     寄送狀態由 stepArticle_ 保留，因此不會把歷史信再寄一次。 */
  smsmail: { name: '同步會員簡訊衍生內容',
             fn: function (dateStr) {
               var d = fmtDate_(dateStr);
               if (!d) { throw new Error('缺少可驗證日期，未重寫郵件內容'); }
               stepArticle_({ date: d, videoId: '', id: 'SMSMAIL-' + d,
                              step: '撰稿', done: 0, total: 1 });
               return d + ' 郵件查詢已同步';
             } }
};

var REFRESH_ORDER_ = ['purge', 'gate1', 'gate2', 'gate3',
                      'codes', 'fund', 'dailyk', 'tracker', 'perf'];

var CHAIN_KEY_ = 'refreshChainState';

/* 這一棒的子進度。分批步驟（補日K、稽核與複審）回報 processed/total 時填進來，
   markChainStep_ 會把它一起寫進狀態。用模組變數而不是再存一份指令碼屬性，
   是因為它只在同一次執行裡有意義——下一次請求會重新算。 */
var CHAIN_SUB_ = null;

/**
 * 記下刷新鏈目前在哪一步。
 *
 * fullfix 不記——它有自己那一套更細的進度（跑到第幾天），記進來只會把
 * 兩件不同的事混在同一個狀態裡。
 */
function markChainStep_(step, name, status, err) {
  // fullfixstate 與 smsstate 是獨立進度查詢/更新，不該被當成「整條鏈跑到這一步」記進去。
  if (step === 'fullfix' || step === 'fullfixstate' || step === 'smsstate' || step === 'smsmail') { return; }
  try {
    var at = REFRESH_ORDER_.indexOf(step);
    // 取消旗標要留著。整包覆寫會把它洗掉，那樣按了取消之後下一步照樣做完，
    // 看起來就像取消沒有用。
    var prev = chainState_() || {};
    PropertiesService.getScriptProperties().setProperty(CHAIN_KEY_, JSON.stringify({
      step: step, name: name, status: status,
      // 分批步驟的「第幾批／共幾批」。補日K與稽核複審一格會亮好幾分鐘，
      // 沒有這個數字的話，畫面上與卡住完全分不出來。
      sub: (CHAIN_SUB_ && CHAIN_SUB_.step === step) ? CHAIN_SUB_.sub : null,
      note: (CHAIN_SUB_ && CHAIN_SUB_.step === step) ? CHAIN_SUB_.note : '',
      index: at, total: REFRESH_ORDER_.length,
      error: err || '',
      cancelled: !!prev.cancelled,
      updatedAt: Utilities.formatDate(new Date(), 'Asia/Taipei', 'yyyy/MM/dd HH:mm:ss')
    }));
  } catch (e) { /* 記進度失敗不能影響真正的工作 */ }
}

function chainState_() {
  var raw = PropertiesService.getScriptProperties().getProperty(CHAIN_KEY_);
  try { return raw ? JSON.parse(raw) : null; } catch (e) { return null; }
}

function chainCancelled_() {
  var st = chainState_();
  return !!(st && st.cancelled);
}

/**
 * 取消刷新。
 *
 * 與全面重整的取消是同一個道理：不去停 GitHub 那個 job，而是插一支旗子，
 * 下一步進來時看到就回「別打了」。已經做完的步驟保留著，之後用
 * 「從這一步重跑」挑一個接著做即可。
 */
function apiAdminCancelRefresh(key) {
  var real = PropertiesService.getScriptProperties().getProperty('ADMIN_KEY');
  if (!real || String(key) !== real) { return { ok: false, reason: '管理密鑰不正確' }; }
  var st = chainState_();
  if (!st) { return { ok: false, reason: '目前沒有進行中的刷新。' }; }
  st.cancelled = true;
  st.status = '已取消';
  st.updatedAt = Utilities.formatDate(new Date(), 'Asia/Taipei', 'yyyy/MM/dd HH:mm:ss');
  PropertiesService.getScriptProperties().setProperty(CHAIN_KEY_, JSON.stringify(st));
  return { ok: true,
           message: '已取消，停在「' + (st.name || st.step) + '」。' +
                    'GitHub 那邊最多再做完手上這一步就會收工。' +
                    '已完成的步驟保留著，用「從這一步重跑」挑一個接著做。' };
}

/** 開始新的一輪刷新之前要把旗子拔掉，否則新的一輪一進來就被自己擋掉。 */
function clearChainCancel_() {
  var st = chainState_() || {};
  st.cancelled = false;
  PropertiesService.getScriptProperties().setProperty(CHAIN_KEY_, JSON.stringify(st));
}

/** 後台用：刷新鏈跑到哪一步了。 */
function apiAdminChainState(key) {
  var real = PropertiesService.getScriptProperties().getProperty('ADMIN_KEY');
  if (!real || String(key) !== real) { return { ok: false, reason: '管理密鑰不正確' }; }
  var raw = PropertiesService.getScriptProperties().getProperty(CHAIN_KEY_);
  var st = null;
  try { st = raw ? JSON.parse(raw) : null; } catch (e) { st = null; }
  return { ok: true, state: st, order: REFRESH_ORDER_,
           names: REFRESH_ORDER_.map(function (k) { return REFRESH_STEPS_[k].name; }) };
}

function apiRefreshStep_(adminKey, step, dateStr, params) {
  var real = PropertiesService.getScriptProperties().getProperty('ADMIN_KEY');
  if (!real) { return { ok: false, error: '尚未設定 ADMIN_KEY' }; }
  if (String(adminKey) !== real) { return { ok: false, error: '管理密鑰不正確' }; }

  /* 被按了取消就立刻收工。

     整條鏈是 GitHub 一步一步打進來的，Apps Script 這邊沒有辦法主動叫停對方，
     只能在下一步進來時回一句「別打了」。呼叫端看到 cancelled 就結束整條鏈，
     所以最多再多做一步就會停，不必到 Actions 去按停止。 */
  if (chainCancelled_()) {
    return { ok: true, cancelled: true, done: true, step: step,
             result: '已取消，不再往下做' };
  }

  // 日期只有稽核與複審那一步用得到，其餘步驟收下但不理會。
  // 沒帶就是今天，這也是每日流程的常態。
  var d = dateStr || '';

  if (step === 'all') {
    var log = [];
    for (var i = 0; i < REFRESH_ORDER_.length; i++) {
      var k = REFRESH_ORDER_[i];
      var t0 = REFRESH_STEPS_[k];
      try {
        var r0 = t0.fn(d, params), guard = 0;
        // 分批的步驟要重複呼叫到做完為止，否則 all 只會做它的第一批，
        // 而回應看起來像是成功了——那種假成功比直接失敗難查得多。
        while (t0.chunked && r0 && typeof r0 === 'object' && !r0.done && ++guard < 40) {
          r0 = t0.fn(d, params);
        }
        log.push(t0.name + '：' +
                 (r0 && typeof r0 === 'object' ? (r0.note || JSON.stringify(r0)) : r0));
      } catch (e) { log.push(t0.name + ' 失敗：' + String(e).slice(0, 120)); }
    }
    return { ok: true, step: 'all', log: log };
  }

  var t = REFRESH_STEPS_[step];
  if (!t) {
    return { ok: false, error: '不認得的步驟：' + step,
             valid: REFRESH_ORDER_.join(', ') };
  }
  // 記下「現在在哪一步」。
  //
  // 刷新是由 GitHub 逐步打進來的，Apps Script 這邊每次只知道自己被要求做哪一步，
  // 但把它寫下來之後，後台就能問出整條鏈跑到哪，而不是只能顯示一個
  // 「GitHub 執行中」——那句話對正在等的人沒有任何資訊。
  markChainStep_(step, t.name, '執行中');

  try {
    var r = t.fn(d, params);
    // 分批的步驟會回一個物件，裡面帶 done 與進度。
    // 呼叫端看到 done=false 就再打一次，直到 true 為止。
    if (t.chunked && r && typeof r === 'object') {
      var note = r.note || ('本批成功 ' + (r.ok || 0) + ' 檔，進度 ' +
                 (r.processed || 0) + '/' + (r.total || 0) +
                 (r.failed ? '，失敗 ' + r.failed : ''));

      /* 把「第幾批／共幾批」寫回狀態，後台的進度條才看得出它在動。

         補日K有三十幾檔、稽核與複審有一百多天，這一格會亮好幾分鐘，
         先前畫面上只有一句「執行中」——與真的卡住完全分不出來，
         而使用者唯一能做的判斷就是「等了很久，是不是壞了」。 */
      CHAIN_SUB_ = { step: step,
                     sub: { done: Number(r.processed) || 0,
                            total: Number(r.total) || 0,
                            label: r.label || '' },
                     note: note };
      markChainStep_(step, t.name, r.done ? '完成' : '執行中');

      return { ok: true, step: step, name: t.name, chunked: true,
               done: !!r.done, processed: r.processed, total: r.total,
               result: note };
    }
    markChainStep_(step, t.name, '完成');
    return { ok: true, step: step, name: t.name, done: true, result: r };
  } catch (e) {
    markChainStep_(step, t.name, '失敗', String(e && e.message || e).slice(0, 200));
    return { ok: false, step: step, name: t.name,
             error: String(e && e.message || e).slice(0, 300) };
  }
}
