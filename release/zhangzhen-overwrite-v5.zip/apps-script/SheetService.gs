/**
 * 檔案：SheetService.gs
 * 試算表讀寫。所有寫入一律經過 LockService，避免與 GitHub Actions 同時寫入造成資料競爭
 * （規格書 3.5.3 節）。
 */

var TZ = 'Asia/Taipei';
var NOT_MENTIONED = '本支影片未說明';

function fmtDate_(v) {
  if (!v) { return ''; }
  if (Object.prototype.toString.call(v) === '[object Date]') {
    return Utilities.formatDate(v, TZ, 'yyyy/MM/dd');
  }
  return String(v).trim().replace(/-/g, '/');
}

function todayStr_() {
  return Utilities.formatDate(new Date(), TZ, 'yyyy/MM/dd');
}

/** 統一的寫入鎖 */
function withLock_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try { return fn(); } finally { lock.releaseLock(); }
}

/* ------------------------------------------------------------------ *
 * 4.1 逐日績效總覽
 * ------------------------------------------------------------------ */

/** 取得最近一個有資料的交易日總覽 */
function getTodayOverview() {
  var trades = readSheetObjects_('操作紀錄');
  var holds = readSheetObjects_('會員持股');
  var videos = readSheetObjects_('影片清單');

  var dates = trades.map(function (r) { return fmtDate_(r['日期']); }).filter(String);
  var latest = dates.sort().pop() || '';

  var todayTrades = trades.filter(function (r) { return fmtDate_(r['日期']) === latest; });
  var todayHolds = holds.filter(function (r) { return fmtDate_(r['日期']) === latest; });

  var video = videos.filter(function (r) { return fmtDate_(r['發布日期']) === latest; })[0] || null;

  function pick(dir) {
    return todayTrades
      .filter(function (r) { return String(r['方向']).indexOf(dir) === 0; })
      .map(function (r) {
        return {
          name: r['股票名稱'],
          code: r['代號'] || '代號待確認',
          price: r['價位說明'] || '未說明',
          reason: naturalReason_(r['理由摘錄']) || '未說明'
        };
      });
  }

  return {
    date: latest,
    hasData: !!latest,
    status: video ? video['處理狀態'] : '',
    failReason: video ? video['失敗原因'] : '',
    buy: pick('買'),
    sell: pick('賣'),
    watchAvoid: pick('觀望不碰'),
    watchWatch: pick('觀望注意'),
    // 舊欄位保留，內容為兩類合併，避免其他呼叫端壞掉
    watch: pick('觀望不碰').concat(pick('觀望注意')).concat(pick('不碰')),
    // 首頁持股與「持股追蹤」頁保持同一個來源：持股追蹤裡狀態為持有中的那些。
    // 先前這裡只讀當天「會員持股」分頁，張震當天沒複述持股清單時就會空白，
    // 與追蹤頁對不起來。改用追蹤表後兩頁必然一致。
    //
    // 追蹤表只收「明確講過買入」的標的，而且一出現觀望不碰就平倉，
    // 所以這份清單不會再出現方向是觀望不碰的股票。
    holdings: (function () {
      var t = getHoldingsTracker();
      return (t.held || []).map(function (i) {
        return {
          name: i.name,
          code: i.valid ? i.code : '代號待確認',
          stance: (i.rounds > 1) ? ('持有中\u3000第 ' + i.rounds + ' 回合') : '持有中',
          note: i.firstReason || '未說明'
        };
      });
    })(),
    notMentioned: NOT_MENTIONED
  };
}

/**
 * 期間統計：買入標的自買入日收盤起算至最新收盤的報酬。
 * 明確標示計算基準與資料期間，不使用「訊號」「建議」等字眼（規格書 4.1、九節）。
 */
function getPerformanceSummary() {
  var trades = readSheetObjects_('操作紀錄').filter(function (r) {
    return String(r['方向']).indexOf('買') === 0 && r['代號'] && String(r['代號']).indexOf('待確認') < 0;
  });

  if (!trades.length) {
    return { count: 0, avgReturn: null, positiveRatio: null, from: '', to: '', basis: '' };
  }

  var dates = trades.map(function (r) { return fmtDate_(r['日期']); }).sort();
  var returns = [];

  trades.forEach(function (r) {
    var code = String(r['代號']).trim();
    var buyDate = fmtDate_(r['日期']);
    try {
      var candles = getCandles(code, 'day');
      if (!candles || !candles.length) { return; }
      var entry = candles.filter(function (c) { return c.date >= buyDate; })[0];
      var last = candles[candles.length - 1];
      if (!entry || !last || !entry.close) { return; }
      returns.push((last.close - entry.close) / entry.close * 100);
    } catch (err) {
      // 單檔取價失敗不影響整體統計
    }
  });

  if (!returns.length) {
    return { count: trades.length, avgReturn: null, positiveRatio: null, from: dates[0], to: dates[dates.length - 1], basis: '' };
  }

  var avg = returns.reduce(function (a, b) { return a + b; }, 0) / returns.length;
  var pos = returns.filter(function (x) { return x > 0; }).length / returns.length * 100;

  return {
    count: trades.length,
    priced: returns.length,
    avgReturn: Math.round(avg * 100) / 100,
    positiveRatio: Math.round(pos * 10) / 10,
    from: dates[0],
    to: dates[dates.length - 1],
    basis: '以買入日收盤價為基準，計算至最近一個交易日收盤價。'
  };
}

/* ------------------------------------------------------------------ *
 * 持股追蹤
 *
 * 使用者真正想知道的是：這檔他從什麼時候開始講、講了多久、到現在賺賠多少。
 *
 * 這裡曾經有個 bug：過濾條件是 /^\d{4,6}$/，代號待確認的整列被扔掉，
 * 所以追蹤表永遠是空的，而且看不出原因。現在改成全部收進來，
 * 代號無效的標示為「代號待確認」並附上原因，讓問題浮出檯面而不是消失。
 *
 * 效能：進場價改讀日K快取，不再逐月向證交所抓。
 * ------------------------------------------------------------------ */

/**
 * 從「價位說明」欄解析出明確的成交價。
 *
 * 只認唯一、明確、可當成本的數字。含「約」「附近」「~」「跌到」這類
 * 模糊語一律不採用，寧可退回當日收盤價。
 * 「約 250 元」「120~125」「跌到 88 再買」都不是實際成交價，
 * 拿它們當成本會算出看起來精確但其實是編的報酬率。
 */
var VAGUE_WORDS = ['約', '附近', '左右', '上下', '~', '～',
                   '如果', '若', '漲停', '跌停', '之間', '區間'];

// 這些詞一出現，整句的數字就與成交價無關（財報、指數、技術線）。
// 「均線」特別重要：「等跌到 35 均線再買」裡的 35 是均線天數不是價格，
// 少了這一條就會把 35 當成買進價寫進表裡。
var NON_PRICE_WORDS = ['EPS', '每股', '年報', '財報', '營收', '毛利', '本益比',
                       '殖利率', '指數', '大盤', '成長',
                       '均線', '月線', '季線', '年線', '週線', '半年線'];

// 這些是「數量或金額單位」，只有緊接在數字後面時才代表非股價。
// 不能當成一般關鍵字比對：張震的「張」字會讓每一句含他名字的話都被誤判成成交量，
// 「說明重點」的「點」也會誤觸指數點位規則。必須要求前面真的有數字。
var NON_PRICE_UNITS = ['億', '兆', '萬張', '張', '口', '點', '塊', '萬元', '千萬'];

function hasNonPriceUnit_(s) {
  // 不用動態組 RegExp，字串裡的反斜線在不同層轉義很容易寫錯。
  // 直接掃字元：找到單位詞之後，往前跳過空白，看前一個字元是不是數字。
  var t = String(s || '');
  for (var i = 0; i < NON_PRICE_UNITS.length; i++) {
    var u = NON_PRICE_UNITS[i];
    var at = t.indexOf(u);
    while (at >= 0) {
      var k = at - 1;
      while (k >= 0 && (t.charAt(k) === ' ' || t.charAt(k) === '\u3000')) { k--; }
      if (k >= 0 && t.charAt(k) >= '0' && t.charAt(k) <= '9') { return true; }
      at = t.indexOf(u, at + 1);
    }
  }
  return false;
}

// 概數：「1400 多」「兩百出頭」。這種數字不能當成本，拿去算報酬是編的。
function isVagueNumber_(s) {
  return /\d\s*(多|出頭)/.test(s);
}

/**
 * 價位說明與方向是否互相矛盾。
 * 方向是買入、內容卻只講賣出（例如「255 以上全部賣掉」誤掛在買入那一列），
 * 那個數字描述的是另一個動作，不能拿來當這一筆的成交價。
 */
function contradictsDirection_(text, kind) {
  var s = String(text || '');
  if (kind === 'buy') {
    return /賣|出清|全部出|獲利了結|停損/.test(s) && !/買|承接|進場|加碼/.test(s);
  }
  if (kind === 'sell') {
    return /買|承接|進場|加碼/.test(s) && !/賣|出清|出場|獲利了結|停損/.test(s);
  }
  return false;
}

/* 技術指標裡的數字不是股價。

   實際算錯過一次：「股價拉回至低檔區，且60分K線顯示收斂末端翻揚，具上漲空間。」
   這句話裡 60 是全句唯一的數字，於是被第 4 條規則（整句只有一個數字就當價位）
   當成成交價，一路變成某一回合的出場價 60，算出 −15.49%；
   而那一天的收盤其實是 72.40。

   這些寫法都要先拿掉再判斷：60分K、5分鐘、20MA、9週KD、日K、月K線、
   60MA、5日均線。拿掉之後那句話一個數字都不剩，才是正確答案。 */
var INDICATOR_NUM_RE =
  /\d+(?:\.\d+)?\s*(?:分\s*[KkＫ]|分鐘|分線|日\s*[KkＫ]|週\s*[KkＫ]|月\s*[KkＫ]|季\s*[KkＫ]|[KkＫ]\s*線|MA|ma|日均線|日均|週期)/g;

function stripIndicatorNumbers_(s) {
  return String(s || '').replace(INDICATOR_NUM_RE, ' ');
}

function parsePriceHint_(priceText, reasonText, kind) {
  function scan_(text, src) {
    var s = String(text || '').trim();
    if (!s || s === '未說明') { return null; }
    // 技術指標的數字先拿掉，後面每一條規則都不會再看到它們。
    s = stripIndicatorNumbers_(s);

    // 財報、指數、技術線類的數字直接排除
    for (var j = 0; j < NON_PRICE_WORDS.length; j++) {
      if (s.indexOf(NON_PRICE_WORDS[j]) >= 0) { return null; }
    }
    // 數量、金額單位（241 億、5000 張）不是股價
    if (hasNonPriceUnit_(s)) { return null; }
    // 概數（1400 多）不能當成本
    if (isVagueNumber_(s)) { return null; }
    // 與操作方向矛盾的敘述，講的是另一個動作，不採用
    if (contradictsDirection_(s, kind)) { return null; }

    // 1. 門檻式：「255 以上」「241 以下」「跌破 88」「站上 120」
    //    這一條要排在模糊語檢查之前。「漲到 255 以上就賣」裡有「到」字，
    //    先前會被模糊語規則整句丟掉，連帶把明確的門檻數字也丟了。
    var th = s.match(/(\d+(?:\.\d{1,2})?)\s*(?:元)?\s*(以上|之上|以下|之下)/);
    if (th) {
      var tv = parseFloat(th[1]);
      if (!isNaN(tv) && tv >= 1 && tv <= 10000) {
        return { value: tv, mode: (th[2] === '以上' || th[2] === '之上') ? 'above' : 'below', src: src };
      }
    }
    var th2 = s.match(/(跌破|跌到|回到|拉回到|站上|漲到|突破|衝上)\s*(\d+(?:\.\d{1,2})?)/);
    if (th2) {
      var tv2 = parseFloat(th2[2]);
      if (!isNaN(tv2) && tv2 >= 1 && tv2 <= 10000) {
        var down = ('跌破跌到回到拉回到'.indexOf(th2[1]) >= 0);
        return { value: tv2, mode: down ? 'below' : 'above', src: src };
      }
    }

    // 2. 明確成交價：「在 235 買入」「235 買進」「成本 168」
    var ex = s.match(/(?:在|以|用)?\s*(\d+(?:\.\d{1,2})?)\s*(?:元)?\s*(買到|買進|買入|承接|進場|賣出|賣掉|出場|成本)/);
    if (!ex) {
      ex = s.match(/(?:成本|買在|賣在|進場價|出場價)\s*(\d+(?:\.\d{1,2})?)/);
      if (ex) { ex = [ex[0], ex[1]]; }
    }
    if (ex) {
      var ev = parseFloat(ex[1]);
      if (!isNaN(ev) && ev >= 1 && ev <= 10000) {
        return { value: ev, mode: 'exact', src: src };
      }
    }

    // 3. 模糊語出現就不再往下猜單一數字。「約 90」「1400 多」不能當成本。
    for (var i = 0; i < VAGUE_WORDS.length; i++) {
      if (s.indexOf(VAGUE_WORDS[i]) >= 0) { return null; }
    }

    /* 4. 整句只有一個數字，且看起來像價位。

       這一條只適用於「價位說明」欄。那一欄本來就是為了放價位，
       裡面出現一個孤零零的數字，它是價位的機率很高。

       「說明重點」不適用。那一欄是敘述句，裡面的數字什麼都可能是——
       技術指標（60分K、20MA）、天數（等3天）、名次、百分比。
       用「只有一個數字就當價位」去撈，撈到的多半不是價位，
       而錯誤的成本會直接變成錯誤的報酬，比沒有數字糟得多。
       敘述句裡真正的價位一定會帶著動詞或門檻詞（「在 235 買進」
       「跌破 88」），那些在上面第 1、2 條就抓到了。 */
    if (src !== '價位說明') { return null; }

    var m = s.match(/(?:^|[^\d.])(\d{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?)(?![\d.])/g);
    if (!m || m.length !== 1) { return null; }
    var v = parseFloat(String(m[0]).replace(/[^\d.]/g, ''));
    if (isNaN(v) || v < 1 || v > 10000) { return null; }
    return { value: v, mode: 'exact', src: src };
  }

  // 價位說明優先，那一欄本來就是為了放價位。找不到才去說明重點裡撈。
  return scan_(priceText, '價位說明') || scan_(reasonText, '說明重點');
}

/** 舊介面保留，只回數值。其他地方若還在用不會壞掉。 */
function parseStatedPrice_(text) {
  var h = parsePriceHint_(text, '', '');
  return h ? h.value : null;
}

// 條件價往後找觸價日的上限。超過這個交易日數還沒碰到，就當作沒成交。
var FILL_LOOKAHEAD_DAYS = 60;

/**
 * 決定某一天的成交價。
 *
 * hint 是 parsePriceHint_ 的結果。處理順序：
 *   1. 沒有 hint            → 當日收盤
 *   2. 落在當日高低之內      → 就是它，當天真的成交得了
 *   3. 門檻價、當日還沒到    → 往後找第一個真的碰到的交易日，用那天當成交日
 *   4. 明確價、當日碰不到    → 往後找第一個涵蓋這個價位的交易日
 *   5. 一直到期限都沒碰到    → 退回當日收盤
 *   6. 離譜到不像這檔的股價  → 判定不是價位，捨棄
 *
 * 第 3 點是這次修正的重點。「255 以上全部賣掉」在講的當天股價可能才 235，
 * 那個 255 是條件不是成交。先前一律拿當日高低去驗，必然驗不過而退回收盤，
 * 等於把張震明確講過的出場價丟掉，報酬就算錯。現在改成往後找觸價日，
 * 後來真的漲到 255 的那一天才是成交日，價格就用 255。
 */
function priceOnDate_(candles, dateStr, hint, name, label, floorDate) {
  if (!candles || !candles.length) {
    return { price: '', src: '', rejected: false, date: dateStr };
  }

  var idx = -1;
  for (var i = 0; i < candles.length; i++) {
    if (candles[i].date >= dateStr) { idx = i; break; }
  }
  var d = idx >= 0 ? candles[idx] : null;

  // 沒有 hint：單純取當日收盤
  if (!hint || !hint.value) {
    return d ? { price: d.close, src: '當日收盤', rejected: false, date: d.date }
             : { price: '', src: '', rejected: false, date: dateStr };
  }

  var v = hint.value;

  // 日K快取沒涵蓋到那一天：用整段區間當寬鬆的合理範圍，只擋離譜值
  if (!d) {
    var his = candles.map(function (k) { return k.high; });
    var los = candles.map(function (k) { return k.low; });
    var hiAll = Math.max.apply(null, his), loAll = Math.min.apply(null, los);
    if (v >= loAll * 0.7 && v <= hiAll * 1.3) {
      return { price: v, src: '影片明講', rejected: false, date: dateStr };
    }
    // 同樣不留空。取離該日最近的一根K棒收盤當估計值。
    var near = candles[0], bestGap = Infinity;
    candles.forEach(function (k) {
      var gap = Math.abs(new Date(k.date).getTime() - new Date(dateStr).getTime());
      if (gap < bestGap) { bestGap = gap; near = k; }
    });
    Logger.log('    ' + name + ' ' + dateStr + ' ' + label + '　明講價 ' + v +
               ' 遠離歷史區間 ' + loAll + '-' + hiAll + '，改用最近一根收盤 ' + near.close);
    return { price: near.close, src: '日K未涵蓋該日，取最近交易日 ' + near.date + ' 收盤',
             rejected: true, date: near.date };
  }

  // 當天就在區間內，直接成交
  if (v >= d.low && v <= d.high) {
    return { price: v, src: '影片明講', rejected: false, date: d.date };
  }

  // 先確認這個數字對這一檔而言合不合理。差太多的直接判定不是股價，
  // 不要拿去往後找，否則「241 億」會在某天真的漲到 241 時被誤採。
  var hiA = Math.max.apply(null, candles.map(function (k) { return k.high; }));
  var loA = Math.min.apply(null, candles.map(function (k) { return k.low; }));
  if (v > hiA * 1.3 || v < loA * 0.7) {
    // 這個數字不是股價（實際踩過：一檔一千多元的股票抓到「8」）。
    // 捨棄它是對的，但不能因此讓進場價整欄空白——那會讓報酬、現價、
    // 累積報酬一起變成破折號，看起來像系統壞掉，比用當日收盤更難理解。
    // 正確做法是退回當日收盤，並在來源欄說明那個數字為什麼沒被採用。
    Logger.log('    ' + name + ' ' + dateStr + ' ' + label + '　價位 ' + v +
               ' 遠離這檔的歷史區間 ' + loA + '-' + hiA + '，判定不是股價，改用當日收盤');
    return { price: d.close, src: '取當日收盤（明講的 ' + v + ' 不是這檔的價位）',
             rejected: true, date: d.date };
  }

  // ---- 雙向找觸價日 ----
  //
  // 只往後找是錯的，這是先前把明講價丟掉的主因。
  //
  // 講者講價位有兩種時態，兩種都很常見：
  //   未來式　「漲到 255 以上就賣」「跌到 241 以下可以買」→ 要等，往後找。
  //   過去式　「會員在 2135 買的」「241 那天連買都買不到」→ 已經發生，往前找。
  //
  // 先前只往後找，於是所有回述成本的講法都必然找不到，
  // 然後被當成「條件沒成立」退回當日收盤——把講者明確講過的價格丟掉，
  // 換成一個他從沒提過的數字。實際發生過台積電講 2135 卻用 2465、
  // 鴻海講 241 卻用 250.5，兩筆的報酬都因此算錯。
  //
  // 往後找有 FILL_LOOKAHEAD_DAYS 的上限，因為條件價等太久就失去意義；
  // 往前找不設限，因為回述成本可能是好幾個月前的事，而且那是既成事實，
  // 沒有「過期」的問題。
  function hit_(k) {
    if (hint.mode === 'above') { return k.high >= v; }
    if (hint.mode === 'below') { return k.low <= v; }
    return v >= k.low && v <= k.high;
  }

  /* 往前找要有下限。

     這是實際算錯過報酬的地方：往前找原本一路找到快取的最開頭，於是
     出場價可以「成交」在這一回合買進之前——
       第 2 回合　2026/09/04 買入 71 → 2026/09/09 賣出 60（2026/08/04 觸價）
     那筆賣出被記在買進的一個月前，然後用它算出 −15.49%。
     賣出不可能發生在買進之前，那個數字是憑空生出來的。

     floorDate 由呼叫端給：算出場價時是「這一回合的成交日」，
     算進場價時是「上一回合的出場日」。回述成本仍然找得到（那本來就是
     這一回合開始之後、或上一回合結束之後的事），但跨不回不可能的區間。 */
  var floorIdx = 0;
  if (floorDate) {
    for (var f = 0; f < candles.length; f++) {
      if (candles[f].date >= floorDate) { floorIdx = f; break; }
    }
  }

  var fwd = -1, back = -1;
  var limit = Math.min(candles.length, idx + 1 + FILL_LOOKAHEAD_DAYS);
  for (var j = idx; j < limit; j++) {
    if (hit_(candles[j])) { fwd = j; break; }
  }
  for (var b = idx - 1; b >= floorIdx; b--) {
    if (hit_(candles[b])) { back = b; break; }
  }

  // 兩邊都找到就取離發話日比較近的那一天。
  var pick = -1;
  if (fwd >= 0 && back >= 0) {
    pick = (fwd - idx) <= (idx - back) ? fwd : back;
  } else if (fwd >= 0) { pick = fwd; }
  else if (back >= 0) { pick = back; }

  if (pick >= 0) {
    var k2 = candles[pick];
    var tense = pick < idx ? '回述' : (pick > idx ? '條件價' : '明講價');
    var verb = (hint.mode === 'above') ? '漲抵' : (hint.mode === 'below') ? '跌抵' : '成交於';
    var why2 = (pick === idx)
      ? '影片明講'
      : tense + '，' + k2.date + ' ' + verb + ' ' + v;
    if (pick !== idx) {
      Logger.log('    ' + name + ' ' + dateStr + ' ' + label + '　' + v +
                 ' 當日未觸價（' + d.low + '-' + d.high + '），' +
                 (pick < idx ? '往前' : '往後') + '找到 ' + k2.date + ' 觸價');
    }
    return { price: v, src: why2, rejected: false, date: k2.date,
             filled: (pick !== idx), backward: (pick < idx) };
  }

  /* 找不到觸價日。這裡要分兩種情況，因為證據強度完全不同。

     一、沒有下限（floorDate 是空的）
         「整段快取都沒碰到」很可能只是快取沒涵蓋到那一段。這個價位已經
         通過前面的合理性檢查（落在這一檔歷史區間正負三成內），八成仍是
         這一檔的價位。用當日收盤取代等於把講者明講的數字換成他沒提過的，
         報酬會算錯而且看不出來。所以採用明講價，並在來源欄註明沒有K線佐證。

     二、有下限（算出場價、或上一回合之後的進場價）
         這時搜尋範圍是「這一回合實際存在的那幾天」，而那幾天的K線就在
         快取裡——「沒碰到」不是快取缺漏，是這個價位在這段期間真的沒有成交。
         這種情況再採用明講價就是編造：實際發生過
           2026/09/04 買入 71 → 2026/09/09 賣出 60（2026/08/04 觸價）
         那個 60 是一個月前的價，被當成這一回合的出場價，算出 −15.49%。
         而那一天的收盤是 72.40，這一回合其實小賺。
         有下限時一律退回當日收盤，並在來源欄說明那個數字為什麼沒被採用。 */
  if (floorDate && d) {
    Logger.log('    ' + name + ' ' + dateStr + ' ' + label + '　明講價 ' + v +
               ' 在 ' + floorDate + ' 之後到 ' + dateStr + ' 之間未曾成交，改用當日收盤 ' + d.close);
    return { price: d.close, rejected: true, date: d.date,
             src: '明講的 ' + v + ' 在本回合期間未曾成交（' + floorDate +
                  ' 起），改取當日收盤' };
  }

  Logger.log('    ' + name + ' ' + dateStr + ' ' + label + '　明講價 ' + v +
             ' 在日K快取中查無觸價紀錄（快取可能未涵蓋該區間），仍採用明講價');
  return { price: v, src: '影片明講，日K快取查無觸價紀錄', rejected: false,
           date: dateStr, unverified: v };
}

function daysBetween_(a, b) {
  if (!a || !b) { return 0; }
  var d1 = new Date(a), d2 = new Date(b);
  if (isNaN(d1) || isNaN(d2)) { return 0; }
  return Math.max(Math.round((d2 - d1) / 86400000), 0);
}

/* ------------------------------------------------------------------ *
 * 持有回合（round）模型
 *
 * 一檔股票可能買進、賣出、再買回來。用單一組「首次買入 → 最近賣出」
 * 描述不了這件事：第二次買回來之後，進場價還停在第一次那個價格，
 * 報酬就整個算錯，狀態也會在持有中與已出場之間互相蓋掉。
 * 所以改成把每一檔切成數個「回合」，一個回合 ＝ 一次進場到一次出場
 * （或還沒出場）。表格顯示的是「最新那一個回合」，過去的回合另外保留。
 *
 * 開倉有兩種方式：
 *   1. 影片中明講買入。
 *   2. 影片中明講「會員目前持有 X」，也就是寫進「會員持股」分頁的那些。
 *      這一條是後來補的。張震有時候不會重述當初的買入動作，只在盤中
 *      複述一次會員手上有什麼，那句話本身就是一個明確的持有聲明，
 *      信件的「影片中明講之會員目前持有股票」那一段列的就是它。
 *      少了這條路，那些標的會出現在信裡卻不在網站上，兩邊對不起來。
 *
 *      但它跟明講買入不同：那天並沒有成交，所以進場價只能取當日收盤，
 *      而且必須擋掉同日矛盾（同一天又被講成觀望不碰或賣出）。
 *      早期版本就是少了這道防呆，才會讓方向是觀望不碰的股票混進會員持股。
 *      現在的規則是：同一天出現相反訊號時，這一筆持有聲明不予採信。
 *
 * 平倉有三種方式，依序判斷：
 *   1. 明講賣出　　　　　　　　→ 出場價取賣出當日（明講價通過當日高低驗證才採用）
 *   2. 觀望不碰　　　　　　　　→ 暫定視為出場，出場價取當日收盤。
 *      這不是一筆成交，是立場由持有轉為不碰，所以絕不採用明講價，
 *      只用當日收盤代表「若在這天退出，價位大約在這裡」。
 *   3. 逾 STALE_TRADING_DAYS 個交易日未再提及 → 視為出場，取最後一次提及當日收盤。
 *
 * 「觀望不碰」的平倉是暫定的，會被後來的事實推翻。
 *
 * 他講「不碰」時，講的對象常常是「還沒進場的人」而不是「手上有的人」。
 * 鴻海實際發生過：8/27 明講會員持有 238，8/31 說「238 搶過了，248 不會推薦」，
 * 9/2 又說「前幾天於 238 買進，目前已漲到 250 幾」。
 * 8/31 那句是在勸人不要追高，不是宣布出場——9/2 那句證明部位從頭到尾都在手上。
 * 舊的規則把 8/31 當成出場、把 9/2 當成新開的第四回合，於是同一筆部位被切成兩段，
 * 第三回合結算出一個沒有發生過的報酬，第四回合的進場價又變成 9/2 的收盤。
 *
 * 所以改成往後看一步再決定：
 *   不碰之後的下一個實質動作是「會員持股」或「賣出」→ 部位還在，這次不碰不平倉。
 *     賣出也算，因為賣得掉就代表手上還有，那句不碰同樣沒有讓部位離開。
 *   下一個實質動作是「買入」→ 那是重新進場，這次不碰確實是出場，照舊平倉。
 *   在 AVOID_REOPEN_TRADING_DAYS 個交易日內沒有任何實質動作 → 照舊平倉。
 * 被推翻的那幾次會記在回合上，出場原因欄看得到，不會無聲無息地消失。
 *
 * 觀望注意不平倉：語氣偏多，代表繼續追蹤，不是退出。
 * 同一天既有買入又有相反訊號時，以買入為準，忽略當天的平倉訊號。
 * 那種同日矛盾幾乎都是擷取誤判，不該讓它把當天剛建立的部位又關掉。
 * ------------------------------------------------------------------ */

/** 把「方向」欄歸類成回合模型認得的動作。順序有意義，不可對調。 */
function classifyDirection_(dir) {
  var d = String(dir || '');
  if (d.indexOf('買') === 0) { return 'buy'; }
  if (d.indexOf('賣') === 0) { return 'sell'; }
  if (d.indexOf('會員持股') >= 0) { return 'hold'; }
  if (d.indexOf('觀望不碰') >= 0 || d.indexOf('不碰') >= 0) { return 'avoid'; }
  if (d.indexOf('觀望注意') >= 0) { return 'note'; }
  if (d.indexOf('觀望') >= 0) { return 'note'; }   // 舊資料只寫「觀望」時當中性，不平倉
  return 'other';
}

/** 同一天多筆時的先後順序：先開倉、再平倉、其他最後。 */
/* buy 與 hold 都是開倉動作，所以排在最前面；hold 排在 buy 之後，
   同一天兩者都出現時以真正的買入為準（hold 會因為已有部位而略過）。 */
var ACTION_ORDER = { buy: 1, hold: 2, sell: 3, avoid: 4, note: 5, other: 6 };

/**
 * 排序。日期優先，同一天再看順序。
 *
 * 同一天的先後，能用「序」就用「序」。
 *
 * ACTION_ORDER 把買入一律排在賣出前面，那是在沒有其他資訊時的合理猜測，
 * 但它會猜錯，而且錯得很嚴重。實際發生過：他昨天早盤賣出晶心科 270 幾、
 * 快中午又買回來 250 幾。照 ACTION_ORDER 會變成「先買 250 再賣 270」——
 * 先買後賣是加碼之後獲利了結，先賣後買是賣掉再撿回來，兩者的持有回合、
 * 進場價、報酬完全不同。更糟的是後面還有一條「同日已有買入就忽略相反訊號」，
 * 於是那筆賣出直接消失，回合永遠不會結束。
 *
 * 現在擷取端會填「序」（同一檔同一天照他描述的先後 1、2、3）。
 * 兩筆都有序而且都是買賣時就照序走，其餘情況維持原本的優先級——
 * 混用是刻意的：會員持股那張分頁沒有序欄，拿 0 去跟買入的 1 比會把
 * 持有聲明排到買入前面，那是另一種錯。
 */
function sortRecords_(list) {
  return list.slice().sort(function (a, b) {
    if (a.date !== b.date) { return a.date < b.date ? -1 : 1; }
    var trade = (a.kind === 'buy' || a.kind === 'sell') &&
                (b.kind === 'buy' || b.kind === 'sell');
    if (trade && a.seq > 0 && b.seq > 0 && a.seq !== b.seq) {
      return a.seq - b.seq;
    }
    return (ACTION_ORDER[a.kind] || 9) - (ACTION_ORDER[b.kind] || 9);
  });
}

// 觀望不碰之後要往後看幾個交易日，才算「沒有下文」。
// 用交易日而不是日曆日，因為連假期間他本來就沒在講盤，
// 用日曆日會讓中秋或農曆年前後的每一次不碰都被當成真的出場。
// 十天與 STALE_TRADING_DAYS 一致：那是這個系統對「還在追蹤中」的一貫定義。
var AVOID_REOPEN_TRADING_DAYS = 10;

// 日曆日的上限，與上面那個一起看。
//
// 為什麼要兩個：交易日的數法完全依賴日K快取，而日K快取是會殘缺的
// （新股還沒補、當天的還沒進來、額度用盡跑到一半）。快取少了一段時，
// 兩個相隔三個月的日期算起來可能只差三個交易日，於是三個月前的一次不碰
// 會被今天的持有聲明推翻——那是明顯錯的。
// 日曆日不依賴任何快取，拿它當第二道界線，快取殘缺時仍然擋得住。
// 十個交易日約兩週，二十一天留了連假與補班的餘裕。
var AVOID_REOPEN_CALENDAR_DAYS = 21;

/** tradingDays 陣列裡，a 與 b 之間隔了幾個交易日。tradingDays 需已排序。 */
function tradingDaysBetween_(tradingDays, a, b) {
  if (!tradingDays || !tradingDays.length) { return 0; }
  var n = 0;
  for (var i = 0; i < tradingDays.length; i++) {
    if (tradingDays[i] > a && tradingDays[i] <= b) { n++; }
  }
  return n;
}

/**
 * 這一次的「觀望不碰」到底算不算出場。
 *
 * 往後找第一個實質動作（買入、賣出、會員持股），依它決定：
 *   賣出或會員持股 → 部位還在手上，這次不碰不算出場。
 *   買入　　　　　 → 是重新進場，所以這次不碰確實是出場。
 *   都沒有（或超過期限）→ 沒有下文，照舊視為出場。
 *
 * 只看第一個，不看更後面的。中間若隔著一次買入，那次買入已經開了新回合，
 * 再後面的持有聲明講的是新回合的部位，不能拿來證明舊回合沒結束。
 */
function avoidClosesRound_(sorted, at, tradingDays) {
  var here = sorted[at];
  // 沒有交易日曆就量不出「隔多久」，這時退回舊行為：不碰就是出場。
  // 量不出來的時候寧可維持原樣，也不要因為量不出來而放寬。
  if (!tradingDays || !tradingDays.length) { return { close: true }; }
  for (var j = at + 1; j < sorted.length; j++) {
    var r = sorted[j];
    if (r.kind !== 'buy' && r.kind !== 'sell' && r.kind !== 'hold') { continue; }
    if (r.kind === 'buy') { return { close: true }; }
    var gap = tradingDaysBetween_(tradingDays, here.date, r.date);
    var cal = daysBetween_(here.date, r.date);
    if (gap > AVOID_REOPEN_TRADING_DAYS ||
        cal > AVOID_REOPEN_CALENDAR_DAYS) { return { close: true }; }
    return { close: false,
             why: r.date + ' ' + (r.kind === 'sell' ? '明講賣出' : '明講會員持有') +
                  '，證明部位並未在 ' + here.date + ' 離開' };
  }
  return { close: true };
}

/**
 * 把一檔的所有紀錄切成數個持有回合。
 * 回傳陣列，最後一個若 close 為 null 就代表現在還持有。
 *
 * tradingDays 是市場交易日清單（由小到大），用來判斷觀望不碰之後多久沒有下文。
 * 傳空陣列也能跑，那時所有的不碰都照舊視為出場，行為與加這一關之前相同。
 */
function buildRounds_(records, tradingDays) {
  // 每一天出現過哪些動作。用來判斷同日矛盾。
  var dayKinds = {};
  records.forEach(function (r) {
    if (!dayKinds[r.date]) { dayKinds[r.date] = {}; }
    dayKinds[r.date][r.kind] = 1;
  });
  function sameDay_(date, kind) { return !!(dayKinds[date] && dayKinds[date][kind]); }

  /* 哪幾天的買賣有明確的先後。

     有序的那幾天，同一天的買與賣不是「矛盾」而是「順序」，
     下面那條忽略相反訊號的守則要讓開，否則先賣後買會被吃掉那筆賣出。 */
  var daySeqKnown = {};
  records.forEach(function (r) {
    if ((r.kind === 'buy' || r.kind === 'sell') && r.seq > 0) {
      daySeqKnown[r.date] = (daySeqKnown[r.date] || 0) + 1;
    }
  });
  function ordered_(date) { return (daySeqKnown[date] || 0) >= 2; }

  var rounds = [], cur = null;
  var sorted = sortRecords_(records);
  sorted.forEach(function (r, at) {
    if (r.kind === 'buy') {
      // 已經有部位時再買，是加碼，不另開回合，進場價維持這一回合的第一筆。
      if (!cur) { cur = { open: r, openKind: 'buy', adds: [], close: null, closeKind: '' }; }
      else { cur.adds.push(r); }
      return;
    }

    if (r.kind === 'hold') {
      // 明講「會員目前持有」。手上已經有部位就只是再確認一次，不動任何東西。
      if (cur) { return; }
      // 同一天又被講成觀望不碰或賣出，代表這一筆持有聲明與當天的其他訊號打架。
      // 這種矛盾幾乎都是擷取誤判，寧可不開倉，也不要讓一檔「不要碰」的股票
      // 因為被順口列進持股清單就變成持有中。
      if (sameDay_(r.date, 'avoid') || sameDay_(r.date, 'sell')) { return; }
      cur = { open: r, openKind: 'hold', adds: [], close: null, closeKind: '' };
      return;
    }

    if (!cur) { return; }                      // 手上沒部位，賣出或觀望都不構成回合
    // 同日已有買入時忽略相反訊號——但那條守則是在「不知道先後」時的防呆。
    // 這一天若有明確的序（先賣後買、或先買後賣），就照序走，不要忽略。
    if (sameDay_(r.date, 'buy') && !ordered_(r.date)) { return; }
    if (r.kind === 'sell') {
      cur.close = r; cur.closeKind = '賣出';
      rounds.push(cur); cur = null;
    } else if (r.kind === 'avoid') {
      var verdict = avoidClosesRound_(sorted, at, tradingDays);
      if (!verdict.close) {
        // 這次不碰被後來的事實推翻。只記日期——理由對每一次都一樣，
        // 每一筆都附一次會讓出場原因欄變成一整片文字牆。
        cur.avoidIgnored = (cur.avoidIgnored || []);
        cur.avoidIgnored.push(r.date);
        return;
      }
      cur.close = r; cur.closeKind = '觀望不碰';
      rounds.push(cur); cur = null;
    }
  });
  if (cur) { rounds.push(cur); }
  return rounds;
}

// 由「會員持股聲明」開倉的部位，必須在其後這麼多個交易日內至少再被提到一次，
// 否則視為擷取錯誤整筆移除。三天是刻意訂得短的：張震每個交易日都在講盤，
// 一檔真的在手上的股票不可能連續三個交易日完全不被提起；
// 反過來說，只出現過孤零零一次、之後就消失的，幾乎都是語音辨識或擷取的雜訊。
var HOLD_CONFIRM_DAYS = 3;

/**
 * 判斷一個由持有聲明開倉的回合，有沒有在期限內被再次提到。
 *
 * 回傳 'confirmed' | 'unconfirmed' | 'pending'
 *
 *   confirmed    期限內有再被提到，是真的持股。
 *   unconfirmed  期限已過但完全沒有再被提到，判定為擷取錯誤，整個回合移除。
 *   pending      期限還沒過完（例如昨天才剛講的），現在還不能judge。
 *                這一段最容易寫錯：若不分辨 pending，剛講完的持股會在
 *                隔天的重算裡被當成「沒有後續」而立刻刪掉，等於永遠留不住。
 *
 * openDate     這個回合的開倉日
 * recs         這一檔的全部紀錄（已含操作紀錄與會員持股）
 * tradingDays  市場交易日清單，由小到大
 */
function holdConfirmState_(openDate, recs, tradingDays) {
  // 開倉日之後的交易日，取前 HOLD_CONFIRM_DAYS 個當作觀察窗。
  var after = tradingDays.filter(function (d) { return d > openDate; });
  var windowDays = after.slice(0, HOLD_CONFIRM_DAYS);

  // 觀察窗還沒湊滿，代表時間根本還沒到，不能判定。
  if (windowDays.length < HOLD_CONFIRM_DAYS) { return 'pending'; }

  var windowEnd = windowDays[windowDays.length - 1];
  var mentioned = recs.some(function (r) {
    return r.date > openDate && r.date <= windowEnd;
  });
  return mentioned ? 'confirmed' : 'unconfirmed';
}

/** 每日 14:50 觸發。重算每一檔的持有回合、進場價、狀態。 */
function rebuildHoldingsTrackerJob() {
  var start = Date.now();

  /* 開始之前，先把「完全沒有日K」的那幾檔補起來。

     進場價、現價、報酬三欄都是從日K算出來的，所以一檔沒有K線的股票
     在表格上會是三個空格加一句「取不到進場價，可到後台按補齊日K並重算」。
     而會踩到這個的幾乎都是今天第一次被講到的股票——它才剛寫進操作紀錄，
     分批補日K的游標不一定輪得到它，那句話就會在網站上掛一整天。

     要人去按一個按鈕才會好的東西，本來就該自己好。這裡無條件跑一次，
     沒有缺的時候只是多讀一次已經要讀的那張表，成本接近零；
     真的有缺時通常也只有一兩檔，幾秒鐘就補完。

     包在 try 裡是因為它會對外請求，而對外請求一定會有失敗的一天。
     補不到就補不到，不可以因此讓整個重算掛掉——那樣損失比缺幾個數字大得多。 */
  try {
    var mk = fillMissingDailyK_(60);
    if (mk.checked) {
      Logger.log('自動補缺日K：' + mk.checked + ' 檔沒有資料，補成功 ' +
                 mk.filled + '、仍取不到 ' + mk.failed);
    }
  } catch (e) {
    Logger.log('自動補缺日K略過（不影響重算）：' + e);
  }

  var trades = readSheetObjects_('操作紀錄').filter(function (r) {
    return String(r['股票名稱'] || '').trim();
  });
  if (!trades.length) {
    Logger.log('操作紀錄是空的，無事可做');
    return;
  }

  // 分組。代號無效的用「名稱」當 key，不扔掉。
  var groups = {};
  trades.forEach(function (r) {
    var code = String(r['代號'] || '').trim();
    var name = String(r['股票名稱']).trim();
    var valid = /^\d{4,6}$/.test(code);
    var key = valid ? code : ('NAME:' + name);

    if (!groups[key]) {
      groups[key] = { code: valid ? code : '', name: name, valid: valid, records: [] };
    }

    var dir = String(r['方向']);
    groups[key].records.push({
      date: fmtDate_(r['日期']),
      reason: naturalReason_(r['理由摘錄']) || '未說明',
      direction: dir || '提及',
      kind: classifyDirection_(dir),
      // 同一天同一檔的動作先後。舊資料沒有這一欄，那時是 0，排序就退回優先級。
      seq: Number(r['序']) || 0,
      price: String(r['價位說明'] || '').trim(),
      // 價位說明與理由摘錄兩邊一起看。張震常常不在價位欄講價，
      // 而是在說明裡帶一句「會員在 235 買入」，那同樣是明確的成本。
      hint: parsePriceHint_(r['價位說明'], r['理由摘錄'], classifyDirection_(dir))
    });
  });

  // 併入「會員持股」。這是張震在影片中明講「會員目前持有 X」的那些，
  // 也就是信件裡「影片中明講之會員目前持有股票」那一段的來源。
  //
  // 它是第二種開倉方式：沒有對應買入紀錄時，第一次被明講持有就開一個回合。
  // 但那天並沒有成交，所以進場價只能取當日收盤，而且同一天若又出現
  // 觀望不碰或賣出，這一筆就不予採信（詳見 buildRounds_）。
  var holdOnlyOpened = {};
  readSheetObjects_('會員持股').forEach(function (r) {
    var code = String(r['代號'] || '').trim();
    var name = String(r['股票名稱'] || '').trim();
    if (!name) { return; }
    var valid = /^\d{4,6}$/.test(code);
    var key = valid ? code : ('NAME:' + name);
    if (!groups[key]) {
      groups[key] = { code: valid ? code : '', name: name, valid: valid, records: [] };
    }
    groups[key].records.push({
      date: fmtDate_(r['日期']),
      reason: naturalReason_(r['說明重點']) || r['目前立場'] || '會員持股',
      direction: '會員持股',
      kind: 'hold',
      seq: 0,          // 會員持股沒有序欄，排序一律走優先級
      price: '',
      hint: null
    });
  });

  var rows = [];
  var now = todayStr_();
  var stat = { ok: 0, noCode: 0, noPrice: 0, stated: 0, rejected: 0, noOpen: 0,
               autoClosed: 0, avoidClosed: 0, multiRound: 0, dropped: 0,
               holdOpened: 0, holdConflict: 0, refPrice: 0, filled: 0, unverified: 0, backward: 0, noDailyK: 0,
               holdDropped: 0, holdPending: 0 };
  var holdDroppedList = [];

  // 交易日曆：日K快取裡出現過的所有日期。用來判斷「幾個交易日沒再提及」。
  var tradingDays = (function () {
    var set = {};
    readSheetObjects_('日K快取').forEach(function (r) {
      var d = fmtDate_(r['日期']); if (d) { set[d] = 1; }
    });
    return Object.keys(set).sort();
  })();
  function tradingDaysAfter_(dateStr) {
    var n = 0;
    for (var i = 0; i < tradingDays.length; i++) { if (tradingDays[i] > dateStr) { n++; } }
    return n;
  }
  var STALE_TRADING_DAYS = 10;   // 超過這個交易日數沒再提及，自動視為已出場

  Object.keys(groups).forEach(function (key) {
    var g = groups[key];
    var recs = sortRecords_(g.records);
    var hasBuy = recs.some(function (r) { return r.kind === 'buy'; });
    var hasHold = recs.some(function (r) { return r.kind === 'hold'; });

    // 沒有任何開倉動作就沒有持有。只講過觀望或賣出的，不列入追蹤。
    if (!hasBuy && !hasHold) {
      stat.noOpen++;
      return;
    }

    // 轉譯錯誤剔除：若這一檔從頭到尾都沒有出現觀望／不碰／買入／賣出這類
    // 實質操作字眼，且首次理由也是「未說明」，很可能是語音辨識把某句話
    // 誤判成一檔股票，直接不列入追蹤。
    var firstOpen = recs.filter(function (r) {
      return r.kind === 'buy' || r.kind === 'hold';
    })[0];
    var hasRealAction = recs.some(function (r) {
      var d = String(r.direction || '');
      var t = String(r.reason || '');
      return /買|賣|觀望|不碰|持有|抱|會員持股/.test(d) ||
             /買|賣|觀望|不碰|抱著|加碼|減碼|停損|停利|持有/.test(t);
    });
    var firstReasonBlank = !firstOpen.reason || String(firstOpen.reason).trim() === '' ||
                           String(firstOpen.reason).trim() === '未說明';
    if (!hasRealAction && firstReasonBlank) {
      stat.dropped++;
      Logger.log('剔除疑似轉譯錯誤：' + g.name + '（' + g.code + '），無任何實質操作字眼且首次理由未說明');
      return;
    }

    var rounds = buildRounds_(recs, tradingDays);
    if (!rounds.length) {
      // 有持有聲明但每一次都撞上同日矛盾，最後一個回合都開不成。
      stat.holdConflict++;
      return;
    }

    // 由持有聲明開倉的回合要通過三個交易日的確認。
    // 期限內沒有被再次提到的，判定為擷取錯誤，整個回合移除。
    // 這裡只移除「未經確認的持有回合」，不影響同一檔由明講買入開的其他回合，
    // 所以一檔股票若後來真的講了買入，那一段仍然會保留下來。
    var pendingHold = false;
    rounds = rounds.filter(function (rd) {
      if (rd.openKind !== 'hold') { return true; }
      var st = holdConfirmState_(rd.open.date, recs, tradingDays);
      if (st === 'unconfirmed') {
        stat.holdDropped++;
        holdDroppedList.push(g.name + '（' + (g.valid ? g.code : '代號待確認') +
                             '）　' + rd.open.date + ' 起連續 ' + HOLD_CONFIRM_DAYS +
                             ' 個交易日未再被提及');
        return false;
      }
      if (st === 'pending') { rd.pending = true; pendingHold = true; }
      return true;
    });

    if (!rounds.length) {
      // 全部的回合都是未經確認的持有聲明，這一檔整個不列入。
      return;
    }
    if (pendingHold) { stat.holdPending++; }
    if (rounds.length > 1) { stat.multiRound++; }
    if (rounds[0].openKind === 'hold') {
      stat.holdOpened++;
      holdOnlyOpened[g.name] = 1;
    }

    var lastRound = rounds[rounds.length - 1];

    // 最後一個回合還開著時，套用逾期規則。
    // 出場日與出場價以「最後一次提及」當日為準（含會員持股與觀望注意）。
    if (!lastRound.close) {
      var lastMention = recs[recs.length - 1].date;
      if (tradingDaysAfter_(lastMention) > STALE_TRADING_DAYS) {
        lastRound.close = { date: lastMention, hint: null };
        lastRound.closeKind = '逾期未再提及';
        stat.autoClosed++;
      }
    }
    if (lastRound.closeKind === '觀望不碰') { stat.avoidClosed++; }

    var candles = g.valid ? getCachedDailyK(g.code) : null;
    if (!g.valid) { stat.noCode++; }

    // 日K快取沒有這一檔時的備援。
    //
    // 兩種情況會踩到：當天才第一次出現的股票（日K還沒補到），
    // 以及賣掉後又買回來、第二回合進場日就在最近幾天的標的。
    // 先前這種情況 candles 是空的，priceOnDate_ 直接回空字串，
    // 於是進場價、現價、報酬三欄全部空白，表格上看起來像壞掉。
    //
    // 備援順序：先用即時報價，再退回講者明講的價位。
    // 兩者都標明來源，不會被誤認為是從日K算出來的。
    var fallbackPx = 0, fallbackSrc = '';
    if (g.valid && (!candles || !candles.length)) {
      try {
        var qc = getQuoteCache() || {};
        var q = qc[g.code];
        var qp = q ? Number(q.price || q.last || 0) : 0;
        if (qp > 0) {
          fallbackPx = qp;
          fallbackSrc = '日K快取尚無此檔，暫以最新成交價估算';
        }
      } catch (e) { /* 取不到就往下走 */ }
      stat.noDailyK++;
    }

    // 逐回合定價。已結束的回合也要算，才能列出回合明細與已實現報酬。
    rounds.forEach(function (rd, idxRound) {
      rd.entry = ''; rd.entrySrc = ''; rd.exit = ''; rd.exitSrc = '';

      if (!candles || !candles.length) {
        // 沒有日K可算。用講者明講的價位優先，其次即時報價，
        // 總比三欄全空、看起來像壞掉要好。
        var h0 = (rd.openKind === 'hold') ? null : rd.open.hint;
        if (!h0) {
          for (var q0 = 0; q0 < recs.length; q0++) {
            if (recs[q0].date >= rd.open.date && recs[q0].hint && recs[q0].hint.value) {
              h0 = recs[q0].hint; break;
            }
          }
        }
        if (h0 && h0.value) {
          rd.entry = h0.value;
          rd.entrySrc = '張震明講 ' + h0.value + '（日K快取尚無此檔，未經K線驗證）';
        } else if (fallbackPx) {
          rd.entry = fallbackPx;
          rd.entrySrc = fallbackSrc;
        }
        return;
      }

      // 由「會員持股」開倉的回合，那天並沒有成交，所以絕不採用明講價，
      // 一律取當日收盤，代表「這天他說會員手上有，價位大約在這裡」。
      // 由「會員持股」開倉的回合本來沒有價位可用，只能取當日收盤。
      // 但講者後來若真的講到這一檔的價位（例如先說會員持有，隔幾天才說
      // 「2330 以下」），那個價位比當日收盤更能代表他心裡的成本區間，
      // 應該優先採用。只看本回合期間內的紀錄，不會跨到別的回合去。
      var openHint = rd.open.hint;
      if (rd.openKind === 'hold') {
        openHint = null;
        // 挑後續講到的價位之前先篩一次合理性。
        // 逐字稿裡的數字不一定是價位（月份、成數、名次都可能被抓成數字），
        // 挑到離譜的值不但沒幫助，還會蓋掉本來可用的當日收盤。
        var band = candles && candles.length ? {
          hi: Math.max.apply(null, candles.map(function (k) { return k.high; })),
          lo: Math.min.apply(null, candles.map(function (k) { return k.low; }))
        } : null;
        for (var hi2 = 0; hi2 < recs.length; hi2++) {
          var hr = recs[hi2];
          if (hr.date < rd.open.date) { continue; }
          if (rd.close && hr.date > rd.close.date) { break; }
          if (!hr.hint || !hr.hint.value) { continue; }
          var hv = hr.hint.value;
          if (band && (hv > band.hi * 1.3 || hv < band.lo * 0.7)) {
            Logger.log('    ' + g.name + ' 後續提到的 ' + hv +
                       ' 不在合理區間 ' + band.lo + '-' + band.hi + '，略過');
            continue;
          }
          openHint = hr.hint; break;
        }
      }
      /* 進場價的往前下限＝上一回合的出場日。
         回述成本是合理的（「會員在 2135 買的」），但不能回述到上一回合
         還沒結束的時候——那段期間的成交屬於上一回合，不是這一回合的進場。 */
      var buyFloor = (idxRound > 0 && rounds[idxRound - 1] && rounds[idxRound - 1].exitDate)
        ? rounds[idxRound - 1].exitDate
        : ((idxRound > 0 && rounds[idxRound - 1] && rounds[idxRound - 1].close)
            ? rounds[idxRound - 1].close.date : '');
      var r1 = priceOnDate_(candles, rd.open.date, openHint, g.name, '買入', buyFloor);
      rd.entry = r1.price;
      rd.entryDate = r1.date || rd.open.date;
      if (r1.src === '影片明講') {
        rd.entrySrc = '張震明講在 ' + rd.entry + ' 買入';
        stat.stated++;
      } else if (rd.openKind === 'hold') {
        rd.entrySrc = openHint
          ? '首次明講會員持有，後續提到 ' + openHint.value + ' 採用之'
          : '首次明講會員持有，取當日收盤';
      } else if (r1.filled) {
        // 成交日不等於發話日，要標明是往前回述還是往後等到的。
        if (r1.backward) {
          rd.entrySrc = '張震回述 ' + openHint.value + ' 的成本，' + r1.date + ' 曾成交於此';
          stat.backward++;
        } else {
          rd.entrySrc = '張震說' + (openHint.mode === 'below' ? '跌到 ' : '漲到 ') +
                        openHint.value + ' 買進，' + r1.date + ' 觸價';
          stat.filled++;
        }
      } else {
        rd.entrySrc = r1.src;   // 例如「當日收盤」「未觸價，取當日收盤」
        if (r1.unverified) { stat.unverified++; }
      }
      if (r1.rejected) { stat.rejected++; }

      if (rd.close) {
        // 觀望不碰與逾期都不是成交，一律用當日收盤，不採用任何明講價。
        var useHint = (rd.closeKind === '賣出') ? rd.close.hint : null;
        /* 出場價的往前下限＝這一回合實際成交的那一天。
           賣出不可能發生在買進之前，往前找越過那一天就是在編造。 */
        var sellFloor = rd.entryDate || rd.open.date;
        var r2 = priceOnDate_(candles, rd.close.date, useHint, g.name, '賣出', sellFloor);
        rd.exit = r2.price;
        rd.exitDate = r2.date || rd.close.date;
        if (r2.rejected) { stat.rejected++; }
        if (r2.src === '影片明講') {
          rd.exitSrc = '張震明講在 ' + rd.exit + ' 賣出';
        } else if (r2.filled) {
          rd.exitSrc = r2.backward
            ? ('張震回述 ' + useHint.value + ' 的出場價，' + r2.date + ' 曾成交於此')
            : ('張震說' + (useHint.mode === 'below' ? '跌到 ' : '漲到 ') +
               useHint.value + ' 賣出，' + r2.date + ' 觸價');
          if (r2.backward) { stat.backward++; } else { stat.filled++; }
        } else if (r2.unverified) {
          rd.exitSrc = '張震明講 ' + r2.unverified + '，日K快取查無觸價紀錄';
          stat.unverified++;
        } else if (rd.closeKind === '觀望不碰') {
          rd.exitSrc = '轉為觀望不碰，取當日收盤';
        } else if (rd.closeKind === '逾期未再提及') {
          rd.exitSrc = '逾 ' + STALE_TRADING_DAYS + ' 個交易日未再提及，取最後一次提及當日收盤';
        } else {
          rd.exitSrc = r2.src;
        }
      }
      rd.ret = (rd.entry && rd.exit) ? Math.round((rd.exit - rd.entry) / rd.entry * 10000) / 100 : null;
      // 還開著的回合先用最後一根收盤估一個未實現，讓累積報酬涵蓋到現在。
      if (!rd.close && rd.entry && candles.length) {
        var lastC = candles[candles.length - 1].close;
        if (lastC) { rd.ret = Math.round((lastC - rd.entry) / rd.entry * 10000) / 100; }
      }
    });

    if (lastRound.entry) { stat.ok++; } else if (g.valid) { stat.noPrice++; }

    // 參考價位：本回合進場當天沒講價（進場價只好用收盤），
    // 但後面某一天以「觀望注意」的身分講到了價位時，把那個價位撈出來標註。
    // 這只是佐證，不會改動進場價，因為那天並沒有成交。
    var refPrice = '', refSrc = '';
    if (lastRound.entrySrc === '當日收盤') {
      for (var ri = 0; ri < recs.length; ri++) {
        var r = recs[ri];
        if (r.date < lastRound.open.date) { continue; }
        if (lastRound.close && r.date > lastRound.close.date) { break; }
        if (r.kind !== 'note' || !r.hint) { continue; }
        // 一樣要通過當日高低驗證，避免把營收、億元、指數點位當成股價。
        var rp = priceOnDate_(candles, r.date, r.hint, g.name, '觀望注意');
        if (rp.src === '影片明講' || rp.filled) {
          refPrice = rp.price;
          refSrc = r.date + ' 觀望注意時提到 ' + rp.price;
          stat.refPrice++;
          break;
        }
      }
    }

    /* 提及次數。

       這個數字必須等於下面「逐日說明」的筆數，因為介面上它們是同一件事的
       兩種呈現：一個寫「影片提及 32 次」，一個把那 32 次一條一條列出來。
       先前一個從 recs 數、一個從去重後的 timeline 數，兩邊對不起來，
       而使用者會去數——數完發現只有 28 條，那個 32 就變成一個沒人相信的數字。

       所以改成先組 timeline，再拿它的筆數當提及次數。
       真正的數字在下面算完才填得出來，這裡先佔位。 */
    var mentions = 0;

    // 說明欄用最新一句有意義的說明。張震後續若補充（今天說抱著、今天說賣出等），
    // 要用最新的那句；只有完全沒有後續補充時才退回首次理由。
    var meaningful = recs.filter(function (r) {
      var t = String(r.reason || '').trim();
      return t && t !== '未說明' && t !== '會員持股';
    });
    var latestReason = naturalReason_(meaningful.length ? meaningful[meaningful.length - 1].reason
                                                       : (firstOpen.reason || '未說明'));

    // 逐日說明：列出這一檔「所有」被提到的日期，含買入前的討論與會員持股。
    // 同一天若有多筆（例如同日既講買入又列持股），各留一行，只去除完全重複的。
    var seen = {};
    var timeline = recs
      .filter(function (r) {
        var k = r.date + '|' + (r.direction || '') + '|' + (r.reason || '');
        if (seen[k]) { return false; }
        seen[k] = 1;
        return true;
      })
      .map(function (r) {
        var head = (r.direction || '提及');
        if (r.date === rounds[0].open.date) {
          if (r.kind === 'buy') { head = '首次買入'; }
          else if (r.kind === 'hold' && rounds[0].openKind === 'hold') { head = '首次明講會員持有'; }
        }
        var px = r.price && r.price !== '未說明' ? '（' + r.price + '）' : '';
        return r.date + '\u3000' + head + px + '：' + (naturalReason_(r.reason) || '未說明');
      })
      .join('\n');

    // 一對一：提及次數就是逐日說明的筆數。
    mentions = timeline ? timeline.split('\n').length : 0;

    // 回合明細：每一回合一行，讓「買了又賣、賣了又買」看得出來。
    var roundDetail = rounds.map(function (rd, idx) {
      var openWord = (rd.openKind === 'hold') ? '首次明講會員持有' : '買入';
      var head = '第 ' + (idx + 1) + ' 回合\u3000' + rd.open.date + ' ' + openWord;
      if (rd.entry) { head += ' ' + rd.entry; }
      // 條件價的成交日與發話日不同，要標出來，否則會以為當天就買到了。
      if (rd.entryDate && rd.entryDate !== rd.open.date) { head += '（' + rd.entryDate + ' 觸價）'; }
      if (rd.avoidIgnored && rd.avoidIgnored.length) {
        head += '　中途曾轉觀望不碰 ' + rd.avoidIgnored.length + ' 次但未出場';
      }
      if (!rd.close) { return head + ' \u2192 持有中'; }
      var tail = ' \u2192 ' + rd.close.date + ' ' +
                 (rd.closeKind === '賣出' ? '賣出' :
                  rd.closeKind === '觀望不碰' ? '轉觀望不碰視為出場' : '逾期未再提及視為出場');
      if (rd.exit) { tail += ' ' + rd.exit; }
      if (rd.exitDate && rd.exitDate !== rd.close.date) { tail += '（' + rd.exitDate + ' 觸價）'; }
      if (rd.ret !== null && rd.ret !== undefined) {
        tail += '（' + (rd.ret > 0 ? '+' : '') + rd.ret.toFixed(2) + '%）';
      }
      return head + tail;
    }).join('\n');

    // 累積報酬：把每一個已結束回合的報酬連乘起來，再乘上目前這一回合的未實現。
    // 用連乘而不是相加，因為那才是真的把同一筆錢滾過每一回合的結果；
    // 相加會把「跌五成再漲五成」算成打平，實際上是虧了四分之一。
    var cum = 1, cumParts = [];
    rounds.forEach(function (rd) {
      if (rd.ret === null || rd.ret === undefined) { return; }
      cum *= (1 + rd.ret / 100);
      cumParts.push((rd.ret > 0 ? '+' : '') + rd.ret.toFixed(2) + '%');
    });
    var cumRet = cumParts.length ? Math.round((cum - 1) * 10000) / 100 : null;

    var stillHeld = !lastRound.close;
    // 尚在確認期內的持有聲明要標出來，讓人知道它還沒被證實、隨時可能被移除。
    var pendingNote = lastRound.pending
      ? '持有聲明尚在 ' + HOLD_CONFIRM_DAYS + ' 個交易日確認期內，若期滿仍未再被提及將移除'
      : '';
    /* 期間講過不碰卻沒有出場的，要說明白為什麼還算持有中。

       每一次都附上完整理由會變成一大段：兩次不碰就是兩句「（某日明講會員持有，
       證明部位並未在某日離開）」，塞進表格的一格裡是一整片文字牆，
       實際看到的就是那個樣子。理由對每一次都一樣，講一次就夠；
       日期用月/日就好，年份在旁邊的欄位已經看得到。 */
    if (lastRound.avoidIgnored && lastRound.avoidIgnored.length) {
      var days = lastRound.avoidIgnored.map(function (d) {
        return String(d).slice(5);          // 2026/08/31 → 08/31
      });
      var ig = '期間轉觀望不碰 ' + days.length + ' 次（' + days.join('、') +
               '），之後仍明講會員持有，故不計出場';
      pendingNote = pendingNote ? (pendingNote + '\n' + ig) : ig;
    }
    var exitReason = stillHeld ? pendingNote :
      (lastRound.closeKind === '賣出' ? '明講賣出' :
       lastRound.closeKind === '觀望不碰' ? '轉為觀望不碰，視為出場' :
       '逾 ' + STALE_TRADING_DAYS + ' 個交易日未再提及，視為出場');

    // 進場價來源欄：持有中就顯示進場來源；已出場則同時標明出場價來源。
    var srcCol = lastRound.entrySrc;
    if (!stillHeld && lastRound.exitSrc) { srcCol = lastRound.entrySrc + '；' + lastRound.exitSrc; }

    rows.push([
      g.valid ? g.code : '代號待確認',
      g.name,
      rounds[0].open.date,                       // 首次買入日：整檔的追蹤起點
      lastRound.entry, srcCol,
      lastRound.close ? lastRound.close.date : '',
      lastRound.exit,
      stillHeld ? '持有中' : '已出場',
      mentions, latestReason, timeline, now,
      rounds.length,                             // 回合數
      lastRound.open.date,                       // 本回合進場日
      exitReason,                                // 出場原因
      roundDetail,                               // 回合明細
      refPrice, refSrc,                          // 參考價位（後續觀望注意提到的價）
      rounds[0].openKind === 'hold' ? '會員持股聲明' : '明講買入',   // 首次進場方式
      lastRound.openKind === 'hold' ? '會員持股聲明' : '明講買入',   // 本回合進場方式
      cumRet === null ? '' : cumRet,                              // 累積報酬
      cumParts.join(' × '),                                       // 各回合明細
      /* 回合JSON：績效歷史重算要用的結構化版本。

         「回合明細」那一欄是給人看的文字（第 1 回合　2026/08/20 買入 38.5 → …），
         反解析回結構化資料很脆弱，格式一改就整批算錯。這裡多存一份機器讀的，
         成本是一個欄位，換來的是「某一天到底持有哪幾檔、成本多少」可以精確回答。

         有了它，重算歷史績效就不必把整個追蹤重跑一百多次——那在 Apps Script
         的執行時間上限下根本跑不完。只要這一份加上日K收盤價就夠了。 */
      JSON.stringify(rounds.map(function (rd) {
        return {
          o: rd.open.date,                                  // 進場日（發話日）
          od: rd.entryDate || rd.open.date,                 // 實際成交日（條件價可能晚幾天）
          e: rd.entry || null,                              // 進場價
          c: rd.close ? rd.close.date : '',                 // 出場日
          x: rd.exit || null,                               // 出場價
          k: rd.openKind === 'hold' ? 'hold' : 'buy'
        };
      }))
    ]);
  });

  withLock_(function () {
    var sh = getSheet_('持股追蹤');
    sh.clearContents();
    var headers = ['代號', '股票名稱', '首次買入日', '進場價', '進場價來源',
                   '最近賣出日', '出場價', '狀態', '提及次數', '首次理由', '逐日說明', '更新時間',
                   '回合數', '本回合進場日', '出場原因', '回合明細', '參考價位', '參考價位來源',
                   '首次進場方式', '本回合進場方式', '累積報酬', '各回合報酬', '回合JSON'];
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    if (rows.length) { sh.getRange(2, 1, rows.length, headers.length).setValues(rows); }
  });

  CACHE.remove('tracker');

  Logger.log('持股追蹤重算完成，共 ' + rows.length + ' 檔（耗時 ' +
             Math.round((Date.now() - start) / 1000) + ' 秒）');
  Logger.log('  進場價已算出　' + stat.ok + ' 檔（其中 ' + stat.stated + ' 次用影片明講的價格）');
  if (stat.multiRound) {
    Logger.log('  有兩段以上持有回合（賣出後又買回）　' + stat.multiRound + ' 檔');
  }
  if (stat.avoidClosed) {
    Logger.log('  最後由「觀望不碰」平倉　' + stat.avoidClosed + ' 檔');
  }
  if (stat.autoClosed) {
    Logger.log('  超過 ' + STALE_TRADING_DAYS + ' 個交易日未再提及，自動轉為已出場　' + stat.autoClosed + ' 檔');
  }
  if (stat.filled) {
    Logger.log('  條件價往後找到觸價日才成交　' + stat.filled + ' 次');
    Logger.log('  （例如「255 以上賣掉」，講的當天還沒到，後來漲抵才算成交）');
  }
  if (stat.backward) {
    Logger.log('  往前找到觸價日（講者回述先前成本）　' + stat.backward + ' 次');
    Logger.log('  （例如「會員在 2135 買的」，2135 是過去成交價，不是當天的）');
  }
  if (stat.unverified) {
    Logger.log('  明講價在日K快取中查無觸價紀錄，仍採用明講價　' + stat.unverified + ' 次');
    Logger.log('  （多半是日K快取沒涵蓋到那一段，可執行 backfillDailyKJob() 補齊）');
  }
  if (stat.refPrice) {
    Logger.log('  進場當天未說明價位，改由後續「觀望注意」補上參考價位　' + stat.refPrice + ' 檔');
  }
  if (stat.noOpen) {
    Logger.log('  沒有任何開倉動作（既沒買入、也沒被明講會員持有），未列入　' + stat.noOpen + ' 檔');
  }
  if (stat.holdOpened) {
    Logger.log('  由「影片中明講會員持有」開倉、沒有對應買入紀錄的　' + stat.holdOpened + ' 檔：' +
               Object.keys(holdOnlyOpened).slice(0, 20).join('、'));
    Logger.log('  這些進場價取當日收盤，因為那天並沒有成交。');
  }
  if (stat.holdDropped) {
    Logger.log('  持有聲明未通過 ' + HOLD_CONFIRM_DAYS + ' 個交易日確認，判定為擷取錯誤已移除　' +
               stat.holdDropped + ' 筆：');
    holdDroppedList.slice(0, 30).forEach(function (t) { Logger.log('      ' + t); });
    if (holdDroppedList.length > 30) {
      Logger.log('      ……另有 ' + (holdDroppedList.length - 30) + ' 筆');
    }
  }
  if (stat.holdPending) {
    Logger.log('  持有聲明尚在確認期內（未滿 ' + HOLD_CONFIRM_DAYS + ' 個交易日），暫時保留　' +
               stat.holdPending + ' 檔');
    Logger.log('  這些會標為待確認。等確認期過完，下一次重算才會判定要留還是要移除。');
  }
  if (stat.holdConflict) {
    Logger.log('  有持有聲明但同日又被講成觀望不碰或賣出，不予採信　' + stat.holdConflict + ' 檔');
  }
  if (stat.rejected) {
    Logger.log('  明講價未通過當日高低驗證，已退回收盤價　' + stat.rejected + ' 筆');
  }
  if (stat.noDailyK) {
    Logger.log('  日K快取沒有這一檔，已改用明講價或即時報價估算　' + stat.noDailyK + ' 檔');
    Logger.log('  （多半是當天新增或剛買回的標的。執行 backfillDailyKJob() 補齊後會更準）');
  }
  if (stat.noCode) {
    Logger.log('  代號待確認　　' + stat.noCode + ' 檔　<<< 請執行 repairCodesJob()，或到 GitHub 重跑 backfill');
  }
  if (stat.noPrice) {
    Logger.log('  缺進場價　　　' + stat.noPrice + ' 檔　<<< 日K快取還沒補到，請多執行幾次 backfillDailyKJob()');
  }
  return stat;
}

/**
 * 前端用。讀持股追蹤分頁，配上即時快取算出目前報酬。
 * 全部從試算表讀，不對外請求，所以很快。
 */
function getHoldingsTracker() {
  var hit = CACHE.get('tracker');
  if (hit) { return JSON.parse(hit); }

  var base = readSheetObjects_('持股追蹤');
  if (!base.length) {
    return {
      items: [], summary: null,
      note: '持股追蹤尚未建立。管理者請在 Apps Script 執行 bootstrapAll()。',
      basis: ''
    };
  }

  var quotes = getQuoteCache();
  var today = todayStr_();
  // 補日K時記下來的失敗原因。讀不到就當空的，說明文字自動退回一般版本。
  var missReason = (typeof dailyKMissingReasons_ === 'function')
    ? dailyKMissingReasons_() : {};

  var items = base.map(function (r) {
    var code = String(r['代號']).trim();
    var valid = /^\d{4,6}$/.test(code);
    var stillHeld = String(r['狀態']) === '持有中';
    var entry = Number(r['進場價']) || null;
    var entrySrc = r['進場價來源'] || '';

    var current = null, curSrc = '';
    if (!valid) {
      current = null;
    } else if (stillHeld) {
      // 持有中：以最新價格計算未實現損益。
      // 即時快取只在盤中更新，取不到就用日K最後一根收盤價。
      var q = quotes[code];
      if (q && q.last != null) {
        current = q.last;
        curSrc = '即時';
      } else {
        var lc = lastCloseOf_(code);
        if (lc) { current = lc.last; curSrc = lc.date + ' 收盤'; }
      }
    } else {
      // 已出場：報酬必須用「賣出當日的價格」算，這是已實現損益，是固定的事實。
      // 絕對不可以用今天的價格代替，否則賣出後股價再漲跌，
      // 已經結束的那筆交易的報酬率會跟著變動，那是錯的。
      current = Number(r['出場價']) || null;
      curSrc = current ? '賣出當日' : '';
    }

    var ret = (entry && current) ? Math.round((current - entry) / entry * 10000) / 100 : null;
    var firstBuy = fmtDate_(r['首次買入日']);
    // 持有天數要用「本回合進場日」算，不是整檔的首次買入日。
    // 賣掉又買回來的標的，用首次買入日會把中間沒持有的那段也算進去。
    var roundStart = fmtDate_(r['本回合進場日']) || firstBuy;
    var endDate = stillHeld ? today : fmtDate_(r['最近賣出日']);

    /* 缺數字的時候要講出真正的原因。

       原本三種情況都只寫「可到後台按補齊日K並重算」，但那句話有時候是錯的：
       這一檔如果根本查不到歷史行情（代號打錯、剛上市、已下市），
       按幾次都不會好，而使用者會一直按。現在重算之前已經會自動補一次，
       所以還缺的必然是補不到，那就把補不到的理由直接寫出來。 */
    var why = '';
    if (!valid) { why = '代號待確認，無法取價'; }
    else if (!entry) {
      var r1 = missReason[code];
      why = r1 ? ('這一檔取不到歷史行情（' + r1 + '），因此算不出進場價')
               : '進場價尚未算出。日K可能還在補，下一次重算會補上';
    }
    else if (!current) {
      var r2 = missReason[code];
      why = r2 ? ('這一檔取不到歷史行情（' + r2 + '），因此沒有現價')
               : '日K快取還沒有這一檔的最新報價，下一次重算會補上';
    }

    return {
      code: code, name: r['股票名稱'], valid: valid,
      firstBuy: firstBuy, firstReason: r['首次理由'] || '未說明',
      timeline: r['逐日說明'] || '',
      lastSell: fmtDate_(r['最近賣出日']), stillHeld: stillHeld,
      days: daysBetween_(roundStart, endDate),
      entry: entry, entrySrc: entrySrc, current: current, curSrc: curSrc, ret: ret,
      mentions: Number(r['提及次數']) || 0,
      why: why,
      // 回合模型：買了又賣、賣了又買時，表格顯示的是最新那一回合
      rounds: Number(r['回合數']) || 1,
      roundStart: roundStart,
      exitReason: r['出場原因'] || '',
      roundDetail: r['回合明細'] || '',
      // 進場當天沒講價、後續以「觀望注意」提到的價位。只作佐證，不改進場價。
      refPrice: Number(r['參考價位']) || null,
      refSrc: r['參考價位來源'] || '',
      // 進場方式：明講買入，或第一次被明講「會員目前持有」。
      // 後者沒有成交價，進場價是當日收盤，介面上要標示清楚以免誤解。
      openBy: r['本回合進場方式'] || '明講買入',
      firstOpenBy: r['首次進場方式'] || '明講買入',
      // 多回合時的累積報酬（各回合連乘）與各回合明細
      cumRet: (r['累積報酬'] === '' || r['累積報酬'] == null) ? null : Number(r['累積報酬']),
      roundRets: r['各回合報酬'] || ''
    };
  });

  function byReturn(a, b) {
    if ((a.ret === null) !== (b.ret === null)) { return a.ret === null ? 1 : -1; }
    if (a.ret === null) { return b.days - a.days; }
    return b.ret - a.ret;
  }

  // 持有中與已出場必須分開呈現，因為兩者的報酬意義不同：
  // 持有中是「未實現損益」，會隨股價變動；
  // 已出場是「已實現損益」，用買入價與賣出價算，賣出後就固定不再變。
  // 混在一起看會誤以為是同一種數字。
  var held = items.filter(function (i) { return i.stillHeld; }).sort(byReturn);
  var exited = items.filter(function (i) { return !i.stillHeld; }).sort(byReturn);

  function summarize(list) {
    var priced = list.filter(function (i) { return i.ret !== null; });
    if (!priced.length) {
      return { total: list.length, priced: 0, pending: list.length, avgReturn: null, positiveRatio: null };
    }
    var sum = priced.reduce(function (s, i) { return s + i.ret; }, 0);
    return {
      total: list.length,
      priced: priced.length,
      pending: list.length - priced.length,
      avgReturn: Math.round(sum / priced.length * 100) / 100,
      positiveRatio: Math.round(priced.filter(function (i) { return i.ret > 0; }).length / priced.length * 1000) / 10
    };
  }

  var heldSummary = summarize(held);
  var exitedSummary = summarize(exited);

  // 舊欄位保留，內容維持「持有中」的統計，避免其他呼叫端壞掉
  var summary = heldSummary.priced ? {
    total: items.length,
    holding: held.length,
    priced: heldSummary.priced,
    pending: heldSummary.pending,
    avgReturn: heldSummary.avgReturn,
    positiveRatio: heldSummary.positiveRatio
  } : null;

  var out = {
    items: held.concat(exited),
    held: held,
    exited: exited,
    heldSummary: heldSummary,
    exitedSummary: exitedSummary,
    summary: summary,
    note: '',
    heldBasis: '持有中為未實現損益。同一檔可能買了又賣、賣了又買，因此以「回合」計算：一個回合是一次進場到一次出場，表格顯示的是最新那一個回合，進場價與持有天數都從本回合進場日起算。進場價取本回合進場當日的收盤價，影片若明講了價格且該價格落在當日最高與最低之間，才改用明講價。報酬以最新成交價計算，盤後或取不到即時報價時用最後一根日K收盤價，因此會隨股價每日變動。',
    exitedBasis: '已出場為已實現損益，用本回合的進場價與出場價計算，出場之後不再變動，後續股價漲跌與這個數字無關。出場有三種情形：明講賣出時取賣出當日價；轉為「觀望不碰」時視為出場，取當日收盤價，因為那不是一筆成交而是立場由持有轉為不碰；超過 10 個交易日未再被提及時自動視為出場，取最後一次提及當日收盤價。',
    basis: '進場有兩種認定：影片中明講買入，或影片中明講「會員目前持有」而先前沒有對應的買入紀錄。後者那天並沒有成交，進場價取當日收盤，表格會標示為會員持股聲明。同一天若又被講成觀望不碰或賣出，該筆持有聲明不予採信。觀望注意不影響持有狀態，觀望不碰視為出場。未計入交易成本與部位大小。'
  };

  CACHE.put('tracker', JSON.stringify(out), 300);
  return out;
}

/** 個股在追蹤表裡的單筆資料 */
function getStockTracker(code) {
  code = String(code || '').trim();
  var all = getHoldingsTracker();
  return all.items.filter(function (i) { return i.code === code; })[0] || null;
}

/* ------------------------------------------------------------------ *
 * 4.4 查詢功能
 * ------------------------------------------------------------------ */

function searchStock(keyword) {
  var kw = String(keyword || '').trim();
  if (!kw) { return { keyword: '', trades: [], holdings: [], found: false }; }

  function hit(r) {
    return String(r['股票名稱']).indexOf(kw) >= 0 || String(r['代號']).indexOf(kw) >= 0;
  }

  /* 「影片中提到的每一次」要與「每天講了什麼」是同一份清單。

     先前這裡只讀操作紀錄，而逐日說明讀的是操作紀錄加會員持股，
     於是同一個面板上兩個區塊列出來的筆數不一樣——上面說提及 32 次，
     下面的表只有 28 列，而且少掉的正好是他明講會員持有的那幾天。
     兩邊都是「他提到這一檔」的紀錄，本來就該是同一份。 */
  var seen = {};
  function dedupe_(x) {
    var k = x.date + '|' + x.direction + '|' + x.reason;
    if (seen[k]) { return false; }
    seen[k] = 1;
    return true;
  }

  var trades = readSheetObjects_('操作紀錄').filter(hit).map(function (r) {
    return {
      date: fmtDate_(r['日期']),
      name: r['股票名稱'],
      code: r['代號'] || '代號待確認',
      direction: r['方向'],
      price: r['價位說明'] || '未說明',
      reason: naturalReason_(r['理由摘錄']) || '未說明',
      videoId: r['來源影片ID'],
      seq: Number(r['序']) || 0
    };
  });

  var holdings = readSheetObjects_('會員持股').filter(hit).map(function (r) {
    return {
      date: fmtDate_(r['日期']),
      name: r['股票名稱'],
      code: r['代號'] || '代號待確認',
      stance: r['目前立場'],
      note: naturalReason_(r['說明重點']),
      videoId: r['來源影片ID']
    };
  }).sort(function (a, b) { return a.date < b.date ? 1 : -1; });

  // 會員持股併進來，方向就寫「會員持股」，價位那一欄它本來就沒有。
  holdings.forEach(function (h) {
    trades.push({
      date: h.date, name: h.name, code: h.code,
      direction: '會員持股', price: '未說明',
      reason: h.note || h.stance || '會員持股',
      videoId: h.videoId, seq: 0
    });
  });

  // 去重之後由新到舊。同一天有多筆時，序小的排前面（早上的動作在上面）。
  trades = trades.filter(dedupe_).sort(function (a, b) {
    if (a.date !== b.date) { return a.date < b.date ? 1 : -1; }
    return (a.seq || 99) - (b.seq || 99);
  });

  var buys = trades.filter(function (t) { return t.direction.indexOf('買') === 0; });
  var sells = trades.filter(function (t) { return t.direction.indexOf('賣') === 0; });

  return {
    keyword: kw,
    found: !!(trades.length || holdings.length),
    firstBuy: buys.length ? buys[buys.length - 1].date : '',
    lastSell: sells.length ? sells[0].date : '',
    stillHeld: buys.length > 0 && (!sells.length || sells[0].date < buys[0].date),
    trades: trades,
    holdings: holdings
  };
}

/**
 * 有紀錄的日期清單，新到舊。供「翻到某一天」的日曆標記哪幾天點得下去。
 * 只列出真的有操作紀錄或會員持股的日期，沒資料的日期在日曆上就是不可點，
 * 使用者不必先點下去才發現那天沒東西。
 */
function listRecordDates() {
  var hit = CACHE.get('recordDates');
  if (hit) { return JSON.parse(hit); }

  var set = {};
  readSheetObjects_('操作紀錄').forEach(function (r) {
    var d = fmtDate_(r['日期']); if (d) { set[d] = (set[d] || 0) + 1; }
  });
  readSheetObjects_('會員持股').forEach(function (r) {
    var d = fmtDate_(r['日期']); if (d) { set[d] = (set[d] || 0) + 1; }
  });

  var out = Object.keys(set).sort().reverse().map(function (d) {
    return { date: d, count: set[d] };
  });
  CACHE.put('recordDates', JSON.stringify(out), 300);
  return out;
}

function searchByDate(dateStr) {
  var d = fmtDate_(dateStr);
  var trades = readSheetObjects_('操作紀錄').filter(function (r) { return fmtDate_(r['日期']) === d; });
  var holds = readSheetObjects_('會員持股').filter(function (r) { return fmtDate_(r['日期']) === d; });
  var video = readSheetObjects_('影片清單').filter(function (r) { return fmtDate_(r['發布日期']) === d; })[0];

  return {
    date: d,
    found: !!(trades.length || holds.length),
    videoId: video ? video['影片ID'] : '',
    videoTitle: video ? video['標題'] : '',
    status: video ? video['處理狀態'] : '',
    buy: trades.filter(function (r) { return String(r['方向']).indexOf('買') === 0; }).map(mapTrade_),
    sell: trades.filter(function (r) { return String(r['方向']).indexOf('賣') === 0; }).map(mapTrade_),
    watchAvoid: trades.filter(function (r) { return String(r['方向']).indexOf('觀望不碰') >= 0 || String(r['方向']).indexOf('不碰') >= 0; }).map(mapTrade_),
    watchWatch: trades.filter(function (r) { return String(r['方向']).indexOf('觀望注意') >= 0; }).map(mapTrade_),
    watch: trades.filter(function (r) { return String(r['方向']).indexOf('買') < 0 && String(r['方向']).indexOf('賣') < 0; }).map(mapTrade_),
    // 同一天不可能既列在會員持股、又被歸到觀望不碰或賣出，那是擷取誤判。
    // 這種列留著只會讓當天的會員持股出現方向是觀望不碰的股票，所以直接濾掉。
    holdings: (function () {
      var conflict = {};
      trades.forEach(function (r) {
        var dir = String(r['方向']);
        if (dir.indexOf('觀望不碰') >= 0 || dir.indexOf('不碰') >= 0 || dir.indexOf('賣') === 0) {
          conflict[String(r['股票名稱'] || '').trim()] = 1;
        }
      });
      return holds
        .filter(function (r) { return !conflict[String(r['股票名稱'] || '').trim()]; })
        .map(function (r) {
          return { name: r['股票名稱'], code: r['代號'] || '代號待確認',
                   stance: r['目前立場'], note: naturalReason_(r['說明重點']) };
        });
    })()
  };
}

function mapTrade_(r) {
  return {
    name: r['股票名稱'],
    code: r['代號'] || '代號待確認',
    price: r['價位說明'] || '未說明',
    reason: naturalReason_(r['理由摘錄']) || '未說明'
  };
}

/* ------------------------------------------------------------------ *
 * 4.6 使用者上下文記憶
 * ------------------------------------------------------------------ */

function rememberQuery(email, keyword) {
  if (!email || !keyword) { return; }
  withLock_(function () {
    var sh = getSheet_('使用者上下文記憶');
    var rows = sh.getDataRange().getValues();
    for (var i = 1; i < rows.length; i++) {
      if (String(rows[i][0]).toLowerCase() === String(email).toLowerCase()) {
        var hist = String(rows[i][1] || '').split(',').filter(String);
        hist.unshift(keyword);
        hist = hist.filter(function (v, idx, arr) { return arr.indexOf(v) === idx; }).slice(0, 12);
        sh.getRange(i + 1, 2).setValue(hist.join(','));
        sh.getRange(i + 1, 4).setValue(todayStr_());
        return;
      }
    }
    sh.appendRow([email, keyword, '', todayStr_()]);
  });
}

function getUserContext(email) {
  if (!email) { return { recent: [] }; }
  var rows = readSheetObjects_('使用者上下文記憶').filter(function (r) {
    return String(r['使用者識別']).toLowerCase() === String(email).toLowerCase();
  });
  if (!rows.length) { return { recent: [] }; }
  return { recent: String(rows[0]['歷史互動摘要'] || '').split(',').filter(String) };
}

/* ------------------------------------------------------------------ *
 * 3.5.3 年度封存
 * ------------------------------------------------------------------ */

function yearlyArchiveJob() {
  var now = new Date();
  if (Number(Utilities.formatDate(now, TZ, 'M')) !== 1) { return; }

  var lastYear = Number(Utilities.formatDate(now, TZ, 'yyyy')) - 1;
  ['操作紀錄', '每日推播內容', '影片清單'].forEach(function (name) {
    archiveSheetYear_(name, lastYear);
  });
}

function archiveSheetYear_(sheetName, year) {
  withLock_(function () {
    var ss = getSS_();
    var sh = ss.getSheetByName(sheetName);
    var target = sheetName + '_' + year;
    if (ss.getSheetByName(target)) { return; }

    var values = sh.getDataRange().getValues();
    if (values.length < 2) { return; }
    var headers = values[0];
    var dateCol = headers.indexOf('日期') >= 0 ? headers.indexOf('日期') : headers.indexOf('發布日期');
    if (dateCol < 0) { return; }

    var keep = [], move = [];
    values.slice(1).forEach(function (row) {
      var d = fmtDate_(row[dateCol]);
      if (d && Number(d.slice(0, 4)) === year) { move.push(row); } else { keep.push(row); }
    });
    if (!move.length) { return; }

    var arch = ss.insertSheet(target);
    arch.getRange(1, 1, 1, headers.length).setValues([headers]);
    arch.getRange(2, 1, move.length, headers.length).setValues(move);

    sh.clearContents();
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    if (keep.length) { sh.getRange(2, 1, keep.length, headers.length).setValues(keep); }

    ss.getSheetByName('資料索引').appendRow([target, sheetName, year + '/01/01 至 ' + year + '/12/31', todayStr_()]);
  });
}

/**
 * 乾跑：列出「由會員持股聲明開倉」的每一檔目前的確認狀態，不寫任何資料。
 *
 * 用途是在真的重算之前先看一眼會刪掉哪些，確認不是誤刪。
 * 直接在編輯器執行這一支，看執行紀錄即可，跑完不會動到試算表。
 */
function auditUnconfirmedHoldings() {
  var trades = readSheetObjects_('操作紀錄').filter(function (r) {
    return String(r['股票名稱'] || '').trim();
  });
  var groups = {};
  function push_(name, code, date, dir, reason, seq) {
    if (!name) { return; }
    var valid = /^\d{4,6}$/.test(String(code || '').trim());
    var key = valid ? String(code).trim() : ('NAME:' + name);
    if (!groups[key]) {
      groups[key] = { code: valid ? String(code).trim() : '', name: name, valid: valid, records: [] };
    }
    groups[key].records.push({
      date: fmtDate_(date), reason: reason || '', direction: dir || '',
      kind: classifyDirection_(dir), seq: Number(seq) || 0, price: '', hint: null
    });
  }
  trades.forEach(function (r) {
    push_(String(r['股票名稱']).trim(), r['代號'], r['日期'], String(r['方向']),
          r['理由摘錄'], r['序']);
  });
  readSheetObjects_('會員持股').forEach(function (r) {
    push_(String(r['股票名稱'] || '').trim(), r['代號'], r['日期'], '會員持股',
          r['說明重點'] || r['目前立場'] || '會員持股');
  });

  var tradingDays = (function () {
    var set = {};
    readSheetObjects_('日K快取').forEach(function (r) {
      var d = fmtDate_(r['日期']); if (d) { set[d] = 1; }
    });
    return Object.keys(set).sort();
  })();

  var out = { confirmed: [], unconfirmed: [], pending: [] };
  Object.keys(groups).forEach(function (key) {
    var g = groups[key];
    var recs = sortRecords_(g.records);
    buildRounds_(recs, tradingDays).forEach(function (rd) {
      if (rd.openKind !== 'hold') { return; }
      var st = holdConfirmState_(rd.open.date, recs, tradingDays);
      var after = recs.filter(function (r) { return r.date > rd.open.date; });
      out[st].push(g.name + '（' + (g.valid ? g.code : '代號待確認') + '）　開倉 ' +
                   rd.open.date + '　之後被提及 ' + after.length + ' 次' +
                   (after.length ? '，最近一次 ' + after[after.length - 1].date : ''));
    });
  });

  Logger.log('===== 會員持股聲明確認狀態（乾跑，未寫入任何資料）=====');
  Logger.log('確認門檻：開倉後 ' + HOLD_CONFIRM_DAYS + ' 個交易日內至少要再被提及一次');
  Logger.log('');
  Logger.log('【會被移除】期限已過且完全沒有後續　' + out.unconfirmed.length + ' 筆');
  out.unconfirmed.forEach(function (t) { Logger.log('    ' + t); });
  Logger.log('');
  Logger.log('【暫時保留】確認期還沒過完　' + out.pending.length + ' 筆');
  out.pending.forEach(function (t) { Logger.log('    ' + t); });
  Logger.log('');
  Logger.log('【會保留】期限內有再被提及　' + out.confirmed.length + ' 筆');
  out.confirmed.slice(0, 40).forEach(function (t) { Logger.log('    ' + t); });
  if (out.confirmed.length > 40) {
    Logger.log('    ……另有 ' + (out.confirmed.length - 40) + ' 筆');
  }
  Logger.log('');
  Logger.log('確認名單沒問題後，執行 rebuildHoldingsTrackerJob() 套用，');
  Logger.log('或用網站的「立即刷新網站內容」一次跑完全站重算。');
  return out;
}


/* ==================================================================== *
 * 逐字稿瀏覽
 * ==================================================================== */

/** 有逐字稿的日期清單，供日曆標記哪幾天點得下去。 */
function listTranscriptDates() {
  var hit = CACHE.get('txDates');
  if (hit) { return JSON.parse(hit); }

  var byDate={},groups={};
  readSheetObjects_('影片清單').forEach(function(r){
    var d=fmtDate_(r['發布日期']);if(d){(groups[d]||(groups[d]=[])).push(r);}
  });
  Object.keys(groups).forEach(function(d){
    var selected=selectTranscriptRow_(groups[d],'',d).row;
    var text=displayTranscriptText_(selected);if(text.length<200){return;}
    byDate[d]={date:d,chars:text.length,title:String(selected['標題']||selected['影片標題']||''),
      videoId:String(selected['影片ID']||''),raw:text===String(selected['原始逐字稿內容']||'')};
  });
  var out = Object.keys(byDate).map(function (k) { return byDate[k]; });
  out.sort(function (a, b) { return a.date < b.date ? 1 : -1; });
  CACHE.put('txDates', JSON.stringify(out), 300);
  return out;
}

/**
 * 取某一天的逐字稿，並排好版。
 *
 * 直接把兩萬字倒出來沒有人看得下去：沒有段落、沒有重點、找不到位置。
 * 所以要分段。分段有兩種做法，這裡兩種都用：
 *   1. 規則分段　依句號與長度切，保證一定有結果，而且不花錢。
 *   2. AI 分段　　讓模型判斷語意轉折並下小標，讀起來像文章。
 * AI 的結果會存回快取，同一天第二次開就直接用，不重複花錢。
 */
function getTranscript(dateStr) {
  var d = fmtDate_(dateStr);

  // 同一天可能有多列。後台投稿會用 MANUAL-日期 當影片ID 另外建一列，
  // 若當天稍後又補上了真正的影片，就會出現一列有內容、一列全空的情況。
  // 先前用 forEach 逐列覆蓋，最後留下的是「最後一列」而不是「有內容那列」，
  // 於是明明資料就在試算表裡，畫面卻說沒有逐字稿。
  // 改成挑內容最長的那一列。
  var selected=selectTranscriptRow_(readSheetObjects_('影片清單'),'',d);
  var row=selected ? selected.row : null;
  if (!row) { return { found: false, date: d }; }

  var v2 = displayTranscriptText_(row);
  var v1 = String(row['原始逐字稿內容'] || '');
  var isRaw = v2 === v1;

  if (v2.length < 200) {
    if (v1.length >= 200) {
      // 只有原始稿也要能看。潤飾只是把口語整理得好讀，
      // 內容本身兩者相同，核對原話時原始稿甚至更貼近實際。
      v2 = v1; isRaw = true;
    } else {
      return { found: false, date: d,
               reason: '這一天的影片清單裡沒有逐字稿內容（修飾後 ' + v2.length +
                       ' 字、原始 ' + v1.length + ' 字）。' +
                       '可能是還沒處理完，或該列的逐字稿欄位是空的。' };
    }
  }

  var cacheKey = transcriptFormatCacheKey_(d,v2);
  var cached = CACHE.get(cacheKey);
  if (cached) {
    return { found: true, date: d, title: String(row['標題'] || row['影片標題'] || ''),
             videoId: String(row['影片ID'] || ''), chars: v2.length, raw: isRaw,
             sections: JSON.parse(cached), formatted: true };
  }

  return { found: true, date: d, title: String(row['標題'] || row['影片標題'] || ''),
           videoId: String(row['影片ID'] || ''), chars: v2.length, raw: isRaw,
           sections: splitTranscriptByRule_(v2), formatted: false };
}

/** 規則分段。不呼叫 AI，永遠可用。 */
function splitTranscriptByRule_(text) {
  var parts=String(text||'').replace(/\r/g,'').split(/\n+/),out=[],buf='';
  parts.forEach(function(line){
    var sentences=line.trim().match(/[^。！？]+[。！？]?|[。！？]/g)||[];
    sentences.forEach(function(sentence){
      if(buf && buf.length+sentence.length>320){out.push(buf);buf='';}
      buf+=sentence;
    });
    if(buf.length>=160){out.push(buf);buf='';}
  });
  if(buf){out.push(buf);}
  return [{title:'',paras:out}];
}

function displayTranscriptText_(row) {
  var raw=String(row['原始逐字稿內容']||''),polished=String(row['修飾後逐字稿內容']||'');
  function words(s){return s.replace(/[\s，。！？、；：,.!?;:「」『』“”‘’（）()【】\[\]《》<>\-—_＊*]/g,'');}
  // Old display drafts may have introduced different companies. They cannot be
  // rehabilitated by a second AI formatter; display the original words instead.
  if(raw && words(raw)!==words(polished)){return raw;}
  return polished || raw;
}
function transcriptFormatCacheKey_(d,text) {
  return 'txfmt_v2_'+d+'_'+Utilities.base64EncodeWebSafe(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,text)).slice(0,16);
}


var TX_FORMAT_SYSTEM =
  '你要把一段直播逐字稿整理成好讀的版面。這是排版工作，不是改寫。\n' +
  '\n' +
  '=== 絕對禁止 ===\n' +
  '一個字都不能改。不可以改寫、摘要、省略、補字、修正錯字或調整用詞。\n' +
  '講者講錯話、重複、語句不通順，都照原樣保留。\n' +
  '你唯一能做的事是決定「在哪裡分段」以及「每一段的小標」。\n' +
  '\n' +
  '=== 在哪裡分段 ===\n' +
  '以下六種情況出現時就換一段。判斷依據是「講者換了話題」，\n' +
  '不是字數到了就切——切在半句話中間會比不分段更難讀。\n' +
  '\n' +
  '1. 換一檔股票。從一檔講到另一檔，是最明確的分段點。\n' +
  '2. 從大盤轉到個股，或從個股回到大盤。\n' +
  '3. 從講行情轉到講操作。例如講完技術面之後開始說「所以今天可以買」。\n' +
  '4. 開始回答會員提問，或提問結束回到盤勢。\n' +
  '5. 插入題外話。講者常突然講到時事、抱怨、講古，那整段自成一段。\n' +
  '6. 時間推進。例如「等一下開盤」「收盤前再看」這種明顯的時間切換。\n' +
  '\n' +
  '每段大約三到八句。超過十句一定要找地方切開，\n' +
  '但寧可一段十句也不要切在一句話的中間。\n' +
  '同一檔股票講很久時，可以依「技術面／基本面／操作建議」再切細。\n' +
  '\n' +
  '=== 小標怎麼下 ===\n' +
  '八個字以內，直接寫那一段在講什麼，讓人掃過去就知道要不要細看。\n' +
  '有講到特定股票就把名稱放進去，那是讀者最想找的東西。\n' +
  '\n' +
  '好的小標：「鴻海的操作建議」「開盤大盤看法」「會員問記憶體」「聊到最近的新聞」\n' +
  '不好的小標：「內容一」「講者說明」「這一段」（沒有資訊）\n' +
  '不好的小標：「講者針對鴻海這一檔股票提出的操作面建議」（太長）\n' +
  '\n' +
  '=== 輸出 ===\n' +
  'text 必須是原文的連續片段。把所有段落的 text 依序接起來，\n' +
  '要能還原成完整原文——可以少掉純空白，不能少掉任何文字。\n' +
  '這一點會被程式檢查，缺字太多會整批退回改用機械分段。\n' +
  '\n' +
  '只回傳 JSON：\n' +
  '{"sections":[{"title":"小標","text":"這一段的原文"}]}';

/**
 * 用 AI 排版。由前端在使用者按下「智慧排版」時呼叫，不是自動跑——
 * 每天的逐字稿都排一次會花掉不少額度，而多數人只看其中幾天。
 */
function formatTranscript(dateStr) {
  var d = fmtDate_(dateStr);
  var t = getTranscript(d);
  if (!t.found) { return t; }
  if (t.formatted) { return t; }

  var row = null, best = -1;
  readSheetObjects_('影片清單').forEach(function (r) {
    if (fmtDate_(r['發布日期']) !== d) { return; }
    var len = String(r['修飾後逐字稿內容'] || '').length +
              String(r['原始逐字稿內容'] || '').length;
    if (len > best) { best = len; row = r; }
  });
  if (!row) { return { found: false, date: d }; }
  var v2 = displayTranscriptText_(row);
  if (v2.length < 200) { v2 = String(row['原始逐字稿內容'] || ''); }

  // 太長要分批，否則單次輸出會被截斷。
  var chunks = [];
  var s = v2;
  while (s.length > 7000) {
    var cut = s.lastIndexOf('。', 7000);
    if (cut < 3000) { cut = 7000; }
    chunks.push(s.slice(0, cut + 1));
    s = s.slice(cut + 1);
  }
  if (s.trim()) { chunks.push(s); }

  var sections = [];
  for (var i = 0; i < chunks.length; i++) {
    try {
      var raw = callGemini_(TX_FORMAT_SYSTEM, chunks[i],
                            { maxOut: 8192, temperature: 0.1, json: true });
      var res = JSON.parse(String(raw).replace(/^```json|^```|```$/gm, '').trim());
      // 還原檢查：把模型回傳的段落接起來，字數必須接近原文。
      //
      // 模型偶爾會「順手」摘要或漏掉一段，而那種錯誤從畫面上完全看不出來
      // ——版面很漂亮，只是內容少了一塊。逐字稿的用途就是核對原話，
      // 少字比排版難看嚴重得多，所以寧可退回機械分段。
      var joined = (res.sections || []).map(function (x) {
        return String(x.text || '');
      }).join('');
      var srcLen = chunks[i].replace(/\s/g, '').length;
      var outLen = joined.replace(/\s/g, '').length;

      if (joined.replace(/\s/g,'') !== chunks[i].replace(/\s/g,'')) {
        Logger.log('第 ' + (i + 1) + ' 批還原檢查未通過（' + outLen + '/' + srcLen +
                   ' 字），改用機械分段');
        sections = sections.concat(splitTranscriptByRule_(chunks[i]));
      } else {
        (res.sections || []).forEach(function (sec) {
          var txt = String(sec.text || '').trim();
          if (!txt) { return; }
          sections.push({ title: String(sec.title || '').slice(0, 12),
                          paras: splitTranscriptByRule_(txt)[0].paras });
        });
      }
    } catch (e) {
      // 某一批失敗就用規則分段補上，不要整份失敗。
      Logger.log('第 ' + (i + 1) + ' 批排版失敗，改用規則分段：' + e);
      sections = sections.concat(splitTranscriptByRule_(chunks[i]));
    }
  }

  if (!sections.length) { sections = splitTranscriptByRule_(v2); }
  CACHE.put(transcriptFormatCacheKey_(d,v2), JSON.stringify(sections), 21600);   // 存六小時

  return { found: true, date: d, title: String(row['標題'] || row['影片標題'] || ''),
           videoId: String(row['影片ID'] || ''), chars: v2.length,
           sections: sections, formatted: true };
}


/**
 * 診斷：列出影片清單每一天的逐字稿長度。
 * 逐字稿分頁說某天沒有內容、但你確定試算表裡有的時候，用這一支確認實情。
 */
function debugTranscripts() {
  var rows = readSheetObjects_('影片清單');
  Logger.log('影片清單共 ' + rows.length + ' 列');
  Logger.log('欄位名稱：' + Object.keys(rows[0] || {}).join('、'));
  Logger.log('');
  Logger.log('日期　　　　狀態　　原始　修飾後　會不會出現在逐字稿分頁');
  rows.slice(-20).forEach(function (r) {
    var d = fmtDate_(r['發布日期']);
    var v1 = String(r['原始逐字稿內容'] || '').length;
    var v2 = String(r['修飾後逐字稿內容'] || '').length;
    var show = (v2 >= 200 || v1 >= 200) ? '會' : '不會（兩者都不足 200 字）';
    Logger.log(d + '　' + String(r['處理狀態'] || '').slice(0, 4) +
               '　' + v1 + '　' + v2 + '　' + show);
  });
  Logger.log('');
  Logger.log('若某天顯示「會」但網站上看不到，執行 CACHE.remove(\'txDates\') 清快取後重試。');
}

/** 清掉逐字稿相關快取。改過試算表之後想立刻看到新內容時用。 */
function clearTranscriptCache() {
  CACHE.remove('txDates');
  readSheetObjects_('影片清單').forEach(function (r) {
    var d = fmtDate_(r['發布日期']);
    if (d) { CACHE.remove('txfmt_' + d); }
  });
  Logger.log('逐字稿快取已清除');
}
