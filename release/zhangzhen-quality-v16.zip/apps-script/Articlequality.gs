/** Fixed article structure, shared facts and no additional AI call on refresh. */
function enforceArticleRecords_(article, signals, d) {
  var text = String(article || ''), parts = {}, found = [], m;
  var re = /^\s*(?:#{1,6}\s*)?(?:\*\*)?([①②③④⑤⑥])(?![-－])\s*[^\n]*/gm;
  while ((m = re.exec(text))) { found.push({key:m[1],start:m.index}); }
  if (found.map(function(x){return x.key;}).join('') === '①②③④⑤⑥') {
    found.forEach(function(x,i){parts[x.key]=text.slice(x.start,i+1<found.length?found[i+1].start:text.length).trim();});
  }
  // ③ 放盤勢；講者的操作邏輯與教學重點（kind=view）放 ⑤，不在兩章重複出現。
  var macro = (signals.market || []).filter(function(r){return r._evidence_verified && r.kind !== 'view';})
    .map(function(r){return '• ' + publicNarrative_(r.text);});
  var lessons = (signals.market || []).filter(function(r){return r._evidence_verified && r.kind === 'view';})
    .map(function(r){return '• ' + publicNarrative_(r.text);});
  var kept = [], length = 0;
  macro.forEach(function(line){if(length+line.length+1<=2400){kept.push(line);length+=line.length+1;}});
  var chapter = recordChapter_(signals,d);
  // 日期未明的回顧不再另列一段：有現況看法的已經進了觀望類（上面的表格就有），
  // 沒有的本來就不列。另列會讓信件出現網站「翻到某一天」查不到的股票（2026/09/10）。
  var past = signals._past || [];
  var appendix = [];
  past.forEach(function(r){appendix.push('• ' + r._date + ' ' + r.name + '：' + publicNarrative_(r.reason,r));});
  if(appendix.length){chapter=chapter.replace('④-2', '補記（記在其他日期，不列入當日買賣）\n\n'+appendix.join('\n')+'\n\n④-2');}
  return ['① 文章標題：' + articleTitle_(signals),
    '② 基本資訊\n\n• 節目名稱：張震 股市盤中家教班\n• 播出平台：YouTube 直播 / 影片\n• 播出日期：'+d+'\n• 主要講者：張震',
    '③ 盤勢總覽重點整理\n\n'+(kept.join('\n') || '本集未整理出可引用的盤勢重點。'),
    chapter.trim(), ('⑤ 分析師操作邏輯與教學重點\n\n' +
      (lessons.length ? lessons.join('\n') : '本集未整理出可引用的操作教學。')),
    '⑥ 風險揭露與重要提醒\n\n• 本文章內容僅為整理節目中之公開資訊與觀點，不構成任何形式之投資建議或獲利保證。\n• 實際投資操作須自行評估風險與財務狀況，必要時請諮詢專業投資顧問。'].join('\n\n');
}

function attachArticleEvidence_(signals, d) {
  var rows = [];
  try { rows = readSheetObjects_('逐字稿判讀稽核'); } catch(e) { return signals; }
  var items = [], latest = null;
  rows.forEach(function(r){
    // 規則版本從 evidence-v2 升到 context-json-v3 之後，這裡仍只認 evidence-v2，
    // 於是整批大盤摘要都被略過，信件第③章變成「本支影片沒有已驗證的大盤摘要」（2026/09/11）。
    if(fmtDate_(r['影片日期'])!==d || !/^(evidence-v2|context-json-v\d+)$/.test(String(r['規則版本']||''))){return;}
    try {
      var p=JSON.parse(r['判讀JSON']); p.video=r['來源影片ID']; items.push(p);
      if(p.category==='manifest' && p.item.status==='published'){latest={video:p.video,batch:p.batch};}
    } catch(e) { Logger.log('略過無效稽核JSON'); }
  });
  signals.market=[];signals.history=[];signals._past=[];
  items.forEach(function(p){
    if(!latest || latest.video!==p.video || latest.batch!==p.batch){return;}
    if(p.category==='market' && p.item._evidence_verified){signals.market.push(p.item);}
    if(p.category==='history' && p.item._evidence_verified){signals.history.push(p.item);}
    if((p.category==='buy'||p.category==='sell') && p.item._date && p.item._date!==d){signals._past.push(p.item);}
  });
  return signals;
}
