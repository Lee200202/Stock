/**
 * 公開價位摘要。保留試算表原始多次交易價，避免最高展示價變成平均成本。
 * @param {*} value 原始價位
 * @param {string=} evidence 價位原句
 * @param {string=} context 說明
 * @return {string} 單一價位、以上／以下或未說明
 */
function displayPrice_(value, evidence, context) {
  var text = String(value || '').trim();
  if (!text || /^[−-]|\d[/／]\d|[xX]|\d\s*(?:日|天|張|%|％)|EPS|均線/i.test(text)) return '未說明';
  text = text.replace(/182020252135/g, '1820、2025、2135');
  text = text.replace(/(\d),(?=\d{3}(?:\D|$))/g, '$1');
  if (/\d{7,}/.test(text)) return '未說明';
  var re = /\d+(?:\.\d+)?/g, m, best = null;
  while ((m = re.exec(text))) {
    if (!(Number(m[0]) > 0 && Number(m[0]) <= 100000)) return '未說明';
    if (!best || Number(m[0]) > Number(best[0])) best = m;
  }
  if (!best) return '未說明';
  var amount=best[0].replace('.', '\\.');
  var ctx=String(context||'');
  if(new RegExp('(?:大跌|下跌|上漲|漲|跌|漲幅|跌幅)\\s*'+amount+'\\s*(?:元|塊)').test(ctx) &&
     !new RegExp('(?:成本|買點|現價|股價|目標價|買在|賣在|來到|收在)\\s*(?:為|是|約|在)?\\s*'+amount+'(?!\\d)').test(ctx)) return '未說明';
  if ([5,10,20,60,120,200,240].indexOf(Number(best[0])) >= 0 && /均線|技術線|碰.{0,6}線|線型/.test(String(context || '')) &&
      !(new RegExp(best[0] + '\\s*(?:元|塊)')).test(String(evidence || ''))) return '未說明';
  var suffix = /^\s*(以上|以下)/.exec(text.slice(best.index + best[0].length));
  return String(Number(best[0])) + (suffix ? suffix[1] : '');
}

/** 僅供畫面日K預覽，絕不寫進正式日K或績效快取。 */
function intradayPreview_(daily, quote, today) {
  var rows = daily.slice();
  if (!quote || quote.date !== today || !quote.open || !quote.high || !quote.low || !quote.last) return rows;
  if (![quote.open,quote.high,quote.low,quote.last].every(function(v){return isFinite(v) && v > 0;})) return rows;
  if (quote.low > Math.min(quote.open,quote.last) || quote.high < Math.max(quote.open,quote.last)) return rows;
  // 收盤日K已存在時以正式資料為準。舊報價不跨日延伸。
  if (rows.some(function(r){return String(r.date).replace(/-/g,'/') === today;})) return rows;
  rows.push({date:today,open:quote.open,high:quote.high,low:quote.low,close:quote.last,
    volume:quote.volume || 0,_provisional:true,_asOf:quote.time});
  rows.sort(function(a,b){return String(a.date).localeCompare(String(b.date));});
  return rows;
}

// BEGIN PUBLIC NARRATIVE V10
var PUBLIC_CONFIRMED_NAMES = {"普威": ["4966", "譜瑞-KY"], "普位": ["4966", "譜瑞-KY"], "譜位": ["4966", "譜瑞-KY"], "加折": ["3533", "嘉澤"], "加哲": ["3533", "嘉澤"], "加澤": ["3533", "嘉澤"], "出金城": ["8210", "勤誠"], "初清程": ["8210", "勤誠"], "00981A": ["00981A", "主動統一台股增長"], "主動統一台股增長": ["00981A", "主動統一台股增長"], "瑞獄": ["2379", "瑞昱"], "雨沾": ["8271", "宇瞻"], "維星": ["2377", "微星"], "邦店": ["2344", "華邦電"], "連電": ["2303", "聯電"], "大力光": ["3008", "大立光"], "利基電": ["6770", "力積電"], "宜頂": ["5289", "宜鼎"], "移頂": ["5289", "宜鼎"], "以頂": ["5289", "宜鼎"], "川服": ["2059", "川湖"], "木德": ["3563", "牧德"], "四星KY": ["3661", "世芯-KY"], "四星": ["3661", "世芯-KY"], "宏準": ["2354", "鴻準"], "弘準": ["2354", "鴻準"], "紅準": ["2354", "鴻準"], "威星": ["2377", "微星"], "想碩": ["5269", "祥碩"], "享碩": ["5269", "祥碩"]};
/** 說明名稱與代號對齊，原始逐字稿與引用不經過這個函式。 */
function publicNarrative_(text, row) {
  row = row || {};
  text = String(text || '').replace(/(^|[，,。；;：:、「『（(\s]|雖然|但是|但|而且|而|並且|並|且|因為|所以)(?:張震|張正|講者)(?:老師)?(?:本人)?(?:的(?=會員))?/g,'$1');
  text=text.replace(/[（(][^（）()]*?(?:原文(?:作|為|寫|說)|語音(?:作|為)|誤植|誤字)[^（）()]*[）)]/g,'');
  if(String(row.code||'')==='5274')text=text.replace(/信化/g,'信驊');
  Object.keys(PUBLIC_CONFIRMED_NAMES).sort(function(a,b){return b.length-a.length;}).forEach(function(heard){
    if(heard==='00981A')return;
    var fixed=PUBLIC_CONFIRMED_NAMES[heard][1];
    if(heard!==fixed)text=text.split(heard).join(fixed);
  });
  Object.keys(PUBLIC_CONFIRMED_NAMES).forEach(function(heard){
    var fixed=PUBLIC_CONFIRMED_NAMES[heard][1], escaped=fixed.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    text=text.replace(new RegExp(escaped+'\\s*[（(]'+escaped+'[）)]','g'),fixed);
  });
  var name=row.name || '', code=String(row.code || ''), raw=row['原始語音名稱'];
  if(raw && raw.length>=2 && name && (!PUBLIC_CONFIRMED_NAMES[raw] || PUBLIC_CONFIRMED_NAMES[raw][0]===code)) text=text.split(raw).join(name);
  if(name && /^(?:00981A|\d{4,6})$/.test(code)) {
    var escaped=name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
    text=text.replace(new RegExp(escaped+'\\s*(?:[（(]\\s*(?:00981A|\\d{4,6})\\s*[）)]|(?:00981A|\\d{4,6})(?=為例|這檔|這支|這一檔)|代號\\s*(?:00981A|\\d{4,6})(?!\\d))','g'),name+'（'+code+'）');
    text=text.replace(new RegExp(escaped+'\\s*[（(]'+escaped+'[）)]','g'),name);
    text=text.replace(new RegExp('(?:'+escaped+'){2,}','g'),name);
  }
  var seen={},parts=[];
  text.split(/[。；;]/).forEach(function(part){
    var key=part.replace(/回顧|過往|目前|\s|[，,]/g,'');
    if(key && !seen[key]){seen[key]=true;parts.push(part.trim());}
  });
  return parts.join('。')+(parts.length?'。':'');
}
// END PUBLIC NARRATIVE V10

/** 從同批已驗證盤勢取20字內標題，重建郵件不另呼叫模型。 */
function articleTitle_(signals) {
  var rows=(signals.market||[]).filter(function(r){return r._evidence_verified && r.kind!=='view';});
  for(var i=0;i<rows.length;i++) {
    var r=rows[i], title=String(r.headline||'').replace(/^[ ①：:。！？「」]+|[ ①：:。！？「」]+$/g,'');
    var source=String(r.text||'')+(r.evidence||[]).join(' '), chars=title.match(/[A-Za-z0-9_\u3400-\u9fff]/g)||[];
    var nums=title.match(/\d+(?:\.\d+)?/g)||[];
    if(title && Array.from(title).length<=20 && !/張震|張正|講者|盤勢與操作紀錄|\d{4}[/年]/.test(title) &&
       nums.every(function(n){return source.indexOf(n)>=0;}) && (!chars.length || chars.filter(function(c){return source.indexOf(c)>=0;}).length/chars.length>=0.8))return title;
  }
  var text=rows.map(function(r){return r.text||'';}).join(' '),themes=[];
  [[/CPI|消費者物價指數/,'CPI動向'],[/PPI|生產者物價指數/,'PPI動向'],[/利率|聯準會/,'利率決策'],
   [/量縮|成交量縮/,'量縮整理'],[/震盪|壓縮|橫盤/,'震盪盤勢'],[/外資|資金/,'外資動向'],
   [/美元|匯率/,'匯率變化'],[/融資/,'融資變化'],[/缺口|支撐|關卡/,'技術關卡']].forEach(function(pair){if(pair[0].test(text))themes.push(pair[1]);});
  return themes.length?themes.slice(0,2).join('與'):'市場觀察與操作重點';
}
