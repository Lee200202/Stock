const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const path = require('path');
const root = path.resolve(__dirname, '..');
let syntaxCount = 0;
for (const f of fs.readdirSync(path.join(root, 'apps-script'))) {
  const text = fs.readFileSync(path.join(root, 'apps-script', f), 'utf8');
  if (f.endsWith('.gs')) { new vm.Script(text, {filename: f}); syntaxCount++; }
  if (f.endsWith('.html')) {
    for (const match of text.replace(/<!--[\s\S]*?-->/g, '').matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/gi)) {
      new vm.Script(match[1].replace(/<\?[\s\S]*?\?>/g, 'null'), {filename:f}); syntaxCount++;
    }
  }
}
const properties = {};
const calls = [];
const ctx = vm.createContext({
  PropertiesService: {getScriptProperties: () => ({getProperty:k=>properties[k],setProperty:(k,v)=>properties[k]=v})},
  ScriptApp: {getProjectTriggers:()=>[], newTrigger:()=>({timeBased:()=>({after:()=>({create:()=>{}})})})},
  nowStamp_:()=> '2026/09/10 16:00:00', fmtDate_:s=>s, adminAuth_:()=>{}, withLock_:f=>f(),
  stepArticle_:()=> calls.push('mail'), rebuildHoldingsTrackerJob:()=> calls.push('tracker'),
  rebuildPerformanceHistoryJob:d=>{calls.push('history:'+d);return {ok:true};},
  snapshotPerformanceJob:()=> calls.push('perf'),
});
vm.runInContext(fs.readFileSync(path.join(root,'apps-script/Presentationquality.gs'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(root, 'apps-script/Evidencequality.gs'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(root, 'apps-script/Articlequality.gs'),'utf8'),ctx);
assert(ctx.validEvidence_(['我昨天買世芯-KY，今天還有。'], '我昨天買世芯-KY，今天還有。'));
assert(!ctx.validEvidence_(['新代我們今天買了。'], '我昨天買世芯-KY，今天還有。'));
assert.equal(ctx.rawTranscript_({'原始逐字稿內容':'原文辛耘','修飾後逐字稿內容':'摘要星雲'}),'原文辛耘');
assert(ctx.apiAdminStartDaySync('k','2026/09/09').ok);
assert(!ctx.apiAdminStartDaySync('k','2026/09/10').ok);
ctx.runDayEditSync_();
assert.equal(ctx.daySyncState_().status,'處理中');
assert.equal(ctx.daySyncState_().index,1);
ctx.runDayEditSync_();ctx.runDayEditSync_();ctx.runDayEditSync_();
assert.deepStrictEqual(calls,['mail','tracker','history:2026/09/09','perf']);
assert.equal(ctx.daySyncState_().status,'完成');
ctx.apiAdminStartDaySync('k','2026/09/09');
ctx.runDayEditSync_();
ctx.rebuildHoldingsTrackerJob=()=>{throw new Error('tracker unavailable');};
assert.throws(()=>ctx.runDayEditSync_(),/tracker unavailable/);
assert.equal(ctx.daySyncState_().status,'失敗');
assert.equal(ctx.daySyncState_().index,1);
const oldCalls=calls.length;ctx.runDayEditSync_();assert.equal(calls.length,oldCalls);
ctx.apiAdminStartDaySync('k','2026/09/09');ctx.apiAdminCancelDaySync('k');ctx.runDayEditSync_();
assert.equal(ctx.daySyncState_().status,'已取消');
const sig={buy:[],sell:[],holdings:[{name:'鴻準',code:'2354',note:'目前仍持有。'}],watch_avoid:[],watch_watch:[]};
const article=ctx.enforceArticleRecords_('① 標題\n④ 會員操作紀錄與持股明細\n華城今日賣出\n⑤ 分析師操作邏輯與教學重點\n',sig,'2026/09/10');
assert(!article.includes('華城'));assert(article.includes('鴻準'));assert(article.includes('未說明當日具體買賣'));
assert(ctx.enforceArticleRecords_('不完整文章',sig,'2026/09/10').includes('⑥'));
// 日期未明的回顧不再另列：信件不可出現網站「翻到某一天」查不到的股票（2026/09/11）。
const sigHistory=Object.assign({},sig,{history:[{name:'索羅門',reason:'大漲時賣出索羅門。'}]});
const withHistory=ctx.enforceArticleRecords_('① 標題\n④ 會員操作紀錄\n⑤ 教學\n',sigHistory,'2026/09/10');
assert(!withHistory.includes('索羅門'));assert(!withHistory.includes('歷史回顧'));
// 規則版本升到 context-json-v3 之後，大盤摘要仍要讀得到；③ 放盤勢、⑤ 放教學重點（2026/09/11）。
const auditRow=(item,cat)=>({'影片日期':'2026/09/11','規則版本':'context-json-v3','來源影片ID':'MANUAL-20260911',
  '判讀JSON':JSON.stringify({batch:'R1',category:cat,item:item})});
ctx.readSheetObjects_=()=>[auditRow({kind:'level',text:'指數關卡46188',_evidence_verified:true},'market'),
  auditRow({kind:'view',text:'下跌不賣、大漲才賣',_evidence_verified:true},'market'),
  auditRow({status:'published'},'manifest')];
const sig3=ctx.attachArticleEvidence_({buy:[],sell:[],holdings:[],watch_avoid:[],watch_watch:[]},'2026/09/11');
assert.equal(sig3.market.length,2);
const art3=ctx.enforceArticleRecords_('① 標題\n④ 會員操作紀錄\n⑤ 教學\n',sig3,'2026/09/11');
const third3=art3.split('③')[1].split('④')[0], fifth3=art3.split('⑤')[1].split('⑥')[0];
assert(third3.includes('46188'));assert(!third3.includes('下跌不賣'));assert(fifth3.includes('下跌不賣'));
// 同一天只寄第一封：整天重跑把那一列刪掉重建成「待寄送」，也不再寄第二封（2026/09/11）。
const mailProps = {}, mailSent = [];
let pushRows, failAt = 0, today = '2026/09/11';
const mctx = vm.createContext({
  PropertiesService: {getScriptProperties: () => ({getProperty: k => mailProps[k], setProperty: (k, v) => { mailProps[k] = v; }})},
  Logger: {log: () => {}},
  MailApp: {sendEmail: m => { if (failAt && mailSent.length + 1 === failAt) { throw new Error('quota'); } mailSent.push(m.to); }},
});
vm.runInContext(fs.readFileSync(path.join(root, 'apps-script/MailService.gs'), 'utf8'), mctx);
Object.assign(mctx, {
  todayStr_: () => today, isTradingDayToday_: () => true, fmtDate_: s => s, nowStamp_: () => today + ' 13:05:00',
  withLock_: f => f(), gateReady_: () => true, readSheetObjects_: () => [], mdToHtml_: s => s, wrapMail_: b => b,
  activeSubscribers_: () => ['a', 'b', 'c'].map(e => ({Email: e + '@x', '取消訂閱權杖': 't', '訂閱項目': '每日總覽', '關注股票代號': ''})),
  getSheet_: () => ({
    getDataRange: () => ({getValues: () => pushRows.map(r => r.slice())}),
    getRange: (r, c) => ({getValue: () => pushRows[r - 1][c - 1], getNote: () => '',
      setValue(v) { pushRows[r - 1][c - 1] = v; return this; }, setNote() { return this; }})
  })
});
const pushHead = ['日期', '文字稿', '寄送狀態'];
pushRows = [pushHead, ['2026/09/11', '第一版', '待寄送']];
mctx.dailyPushJob();
assert.equal(mailSent.length, 3); assert.equal(pushRows[1][2], '已寄送');
assert(JSON.parse(mailProps.dailyPushSentDates)['2026/09/11']);
pushRows = [pushHead, ['2026/09/11', '第二版', '待寄送']];          // 整天重跑：列被刪掉重建
mctx.dailyPushJob(); mctx.dailyPushJob();
assert.equal(mailSent.length, 3); assert.equal(pushRows[1][2], '已寄送');
// 寄到一半出錯：已經有人收到，就不退回待寄送，否則先收到的人每五分鐘多一封。
today = '2026/09/14'; failAt = 5; pushRows = [pushHead, ['2026/09/14', '文章', '待寄送']];
assert.throws(() => mctx.dailyPushJob(), /quota/);
assert.equal(mailSent.length, 4); assert(pushRows[1][2].startsWith('已寄送'));
failAt = 0; mctx.dailyPushJob(); assert.equal(mailSent.length, 4);
// 一封都還沒寄出就出錯：仍退回待寄送，下一棒照常重試。
today = '2026/09/15'; failAt = 5; pushRows = [pushHead, ['2026/09/15', '文章', '待寄送']];
assert.throws(() => mctx.dailyPushJob(), /quota/);
assert.equal(pushRows[1][2], '待寄送');
failAt = 0; mctx.dailyPushJob(); assert.equal(mailSent.length, 7);
// 上線前就寄過（試算表已寄送、寄送紀錄還沒有）：先補記，之後被改回待寄送也不寄。
today = '2026/09/16'; pushRows = [pushHead, ['2026/09/16', '文章', '已寄送']];
mctx.dailyPushJob(); pushRows[1][2] = '待寄送'; mctx.dailyPushJob();
assert.equal(mailSent.length, 7); assert.equal(pushRows[1][2], '已寄送');
// whyNoMail() 在編輯器執行曾丟 ReferenceError: chr is not defined（2026/09/11）：實際跑一次。
const whyText = mctx.whyNoMail();
assert(whyText.split('\n').length > 5); assert(whyText.includes('今天（2026/09/16）的推播狀態'));
assert(whyText.includes('第一封已在 2026/09/16 13:05:00 寄出'));
console.log(`PASS: ${syntaxCount} script syntax checks; evidence, durable day-sync, failure, cancellation, article and one-mail-per-day regression checks.`);
