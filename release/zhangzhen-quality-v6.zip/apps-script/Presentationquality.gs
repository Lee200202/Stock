/**
 * 公開價位摘要。保留試算表原始多次交易價，避免最高展示價變成平均成本。
 * @param {*} value 原始價位
 * @param {string=} evidence 價位原句
 * @param {string=} context 說明
 * @return {string} 單一價位、以上／以下或未說明
 */
function displayPrice_(value, evidence, context) {
  var text = String(value || '').trim();
  if (!text || /^[−-]|\d[/／]\d|[xX]|\d\s*(?:日|天|張|%|％)|EPS|均線/i.test(text)) return '未說明';
  text = text.replace(/182020252135/g, '1820、2025、2135');
  text = text.replace(/(\d),(?=\d{3}(?:\D|$))/g, '$1');
  if (/\d{7,}/.test(text)) return '未說明';
  var re = /\d+(?:\.\d+)?/g, m, best = null;
  while ((m = re.exec(text))) {
    if (!(Number(m[0]) > 0 && Number(m[0]) <= 100000)) return '未說明';
    if (!best || Number(m[0]) > Number(best[0])) best = m;
  }
  if (!best) return '未說明';
  if ([5,10,20,60,120,200,240].indexOf(Number(best[0])) >= 0 && /均線|技術線|碰.{0,6}線|線型/.test(String(context || '')) &&
      !(new RegExp(best[0] + '\\s*(?:元|塊)')).test(String(evidence || ''))) return '未說明';
  var suffix = /^\s*(以上|以下)/.exec(text.slice(best.index + best[0].length));
  return String(Number(best[0])) + (suffix ? suffix[1] : '');
}

/** 僅供畫面日K預覽，絕不寫進正式日K或績效快取。 */
function intradayPreview_(daily, quote, today) {
  var rows = daily.slice();
  if (!quote || quote.date !== today || !quote.open || !quote.high || !quote.low || !quote.last) return rows;
  if (![quote.open,quote.high,quote.low,quote.last].every(function(v){return isFinite(v) && v > 0;})) return rows;
  if (quote.low > Math.min(quote.open,quote.last) || quote.high < Math.max(quote.open,quote.last)) return rows;
  // 收盤日K已存在時以正式資料為準。舊報價不跨日延伸。
  if (rows.some(function(r){return String(r.date).replace(/-/g,'/') === today;})) return rows;
  rows.push({date:today,open:quote.open,high:quote.high,low:quote.low,close:quote.last,
    volume:quote.volume || 0,_provisional:true,_asOf:quote.time});
  rows.sort(function(a,b){return String(a.date).localeCompare(String(b.date));});
  return rows;
}
